# YENİ (v273): Gelen kutusunda "SİL" + push token yenileme
- **Mesaj silme:** Mesaj penceresinde, hediyesi ALINMIŞ (ya da hediyesiz) mesajlarda "SİL" düğmesi. Alınmamış hediye silinemez. Silinen id'ler cihazda saklanır (`inbox_dismissed_v1`, buluta girmez); worker'da silme uç noktası yok, bu yüzden yeniden kurulumda mesaj geri gelebilir (hediyesi zaten alınmış görünür). `InboxService.deleteMessage`.
- **Push:** `PushService.init` Firebase ayar damgası (proje|gönderen|appId) değişince FCM token'ı bir kez siler ve yenisini alır (`fcm_cfg_stamp_v1`); eski projeden kalan token yeni projede SENDER_ID_MISMATCH/UNREGISTERED verir. Token'ın son 8 karakteri `[push]` logunda görünür. Sunucu tarafı (Worker `FCM_SERVICE_ACCOUNT` secret'ı, FCM HTTP v1 API) uygulamadan kontrol edilemez: `npx wrangler tail merge-davet` ile gönderim sırasındaki FCM hata koduna bak.
- Sürüm: 1.4.5+45.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter pub get && flutter analyze && flutter test`.

# YENİ (v272): v270 temel alındı — yalnız Hafta Sonu / Gezegen Birleştir etkinliği kaldırıldı, yarış takvimi değişti
- **Kaldırıldı:** Hafta sonu etkinliği (`planet_event*`, `planet_game_screen`, `planet_physics`, `planet_face`, `planet_merge_fx`, `assets/images/planet/`, ana menüdeki "Weekend" ikonu, bildirimleri, bulut kaydı `planet_event_v1`). `PlanetReward` → `EventReward` (`models/event_reward.dart`). Eski bulut kayıtlarındaki `planet_event_v1` alanı yok sayılır (etkinlikte birikmiş ilerleme/ödül kaybolur).
- **Dokunulmadı:** Billing (IAP), kumbara, başlangıç paketi, mesaj kutusu/davet (Cloudflare worker), FCM push, takım yarışı, haftalık etkinlik (hafta sonu 2 kat puan dahil), sezon.
- **Yeni takvim (NORMAL hafta):** Fırlat Yarışı **Pazartesi 10:00 → Perşembe 10:00** (72 sa), Merge Tahtası Yarışı **Cuma 10:00 → Pazartesi 10:00** (72 sa). Üst üste binmez. Bir sonraki hafta **Takım Yarışı** haftası (varsayılan 2 haftada bir; `team_race_every_weeks`). Takım yarışı haftasında Merge/Fırlat açılmaz; Cuma'da başlayan Merge yarışı takım yarışının açıldığı Pzt 10:00'da biter. `LiveEvents.buildDefaults()`; testler için `LiveEvents.defaultDefsOverride`.
- ⚠️ Remote Config `events_json` aynı id'li (`race_mod1`, `race_mod2`) tanımı TAMAMEN ezer: eski takvimi içeriyorsa sil/güncelle.
- ⚠️ Hedef/sıralama ödülleri ve botlar 48 saate göre ayarlıydı; 72 saatte botlar ve oyuncular ~1,5× puan yapar.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter pub get && flutter analyze && flutter test`. Özellikle bak: `main_menu_screen.dart`, `save_merge.dart`, `notification_service.dart`, `live_events_test.dart`, `team_race_test.dart`.
- Sürüm: 1.4.4+44 (Play'deki yayındaki sürümün versionCode'undan büyük olmalı).

# YENİ (v268): Açılış kapıları — Firebase erken, yasal pencere sadeleşti, bildirim 2. açılışta, Play Games elle
- **Firebase açılışta aktif:** `PushService.initCore()` (Firebase.initializeApp + Analytics + Crashlytics) `main()`'de en başta, onay penceresini BEKLEMEDEN başlar. `AndroidManifest`: `firebase_analytics_collection_enabled` = true (Crashlytics/FCM manifestte hâlâ kapalı, onaydan sonra). `PushService.init()` artık yalnız onay sonrası kısmı (Remote Config + FCM) yapar. `AnalyticsService.load()` diskteki tamponu sink hazırsa hemen iletir. ⚠️ AB/AEA/UK kullanıcıları için analitik artık onay öncesi çalışıyor (Play Veri Güvenliği formunu buna göre doldur).
- **Yasal pencere:** Şartlar/Gizlilik onay kutuları kaldırıldı; iki bağlantı satırı (okunabilir) + **Kabul Et** (yeşil) ve **Reddet** (turuncu, oyundan çıkar) butonları. AB/AEA/UK'deki kişiselleştirilmiş reklam kutusu (isteğe bağlı, varsayılan kapalı) DURUYOR.
- **Bildirim izni:** splash'ten kaldırıldı. `NotificationService.registerOpen()` her soğuk açılışta sayaç artırır; ana menü `openCount >= 2` ve ilk-çalıştırma öğreticisi yokken izni bir kez ister (öğretici sürüyorsa sonraki açılışa kalır).
- **Play Games:** açılıştaki otomatik giriş (`autoSignIn`) çağrısı kaldırıldı; giriş ve bulut kaydı yalnız Ayarlar > "Sign in with Google Play Games" ile. Zaten bağlı oyuncuda sessiz senkron aynen sürer. ⚠️ `games_services` eklentisinin kendi native otomatik girişi varsa `GamesResolutionActivity` yine görünebilir; yayında Firebase'te kontrol et.
- **Yeni Firebase olayları (huni):** `boot_ok {accepted}`, `net_gate_fail`, `legal_shown {gdpr_box}`, `legal_decline`, `consent_accept` (zaten vardı), `notif_prompt_result {granted, open}`, `games_signin_tap`, `games_signin_result {ok}`. Parametreleri raporda görmek için Custom definitions'a ekle.
- **Dokunulmadı:** zorunlu internet kapısı, Fırlat yönlendirmesi, reklam/enerji dengesi.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test`. Telefonda bak: (1) yeni kayıtta yasal pencerede iki buton var mı, Kabul sonrası doğrudan oyun mu, (2) ilk açılışta bildirim izni ÇIKMIYOR, ikinci açılışta menüde 2 sn sonra çıkıyor, (3) ilk açılışta Play Games penceresi çıkmıyor, Ayarlar'daki düğme çalışıyor, (4) Firebase DebugView'da `boot_ok`/`legal_shown`/`consent_accept` görünüyor.

# YENİ (v253): İlk 10 dakika düzeltmeleri (öğretici + hikâye sırası + 3. bölüm + ilk enerji refill)
- **Öğretici artık üretmeyi öğretiyor:** yeni oyuncunun tahtası 7 Lv1 ile başladığı için ilk sipariş çoğu zaman üretmeden doluyor ve oyuncu enerji harcayan sandığa hiç dokunmadan öğreticiyi bitiriyordu (~%94). `MbTutorial.plan(board, needSpawn: true)` ilk adım olarak **Üret'e dokun** gösterir (tahtada yer ve enerji varsa). İlk sipariş üretmeden bitse bile öğretici üretme adımı yapılana kadar sürer (`_tutOrderDone`); enerji 0 ise takılmaz.
- **Hikâye öğreticiden SONRA:** `merge_board_screen.dart` açılışta önce `_tutInit()`; öğretici gerekmiyorsa (zaten görülmüş) hikâye eskisi gibi hemen kontrol edilir. Yeni oyuncuda hikâye, öğretici bitince/atlanınca (`_tutFinish`/`_tutSkip` zaten çağırıyordu) gelir. Yani ilk dokunuş splash + onaydan sonra hikâye okutmadan olur.
- **3. bölüm (ilk çift sipariş) hafifledi:** hedef 5 → 4, en düşük seviye Lv3 → Lv2 (yalnız `n <= 3`; 23, 43… duo bölümleri aynı). Simülasyonda (mükemmel oyun, 2000 deneme) 3. bölüm ~54 → ~33 üretim; 4 bölüm toplamı ~131 → ~116 üretim.
- **İlk seviye atlama (tam enerji) 3. bölüm sonunda:** `MbChapter.xpReward` ilk 3 bölümde +15 (30/30/29 = 89 ≥ 80). Eskiden 1. seviye 6. bölümdeydi, ilk enerji duvarı ise 3-4. bölümde. Mod 1 XP'si ve `xpNeededForLevel` DEĞİŞMEDİ.
- **Öğretici bitiş metni:** "Enerji zamanla dolar" (dolum 90 sn'de 1 ⚡, yanıltıcıydı) → "Seviye atlayınca enerji dolar ⚡" (7 dil; yeni anahtar `Level up refills energy ⚡`).
- **Testler:** `mb_tutorial_test.dart` (needSpawn), `merge_board_test.dart` (3. bölüm hedefi/seviyesi, xpReward). Kayıtlar uyumlu: mevcut oyuncu 3. bölümde 4/5 ilerlemedeyse bölüm bir sonraki teslimde biter (`>= goal`).
- **Dokunulmadı (bilerek):** internet zorunluluğu, yasal onay, bildirim izni zamanı, menüden Fırlat'a yönlendirme.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test`. Telefonda bak: (1) yeni kayıtta öğretici ilk adımda sandığı gösteriyor mu, (2) hikâye ilk siparişten ~6 sn sonra mı geliyor, (3) 3. bölümde seviye atlama penceresi + enerji doluyor mu, (4) tahta doluyken öğretici takılmıyor mu.

# YENİ (v252): Gezegen (hafta sonu) etkinliği olayları Firebase'e gidiyor
- `AnalyticsService.firebaseEvents`'e `pe_run_start` (parametreler: `games`, `energy`), `pe_run_end` ve `pe_claim` (parametre: `task`) eklendi. `pe_open` zaten vardı. Böylece etkinliğe giren, oyun başlatan ve ödül alan kullanıcı sayısı konsolda görünür. Oyun/fizik koduna dokunulmadı.
- Parametreler (`task`, `games` vb.) konsolda özel boyut tanımlanmadan raporlarda görünmez; olay sayıları ve kullanıcı sayıları görünür.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze`.

# YENİ (v251): "Oyunlarımız" tıklamaları Firebase'e gidiyor
- `AnalyticsService.firebaseEvents`'e `more_games_open` (Ayarlar'dan ekrana giriş) ve `more_games_tap` (oyun satırına dokunma, parametre `app: yuzbirarena`) eklendi. Konsolda olay sayısı ve kullanıcı sayısı görünür (olaylar ~24 saat gecikmeyle düşer). Parametreye göre kırılım için Firebase'de `app` özel boyut olarak tanımlanmalı; tek oyun olduğu için şart değil.
- Analitik kimliği `astrofelyx` → `yuzbirarena`. Play Store paketi (`com.astrofelyx.pro`) aynı.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze`.

# YENİ (v250): "Oyunlarımız" ekranındaki oyun adı/ikonu değişti
- `more_games_screen.dart`: giriş artık **Anne Terliği:Koridor**, ikon `assets/images/apps/anne_terligi.webp` (anne_terligi_icon_512.png'den 256 px WebP). Play Store paketi (`com.astrofelyx.pro`) ve analitik kimliği (`astrofelyx`) AYNI kaldı. Eski `galaxy_puzzle.webp` silindi.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze`.

# YENİ (v249): Fırlat modu SlideMerge hissine yaklaştırıldı (Gezegen/Suika modu DEĞİŞMEDİ)
- **Kaynak:** `SlideMerge_mekanik_ozeti.md` (Unity APK analizi). Değerler birebir değil, ona YAKIN seçildi; hepsi `board_physics.dart` içindeki tek blokta (`v249 SLIDEMERGE HISSI`).
- **Fizik (`BoardPhysics`):** top-top sürtünme 0.8 → **0.04** (kaygan), duvar sürtünme 0 → **0.22**, duvar sekmesi 0 → **0.04**, sönüm 5 → **1.7** (uçuşta ve oturmada aynı), kütle artık **alanla orantılı** (`pieceDensity = 1`; büyük top ağır, eskiden hepsi eşit kütleydi). Pervane (`gust`) hızı sönüm oranıyla ölçeklenir, kayma mesafesi eskisi gibi kalır.
- **Atış:** `throwSpeedPerTableLen` 8.63 → **3.4** (masayı ~0.4 sn'de geçer, eskiden ~0.18 sn). Atış hâlâ düz yukarı; Nişan Rehberi dikey çizgisi doğru kalır.
- **Atış kilidi (`GameBoard._tickSettleLock`):** atıştan sonra tüm topların hızı `masa uzunluğu × 0.022` px/sn altında **0.22 sn** kalana kadar yeni atış yok (`settleSpeedPerTableLen`, `settleLockDelay`). Güvenlik: en geç **2.6 sn** sonra açılır (`settleLockMaxSeconds`). Eski `_throwCooldown` (Hızlı Atış) artık kilidin MİNİMUM süresi. Yeniden başlat / devam et kilidi sıfırlar.
- **Yapılmadı:** çokgen parçalar (daire kaldı), açılı atış (yatay bileşen), birleşme doğum hızı, boşta 2 sn ipucu, ikinci "kurtarma" çizgisi.
- **Gevşek uçlar / telefonda bak:** (1) kilit yüzünden tur hızı yavaşladı; çok yavaşsa `settleLockDelay` ↓ ya da `settleLockMaxSeconds` ↓. (2) Sönüm düşünce toplar uzağa kayar; çok kayıyorsa `settledDamping` ↑ (2.2) ya da `ballFriction` ↑ (0.1). (3) Atış çok yavaşsa `throwSpeedPerTableLen` ↑. (4) Sipariş süreleri / sınırlı süre bölümlerinin dengesi kilitten etkilenir.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test`.

# YENİ (v245): Yeni cizilmis ikonlar (emoji/eski ikon yerine)
- `assets/images/ui/`: `event_chest.webp` (Etkinlik sandigi, menu), `team_race.webp` (Takimlar yarisi; menu ikonu + yaris ekrani basligi), `throw_mode.webp` (Firlat; sol sutun), `throw_race.webp` + `merge_race.webp` (canli yarislarin menu ikonu ve yaris ekrani basligi, `eventIconAsset(d)`).
- `chest.webp` merge tahtasindaki odul sandigi icin yerinde kaldi. Liderler sekmelerindeki kucuk emoji etiketleri (🛡️/🧩/🎯) degismedi.
- ⚠️ Derlenmedi / calistirilmadi: `flutter analyze && flutter test`.

# YENİ (v244): Billing geri geldi (v237'deki gibi) + sezon yolunda para/reklam seçimi
- **Geri alınanlar:** `billing_service.dart`, `in_app_purchase` bağımlılıkları, `BILLING` izni, mücevher mağazasında başlangıç paketi + mücevher paketleri, kumbara (ekran, menü ikonu, bildirim), menüdeki "FIRSAT" ikonu, sezon premium satın alma butonu (`season_pass_premium`).
- **Sezon premium (iki yol):** para verenler (`premium == true`) tüm premium ödülleri reklamsız alır ve "Hepsini al" onları da toplar; vermeyenler her kademede bedava ödülü aldıktan sonra o kademenin premium ödülünü 1 ödüllü reklamla alır (toplu reklam yok). Premium kartında ▶ ikonu yalnız reklam yolunda görünür.
- Durmaya devam edenler: reklam beklemeleri 0 (v240), Play Games hesap düzeltmesi (v242), mesaj kutusu + davet (v243), Liderler ikonu.
- ⚠️ Play Console'da `season_pass_premium` ve mağaza ürünleri tanımlı/aktif olmalı. Derlenmedi / çalıştırılmadı: `flutter pub get && flutter analyze && flutter test`.

# YENİ (v243): Mesaj kutusu + arkadaş daveti geri geldi (billing YOK)
- `inbox_service.dart`, `inbox_screen.dart`, `push_service.dart` v237'den aynen geri alındı; `main.dart` (yükleme, `onLevelUp`, açılış/dönüş senkronu), bulut kaydı (`InboxService.save/reloadAfterCloudRestore`) ve ana menü (davet turu `feat_invite`, `_openInbox`) yeniden bağlandı.
- Alt çubuk: Oyna | Liderler | **Mesaj kutusu (yeni zarf ikonu `assets/images/ui/envelope.webp`)** | Menü(ayarlar). Liderler ikonu duruyor.
- Billing, kumbara ve satın alma butonları kaldırılmış hâlde kalıyor (v238).
- Worker: `InboxService.baseUrl` → `https://merge-davet.sitora2026.workers.dev` (worker'ı silme/taşıma: bu adres güncellenmeli).
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`.

# YENİ (v242): Play Games hesap değişimi hatası
- **Sebep:** Hesap değişince yeni hesapta bulut kaydı yoksa, eski hesabın yerel ilerlemesi yeni hesabın ilk bulut kaydı olarak yazılıyordu (`_syncOnce`, `switched && cloud == null`). Böylece her hesap aynı ilerlemeyle başlıyor, veri silinse bile her hesabın bulutundan aynı kayıt geri geliyordu.
- **Düzeltme:** Bu durumda yazma yapılmıyor; eski yerel hal `cloud_pre_switch_backup_v1` anahtarına yedekleniyor, bilgi popup'ı çıkıyor ve oyun kapanıyor. Sonraki açılışta `CloudSaveService.wipeIfPending()` (main.dart, servisler yüklenmeden önce) yerel veriyi siliyor (dil, yasal onay, cihaz kimliği, yedek kalır) → yeni hesap sıfırdan başlıyor.
- **Android Auto Backup kapatıldı** (`android:allowBackup="false"`): kaldır-yükle sonrası eski yerel kaydın Google yedeğinden geri gelmesini engeller; ilerleme Play Games bulut kaydıyla taşınıyor.
- ⚠️ Daha önce bu hatayla kirlenmiş hesapların bulut kaydı otomatik düzelmez; o hesapların Play Games oyun verisinin silinmesi gerekir.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`.

# YENİ (v241): Etkinlik/bildirim düzeltmeleri
- **Haftalık etkinlik (kilometre taşı):** hafta bitince ulaşılmış ama alınmamış ödüller artık kaybolmuyor; otomatik hesaba ekleniyor ve menüde "Haftalık etkinlik ödülleri hesabına eklendi!" popup'ı çıkıyor (`WeeklyEvent._autoDeliverOld`, not anahtarı `events_note_v1`).
- **Mod 2 (Merge Tahtası) enerji bildirimi:** enerji 30+ harcandıysa tam dolunca "Merge enerjin doldu ⚡" (ID 7). Mod 1 enerji bildirimi aynen duruyor.
- **Bildirim metinleri:** haftalık etkinlik bildirimi "Yarın 10:00'da sona eriyor" (6 dil); sezon uyarısı bitişten ~2 gün 5 saat önce (metin "son 2 gün" ile uyumlu).
- **Canlı etkinlik popup kaybı:** uygulama yeniden başlayınca henüz gösterilmemiş bitiş notları artık belleğe alınıyor, yeni bir etkinlik bitince eskisinin üstüne yazılmıyor.
- Hafta sonu etkinliği "hiç girmeyene son şans" bildirimi bilerek değiştirilmedi.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`.

# YENİ (v240): Reklam beklemeleri kaldırıldı + coin ikonu boş kutu düzeltmesi
- **Reklam beklemesi:** `AdService.cooldownSeconds` ve `interstitialMinGapSeconds` artık sabit **0** (Remote Config'teki `ad_cooldown_sec` / `inter_min_gap_sec` değerleri dikkate alınmaz). Reklam sıklığı LevelPlay panelindeki capping/pacing ayarlarıyla yönetilir. Geçiş reklamının bölüm sıklığı (`inter_every_chapters`, grace bölümleri) ve "bedava elmas" günlük pencere limiti değişmedi.
- **Coin ikonu:** `🪙` (Unicode 13) eski Android/MIUI fontlarında boş kutu çıkıyordu; düz `Text` kullanan Takım Yarışı ödül listesi (1./2./3. sıra) ve tur sonu "Round complete" ekranı `CoinText`'e çevrildi. Diğer ekranların hepsi zaten `CoinText` kullanıyordu.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`.

# YENİ (v239): Sezon yolu premium ödülleri reklama bağlandı
- Bir kademenin **bedava ödülü alınınca** aynı kademenin premium ödülü açılır; oyuncu özel "İzle" penceresi → 1 ödüllü reklam izleyerek alır (`placement: season_premium`, `strict: true` → reklam gerçekten izlenmeden ödül yok). Reklam bulunamazsa mevcut "Şu an reklam bulunamadı. Lütfen tekrar dene." popup'ı açılır.
- **Toplu alma yok:** "Hepsini al" yalnız bedava ödülleri toplar. Premium kart ▶ ikonlu; bedava ödül alınmamışsa kilitli.
- `kSeasonPremiumEnabled = true` (premium sütunu tekrar görünür), `premiumProductId` / `unlockPremium` silindi. `season_premium` reklam beklemesinden muaf (kademeler arası 60 sn bekletmesin).
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`.

# YENİ (v238): Billing, arkadaş daveti ve mesaj kutusu kaldırıldı; alt menüye Liderler ikonu
- **Billing:** `billing_service.dart`, `in_app_purchase` bağımlılıkları ve `BILLING` izni silindi. Mücevher mağazasından başlangıç paketi + mücevher paketleri (gerçek para) çıkarıldı; reklam/coin/enerji/güçlendirici bölümleri duruyor. Kumbara ekranı + menü ikonu + bildirimi kaldırıldı (kırmak yalnız satın almayla oluyordu). Sezon premium yolu kapandı (`kSeasonPremiumEnabled = false`). Menüdeki "FIRSAT" (başlangıç paketi) ikonu kaldırıldı.
- **Davet + Mesaj kutusu:** `inbox_service.dart`, `inbox_screen.dart` silindi; davet turu, `onLevelUp` bağı, açılış senkronu, push'tan gelen kutusu yenileme ve bulut kaydındaki `InboxService` çağrıları kaldırıldı. `SaveMerge.kInvite` (eski bulut kayıtları okunabilsin diye) bilerek bırakıldı.
- **Menü:** alt çubukta Mesaj Kutusu yerine kupa ikonlu **Liderler** (Lv.7'den önce kilitli, `LeadersScreen`). Sol sütundaki tekrar eden Liderler ikonu kaldırıldı.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter pub get && flutter analyze && flutter test`. Kullanılmayan çeviri anahtarları ve `inbox_push_*` Android metinleri bırakıldı (zararsız).

# YENİ (v235): Bulut kaydı — hesap değişimi koruması + bozuk/eski biçimli bulut kaydı artık "boş" sayılmıyor
- **Hesap değişimi:** yerel kayıt hangi Play Games oyuncusuna ait diye `cloud_player_id_v1` ile tutulur (`GamesServices.getPlayerID()`). Oyuncu değişirse 3'lü birleştirme YAPILMAZ: eski hesabın yerel hali `cloud_pre_switch_backup_v1`'e yedeklenir, yeni hesabın bulutu varsa AYNEN gelir, yoksa yerel kayıt korunup yeni hesaba ilk kayıt olur. Kimlik okunamazsa o tur hiçbir şey yazılmaz. Bağlama `_adopt` bittikten sonra yapılır (yarım kalırsa sonraki tur yine hesap değişimi sayılır).
- **Bozuk/eski biçimli bulut kaydı:** `_fetchCloud` artık "kayıt yok" (null) ile "kayıt var ama okunamadı" (`CloudUnreadableException`) ayırır. Okunamayan kayıt ASLA ezilmez; ham hali `cloud_corrupt_raw_v1`'e yedeklenir. Okunamama 3 gün SÜREKLİ sürerse VE yerelde gerçek ilerleme varsa yerel kayıt buluta yazılır. `data` alanı yoksa eski tek parça biçim denenir (üst düzey depo anahtarları / doğrudan ilerleme JSON'u / `progress`). İlerleme deposu çözülemezse "okunamadı"; diğer depolardan biri çözülemezse yalnız o depo için yerel hal korunur.
- **v235 ek düzeltmeler:** (1) `cloud_pre_restore_backup_v1` için geri yükleme: `CloudSaveService.restoreLocalBackup()`; Ayarlar'da "Google Play Games connected" yazısına UZUN BASINCA onay penceresi (geri almak için `..._undo` yedeği tutulur; yalnız ilerleme deposu, bölüm/seviye gibi max alanlar sonraki birleştirmede bulutla max'lanır). (2) `syncNow()` çalışan eşitlemeye katılır (aynı Future), `flushUpload` artık gerçekten bitmesini bekler. Android arka planda süreci öldürürse yine garanti yok. (3) `signedIn` her eşitleme turunda yeniden okunur (dışarıdan çıkış yapılırsa bayat kalmaz).

- **Bilinen sınır:** hesap değişiminde yeni hesabın bulutunda OLMAYAN depolar (ör. hiç Mod 2 oynamamış hesap) bellekte eski hesabın değerini korur (servislerin `load()`'ı eksik anahtarda sıfırlamıyor).
- **Eski kayıt biçimi bilinmiyor:** v228 öncesi biçimi koddan çıkarılamadı; tahmini ayrıştırma var. Gerçek eski kayıtla denenmedi.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze` (özellikle `GamesServices.getPlayerID` adı, games_services ^4.0.4). Log'da `[cloud]` satırları: "OYUNCU DEGISTI", "BULUT KAYDI OKUNAMADI".

# YENİ (v234): Hafta Sonu Etkinliği güncellemeden sonra sıfırlanıp tekrar sıfırlanma hatası
- **Sebep:** v228'de hafta sınırı Pzt 00:00 → 10:00'a kaydı. Eski sürüm Pzt 00:00'da haftayı çevirip (`w=148`) buluta yazmıştı. Yeni sürümde Pzt sabahı hafta hâlâ `147`. `PlanetEvent._roll()` "kayıttaki hafta ≠ şimdiki hafta" görünce SIFIRLIYORDU; bulut birleştirmesi de "yüksek hafta kazanır" dediği için bulut `148`'i geri getiriyor, her yüklemede yine sıfırlanıyordu (Al'a basınca kaydet → buluta yükle → geri sıfır döngüsü).
- **Düzeltme:** `PlanetEvent._roll()`: kayıt GELECEK haftaya aitse (`_weekId > id`) sıfırlama yok, yalnız hafta numarası düzeltilir. `SaveMerge.planetEvent`: haftalar farklıysa ve biri şu anki haftaysa o kazanır (`SaveMerge.planetWeekNow`, `main.dart` bağlar).
- **Test:** `save_merge_test.dart` "Hafta sonu etkinliği: hafta numarası uyuşmazlığı" (2 test).
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test test/save_merge_test.dart test/planet_event_test.dart`.

# YENİ (v231): Takım Yarışı — ilk 24 saat YALNIZ KAYIT, yarış Salı 10:00'da herkes için başlar
- **Kayıt dönemi:** hafta Pzt 10:00'da açılır; ilk `joinHours` (varsayılan **24**) saat sadece takım seçme dönemidir. Bu sürede **oynanamaz, sipariş sayılmaz, botlar 0 puanda** (`TeamRace.hasStarted/inRegistration/startsIn`). Süre dolunca (**Salı 10:00**) yarış herkes için aynı anda başlar; böylece erken/geç katılan farkı kalktı (eskiden botlar 0. saatten puan topluyordu, geç katılan geriden başlıyordu).
- **Yarış süresi** 7 gün → **6 gün** (hafta takvimi sabit; diğer etkinlikler kayma yok). Botlar `joinHours` kadar kaydırılmış saatle puanlanır (uyku/uyanık deseni korunur). Bot gücü/oyuncu üretimi birlikte ~%14 düşer, denge aynı kalır.
- **Remote:** `team_race_join_hours` artık **1..48** (eskiden 168). Yarış ortasında DEĞİŞTİRME.
- **UI:** hero sayaç kayıt döneminde "Yarış X sonra başlıyor"; takım seçen oyuncuda enerji/Oyna yerine ⏳ geri sayım kartı; takım seçici altında "Geri sayım bitince herkes aynı anda başlar". Menü rozeti: takımlı oyuncuda yarış başlayınca yanar.
- **Bildirim:** Pzt 10:00 "Takım Yarışı kaydı açıldı! 📝"; takım seçen oyuncuya Salı 10:00 "Takım Yarışı başladı! 🏆" (yeni id 64, uygulama arka plana gidince planlanır); Pazar 21:00 "bitiyor" aynı. 6 dilde çeviri eklendi.
- **Testler:** `test/team_race_test.dart` güncellendi + yeni grup "Kayıt dönemi" (5 test). Eski `join_hours=168` hileleri kaldırıldı (kayıtta seç → saati ileri al).
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test test/team_race_test.dart`. Yarış ortasında yayınlarsan kayıt süresi yeniden hesaplanır (hafta başına göre).

# YENİ (v230): Takım Yarışı Play Games bulut kaydına girdi + takıma katılma ilk 24 saatle sınırlı
- **Bulut kaydı:** `team_race_v1` artık `SaveMerge.keys/otherKeys` içinde (`SaveMerge.kTeamRace`), `TeamRace.onSaved` buluta bağlı (`main.dart`), `CloudSaveService` anlık görüntü/uygulamada `TeamRace.instance.save()` ve değişince `TeamRace.instance.load()`. Birleştirme (`SaveMerge.teamRace`): farklı koşuda DAHA YENİ koşu kazanır; aynı koşuda takım seçimi KESİN (biri seçtiyse o; ikisi farklı seçtiyse siparişi çok olan); aynı takımda sipariş delta ile toplanır; **enerji iki cihazda çoğalmaz** (düşük olan); `d` (ödülü verilen son koşu) ve `ad` (reklam bekleme) her durumda max → ödül iki kez verilmez. Yeniden kurulum/yeni telefon artık takımı ve enerjiyi sıfırlamaz.
- **Katılma penceresi:** takıma yalnız yarışın ilk `joinHours` (varsayılan **24**) saatinde katılınır (`TeamRace.canJoin`, `joinClosed`, `joinTimeLeft`; `chooseTeam` süre dolunca `false`). Uzaktan: `team_race_join_hours` (1..168; 168 = tüm hafta). Takım seçmeden 24 saat geçen oyuncu **Liderler'de sıralamayı ve üyeleri görür**, Takım Yarışı ekranında "katılım kapandı" kartı + "Takım sıralaması" butonu + ödül listesini görür; **oynayamaz, bir sonraki yarışa katılır**. Takımı olan oyuncu 24 saatten sonra da oynar. Menü rozeti: takımsızda yalnız katılım açıkken yanar.
- **Metinler:** 3 yeni anahtar, 6 dil (`Joining closes in {0}`, `Team joining is closed for this race...`, `Team joining is closed. Join the next race!`).
- **Testler:** `test/team_race_test.dart` → "Katilma suresi (ilk 24 saat)" (4 test) + "Bulut kaydi (Play Games birlestirme)" (6 test); geç katılan eski 3 test `team_race_join_hours=168` ile güncellendi.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test test/team_race_test.dart test/save_merge_test.dart`. Yarış ortasında yayınlarsan: takım seçmemiş oyuncular, yayın anı 24. saati geçmişse o yarışa katılamaz.

# YENİ (v229): TAKIM YARIŞI (botlu) – 2 haftada bir, o hafta diğer etkinlikler yok
- **Takvim** (`team_race_schedule.dart`): hafta Pzt 10:00'da döner. Hafta numarası ÇİFT ise **Takım Yarışı haftası** (Pzt 10:00 → ertesi Pzt 10:00, 7 gün); tek haftalarda eskisi gibi Merge Yarışı + Fırlat Yarışı + Hafta Sonu etkinliği. İlk takım yarışı **2 Kasım 2026 Pzt 10:00**. Uzaktan: `team_race_every_weeks` (varsayılan 2; **0 = kapalı**), `team_race_phase` (hangi haftalar). Yarış ortasında değiştirme.
- **Diğer etkinlikler bastırma:** `EventDef.runIdAt/nextRunAfter` ve `PlanetEvent.isActiveAt/startOf` yarış haftasında başlayacak koşuyu açmaz (önceki haftadan sürenler bozulmaz; tek seferlik uzaktan etkinlikler etkilenmez). ⚠️ Uzaktan eklenen `everyWeeks: 2, phase: 0` bir etkinlik çift haftalara denk gelir ve hiç çalışmaz → `phase: 1` yaz. `WeeklyEvent` (haftalık kilometre taşı) bu hafta da çalışır.
- **Yarış** (`team_race.dart`): 10 takım × 15 kişi (150 bot, tohumdan üretilir, kaydedilmez). Oyuncu bir takım seçer (onay penceresi; **seçim kesin: değiştirme ve takımdan ayrılma YOK**) ve o takıma **15. kişi** olarak katılır (takımın en yavaş botu çıkar). Puan = takımın teslim ettiği toplam **Fırlat modu siparişi**. İlk 3 takımın üyeleri ödül alır (🥇 🪙6000 💎60 ⚡60, 🥈 🪙4000 💎40 ⚡40, 🥉 🪙2500 💎25 ⚡25); oyuncu için şart: en az `team_race_min_orders` (varsayılan 10) sipariş. Ödül yarış bitince otomatik eklenir + menüde bildirim popup'ı.
- **Enerji:** takım yarışına özel; 3 enerji bedava, 45 dk'da 1 dolar, bir bölüm (tur) 1 enerji harcar (Fırlat kuralı: kazanma/kayıp/çıkış). Saatte 1 kez reklam izleyip enerjiyi tamamen doldurma. Oyun içi: `GameBoard(teamRace: true)` → siparişler `TeamRace.report`, enerji `TeamRace.spendEnergy` (ana enerji/ilerleme/yıldız etkilenmez).
- **Bot gücü:** `TeamRace.strengths` (haftaya göre takımlara karıştırılır) + `team_race_bot_pct` (100 = varsayılan). Hedef: güçlü takımlar hafta sonu ~3500, zayıflar ~1400 sipariş; ortalama bir oyuncu (~600/hafta) orta takımı ilk 3'e taşıyabilir. Dengeyi gerçek verilerle ayarla.
- **Liderler ikonu:** takım yarışı haftasında Liderler ekranının ilk sekmesi "🏆 Takım Yarışı" (10 takımın sıralaması; bir takıma dokununca 15 üyesi açılır; altta Takım Yarışı ekranına gider buton). Diğer haftalarda eskisi gibi Merge/Fırlat sekmeleri.
- **UI/Bildirim:** `team_race_screen.dart` (takım seçimi [yalnız ad+emoji], takımım + teslim ettiğim sipariş, enerji+reklam, Oyna, ödüller; **sıralama/üye listesi YOK** — diğer yarışlar gibi sıralama yalnız Liderler ekranında). Menüde 🏆 "Takımlar" ikonu (yarış haftasında; Hafta Sonu ikonu o hafta gizli). Bildirimler: yarış Pzt 10:00 "başladı", Pazar 21:00 "bitiyor" (takım seçildiyse). Çeviriler: `team_race_strings.dart` (6 dil; takım adları çevrilmez).
- **Sınırlar (v1):** durum yalnız bu cihazda (`team_race_v1`), bulut kaydına GİTMEZ. Derlenmedi/çalıştırılmadı: `flutter analyze && flutter test test/team_race_test.dart test/live_events_test.dart test/planet_event_test.dart`. Eski testler `TeamRaceSchedule.enabled = false` ile normal takvimi sınar.

# YENİ (v228): Etkinlikler sabah 10:00'da başlar, 48 saat sürer
- **Merge Yarışı:** Pzt 10:00 → Çar 10:00. **Fırlat Yarışı:** Çar 10:00 → Cum 10:00. **Hafta Sonu (Gezegen):** Cmt 10:00 → Pzt 10:00. Hepsi 48 saat, oyuncunun yerel saatiyle (internet saati).
- **Kod:** `EventDef.startHour` (varsayılan 0; uzaktan `events_json` içinde `"startHour": 10` yazılabilir). `defaultDefs` iki yarış için `startHour: 10`. Bitiş = başlangıçla aynı saat + `days` gün. Botların gün ritmi zaten `startOfRun(run).hour` kullandığı için otomatik 10'a uydu. `PlanetEvent`: `startHour = 10`, `isActiveAt/startOf/endOf/weekIdOf` 10 saat kaydırılmış takvimle çalışır (hafta Pzt 10:00'da değişir, eski gibi 00:00'da değil → son 10 saatte etkinlik erken sıfırlanmaz).
- **Bildirimler:** "Başladı" tam 10:00'da (sessiz saat dışı olduğu için kaymaz). "Bitiyor" bitişten 3 saat önce 07:00'ye denk geldiği için bir önceki akşam 21:00'e alındı (`_endWarn`; eskiden sessiz saatte ileri, 09:00'a atıyordu).
- **Haftalık etkinlik (`WeeklyEvent`) de aynı saate alındı:** hafta Pzt 10:00'da döner (kilometre taşları o an sıfırlanır), hafta sonu x2 etkinlik puanı ve sezon x1.5 çarpanı Cmt 10:00 – Pzt 10:00. Geri sayım Pzt 10:00'a. "Haftalık etkinlik bitiyor" bildirimi hâlâ Pazar 19:00.
- ⚠️ Yayınlarken: bot ritmi (başlangıç saati) değiştiği için **yarış ortasında yayınlama**. Derlenmedi / çalıştırılmadı (Flutter yok): `flutter analyze && flutter test test/live_events_test.dart test/planet_event_test.dart`.

# YENİ (v224): Ödüllü reklam, AYRI etkinlik oyunları, Liderler Sıralaması
- **Ödüllü reklam:** Ödül/işlem artık reklam KAPANIP oyuna dönülünce verilir (eskiden reklam oynarken veriliyordu). Kapanış olayı gelmezse 90 sn güvenlik zamanlayıcısı.
- **Etkinlikler ana oyundan ayrıldı:** Normal bölümler canlı etkinliğe puan yazmaz; yalnız etkinlikteki Oyna ile girilen oyun sayılır. Fırlat Yarışı: her tur rastgele ZOR bölüm + farklı tema (`EventPick`, `GameBoard.eventRun`; ana ilerleme/yıldız/bölge ödülü etkilenmez, ödül x0.25). Merge Yarışı: ayrı etkinlik tahtası (`MergeBoardService.beginEventRun/endEventRun`), ana tahta ve kayıt korunur, rastgele zor bölüm + farklı dünya.
- **Etkinlik sayfası:** sıralama/“Tüm sıralamayı gör” kaldırıldı (header → Oyna → hedefler → sıralama ödülleri).
- **Liderler Sıralaması:** ana sayfada 🏆 ikonu; aktif yarışlara göre sekmeli ilk 100 + sabit kendi sıran (`LeadersScreen`, `EventLeaderboardBody`).
- **Derleme düzeltmesi:** `ad_service.dart` `_loadVariant` null-safety (eski Dart).

# YENİ (v223): Hafta sonu etkinliğinde GEZEGEN BİRLEŞME EFEKTİ
- **Sorun:** Gezegenler birleşince biri anında yok olup yenisi beliriyordu; hızlı oyunda ne olduğu anlaşılmıyordu.
- **Şimdi (sırayla):** 1) Eski iki gezegen ~0.16 sn birleşme noktasına doğru kayıp küçülür (hayalet), 2) gezegen renginde **parlama**, 3) genişleyen **şok dalgası halkası** (kombo ≥ x2 ise ikinci, altın halka), 4) **kıvılcım/yıldız** parçacıkları (kademe yükseldikçe daha çok; en çok 240 parçacık), 5) kademe ≥ 6 (Gaia ve üstü) birleşmelerinde tahta **hafifçe sarsılır**. Yeni oluşan gezegen küçük başlayıp %28 aşarak yerine oturur ("pop" eğrisi). İki Karanlık Kutle'nin yok oluşu (+150) çok daha büyük, renkli patlamadır.
- **Kod:** yeni `lib/widgets/planet_merge_fx.dart` (`PlanetMergeFx`: `spawn/update/paintBelow/paintAbove`), `PlanetMergeEvent`'e `parentTier/ax/ay/bx/by` eklendi (`planet_physics.dart`), `planet_game_screen.dart` içinde `_fx` bağlandı. **Fiziğe, skora ve kayda DOKUNULMADI** — yalnızca çizim.
- **Ayar:** süreler/sayılar `planet_merge_fx.dart` başında ve `spawn()` içinde (kıvılcım sayısı `12 + kademe*2`, titreşim `tier >= 6`). Çok yavaş telefonda takılma olursa `_maxSparks` değerini 240 → 120 yap.
- Test: `test/planet_event_test.dart` → "Birlesme efekti (v223)" (3 test).
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok): `flutter analyze && flutter test test/planet_event_test.dart`. Telefonda bak: efekt çok mu abartılı/az mı, kombo zincirinde ekran fazla kalabalık oluyor mu.

# YENİ (v221): Üreticiyi sürükle-bırak + yeni (yan) üretici öğreticisi
- **Üretici artık sürüklenir (Merge Tahtası):** Tahtadaki üretici sandığı (Fast Food, Kafe...) basılı tutup sürükleyerek HERHANGİ bir kareye bırakılabilir. Dokunuş = üret (eskisi gibi), sürükle = taşı, uzun basış = yükseltme penceresi (eskisi gibi, sürüklemeden basılı tutunca).
  - Hedef kare boşsa üretici oraya geçer; hedefte obje varsa obje üreticinin eski karesine gelir (kayıp yok); iki üretici birbirinin üstüne bırakılırsa yer değiştirirler.
  - Taşınan üreticinin yeni karesine obje konmaz/sürüklenmez; objeler yine üreticinin YENİ konumuna yakın çıkar.
  - Konum kayda yazılır (`gp` anahtarı, yalnızca varsayılandan farklıysa; eski kayıtlar etkilenmez, bozuk kayıtta varsayılana döner). Henüz açılmamış üreticinin konumu da tutulur (3 konum her zaman farklı): yeni üretici başka bir üreticinin üstüne binmez, o karedeki obje kenara taşınır.
  - Kod: `MbBoard.genPos` / `moveProducer` / `genCellOf` / `nearestFreeCell` (`lib/models/merge_board.dart`), `MergeBoardService.moveProducer`, ekranda `Draggable<_ProdDrag>` + hücre `DragTarget<Object>` (`merge_board_screen.dart`). `MbWorlds.producerCells` artık yalnız VARSAYILAN konumlar.
- **Yeni üretici öğreticisi:** Yan üretici (ör. Fast Food dünyasında Kafe, 5. bölümde) açılınca: 1) üretici parlar + balon "Yeni üretici: Kafe! Eşya almak için dokun." (oyuncu dokunup obje çıkarınca biter), 2) ardından **sürükleme ipucu**: el animasyonu üreticiden en yakın boş kareye gider, "İpucu: Üreticiyi basılı tutup sürükleyerek istediğin kareye taşıyabilirsin!" (oyuncu taşıyınca biter, 12 sn sonra kendiliğinden kapanır, `Geç` her adımda var).
  - Her yan üretici (slot 1, 2) için BİR kez gösterilir (`mb_tut_prod1/2`), sürükleme ipucu toplam bir kez (`mb_tut_pdrag`; ureticiyi kendisi taşıyan oyuncuda da işaretlenir). Ana öğretici bitmeden ve bölüm bitti penceresi/hikaye açıkken beklemeye alınır. Daha önce yan üreticiyi açmış mevcut oyuncular da güncellemeden sonra bir kez görür.
  - 2 yeni metin, 6 dilde (`New producer: {0}! Tap it to get items.`, `Tip: hold and drag a producer to move it anywhere!`). Analytics: `mb_tut_prod_start/tap/skip/done`, `mb_producer_move`.
- Testler: `test/mb_producers_test.dart` içine 5 yeni test ("v221:").
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok). FlutLab'da dene: 5. bölüme gel (ya da `mb_tut_prod1` / `mb_tut_pdrag` kayıtlarını sıfırla), Kafe üreticisinin öğreticisini ve sürüklemeyi test et; sonra `flutter test test/mb_producers_test.dart`.

# YENİ (v220): Öğreticide güçlendirici (booster) tanıtımı
- **Yeni adım (`_CoachStep.boosters`):** Bölüm 1 rehberinde ilk atış yapılınca (Adım 1: Fırlat) artık doğrudan birleştirmeye geçilmez; önce 5 güçlendirici tanıtılır: Nişan Rehberi, Joker Top, Çekiç, Yükselt, Pervane. Sıra: Fırlat → **Güçlendiriciler** → Birleştir → Teslim.
- **Nasıl görünür:** Tahta karartılır, alt çubuktaki 5 buton gösterilir, anlatılan buton parlar (diğerleri soluk). Üstte kart: ikon + isim + açıklama (mevcut `booster_*_name/_desc` metinleri), ilerleme noktaları, `Sonraki` / son kartta `Anladım!`. Kartın oku seçili butonu gösterir. Oyuncu butonlara dokunarak da istediği butona atlayabilir. Bu adımda butonlar gerçekten KULLANILMAZ (stok/elmas harcanmaz), tahtaya dokunuş yutulur.
- **Kapsam:** İlk kez oynayanlar + Nasıl Oynanır "pratik" tekrarı. Eski oyuncular etkilenmez (`ch1_steps` zaten görülmüş).
- **Dil:** 3 yeni anahtar (`tut_boosters_title`, `tut_booster_next`, `tut_booster_done`), 7 dil.
- **Analytics:** `tut_step1b_boosters` huni olayı eklendi (Fırlat ile Birleştir arasında).
- Dokunulan dosyalar: `lib/widgets/game_board.dart`, `lib/localization/app_strings.dart`, `lib/localization/translations.dart`, `lib/services/analytics_service.dart`.
- ⚠️ Derlenmedi / çalıştırılmadı (bu ortamda `flutter` yok). FlutLab'da derleyip ilk kez oynama akışını (yeni kayıt / pratik) bir kez dene.

# YENİ (v219): Botlar güçlendirildi (insan/bot dengesi)
- Aktif insan botlardan 3-5 kat fazla puan yapıyordu. `LiveEvents.defaultDefs` içinde bot hızları artırıldı: **Fırlat** `0.1-4.5` → `0.35-21.0` (×~4,7 üst uç; ilk 10 ≈ 860, 100. ≈ 600, ortanca ≈ 100), **Merge** `0.02-0.5` → `0.042-1.05` (×~2,1; ilk 10 ≈ 42, 100. ≈ 30, ortanca ≈ 5). Dağılım şekli (gamma 3), gün ritmi, kimlikler aynı.
- Simülasyonla (48 saat, 1500 bot) beklenen sıralama eşikleri — Fırlat: ilk 10 ≈ 560-650, 100. ≈ 460, 300. ≈ 290, ortanca ≈ 75 (eski 177/131/82/22). Merge: ilk 10 ≈ 55-65, 100. ≈ 44, 300. ≈ 28, ortanca ≈ 8 (eski 20/15/9/3).
- Sonradan ince ayar (güncelleme GEREKMEZ): Remote Config `ev_race_mod1_bot_pct` / `ev_race_mod2_bot_pct` (100 = bu yeni varsayılan; 120 = %20 daha hızlı, 85 = %15 daha yavaş). Yarışlar arasında değiştir.
- ⚠️ Yarış ortasında yayınlama (bot puanları kayar). Derlenmedi; `flutter test test/live_events_test.dart` çalıştır (testler mutlak hıza bağlı değil).

# YENİ (v218): Fırlat reklamı = tam enerji + reklam butonunda canlı bekleme sayacı + daha inandırıcı botlar
- **Fırlat (Mod 1) enerji reklamı:** `GameProgress.claimEnergyAdReward()` artık +1 yerine enerjiyi TAM doldurur (5/5, dolum sayacı sıfırlanır). Kota aynı: 2 saatte 5 hak, 5. reklamdan sonra 2 saat kilit. Onay penceresinde ödül `⚡ MAX`, buton `Watch Ad · Full ⚡` (6 dil). Mod 2 enerjisi değişmedi (+25).
- **Canlı bekleme sayacı (`energy_bar.dart`, `AdService.cooldownLeftFor`):** enerji popup'ında 60 sn reklam beklemesi sürerken reklam butonu pasif ve `⏳ 00:42` gösterir (Fırlat'ta yanında `(kalan/5)`), saniyede bir tazelenir; bitince normale döner. 2 saatlik kota kilidi sayacı da artık canlı akar. Popup otomatik KAPANMAZ (bilerek).
- **Botlar (`bot_identity.dart`, `live_events.dart`):**
  1. **Seviye hıza bağlı:** `BotIdentity.make(..., fast01)`; en hızlı botlar ~Lv.33-52, yavaşlar ~Lv.7-16 (eski: hızdan bağımsız).
  2. **İsim havuzu genişledi:** ~130 TR + 80 yabancı isim, ~70 takma ad kelimesi, soyad/çift isim; yeni stiller: rakamsız küçük harf (`berk`), `Mert Y.`, `mert_yilmaz`, il plakası/doğum yılı/takım yılı ekleri (`emre34`, `emre1905`), gamer kalıpları (`xXWolfXx`, `its_emre`, `TheNova`), `oyuncu123`/`user48213`/`misafir77`, klavye gelişigüzeli (`kjhs23`).
  3. **Gün ritmi:** `hourRate` uyanık olma olasılığı saate bağlı (gece 2-5 çok düşük, 19-22 en yoğun; ortalama 1.0'a normalize → ekonomi/dağılım aynı). Her botun saat dilimi kayması (`LiveEvents.tzShiftFor`: %82 -2..+2 saat, kalanı dünyanın her yerinden). Kosunun baslangic saati `startHour` ile gelir.
  4. **Kümeli puan akışı:** 3 saatlik oturum blokları + saat içinde 4 çeyrekten bazıları boş (`_withinHour`, `hourAmount`). Puan dakika dakika düz akmaz. `_BotBoard` ile `botScoreAt` HÂLÂ birebir aynı (ikisi de `hourAmount`).
  5. **Cihaza özel tohum:** `LiveEvents.botSalt` (kurulumda bir kez üretilir, `bot_salt_v1`, `main.dart`'ta `initBotSalt()`). İki oyuncu ekran görüntüsü karşılaştırınca aynı isim/puan listesini görmez. Testlerde 0 (eski davranış).
- ⚠️ Botlar için bu güncelleme sıralamaların hesabını değiştirir: **yarış ortasında yayınlama** (Pzt-Sal Merge, Çar-Per Fırlat). Yarışlar arasındaki boşlukta (Cum-Paz) yayınla, yoksa devam eden yarışta oyuncunun sırası/isimleri birden değişir.
- ⚠️ Derlenmedi / çalıştırılmadı (`flutter test`/`analyze` yok). Yeni testler `test/live_events_test.dart` (grup "Botlar", "v218:" ile başlayanlar).

# YENİ (v217): Reklam bulunamazsa ödül yok + 60 sn reklam beklemesi
- **Reklam yoksa ödül yok:** `AdService.rewardOnNoFill = false`. Reklam doluluğu yok / SDK hazır değil / gösterim başarısız / 15 sn watchdog durumlarında ödül VERİLMEZ ve oyunun kendi popup'ı açılır: "Şu an reklam bulunamadı. Lütfen tekrar dene." (Tamam'a basılınca kapanır, `showGamePopup(autoCloseMs: 0)`). İnternet yok durumu eski mesajıyla kalır.
- **60 sn bekleme:** iki ödüllü reklam arasında (YER BAZLI: aynı yer 60 sn içinde tekrar izlenemez; Salla/Değiştir/Sil tek sayaç paylaşır). Ana sayfa + mağaza **bedava elmas** (`free_gems`) HARİÇ. Sayaç reklam İZLENİNCE başlar, monotonik saatle (cihaz saati oynansa etkilenmez), uygulama kapanınca sıfırlanır. Bekleme sürerken butona basılırsa popup: "Başka bir reklam izlemek için N saniye bekle." Süre Remote Config `ad_cooldown_sec` ile değişir (varsayılan 60).
- 2 yeni metin, 6 dilde.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze`. Telefonda bak: uçak modu dışında reklam engelli (DNS) cihazda popup, 2 reklamı arka arkaya izlemeyi dene.

# YENİ (v216): Bulut kaydı düzeltmeleri + hafta sonu etkinliğine "Toplam 350.000 puan" görevi
- **Hafta sonu etkinliği (Gezegen Birleştir):** 7. görev eklendi: *Etkinlik boyunca toplam 350.000 puan topla* → 🪙5000 💎40 ⚡50 (`PlanetEvent.targetTotalScore`, `tasks` listesinin SONUNA eklendi; alınmış görev indeksleri bozulmaz). Toplam puan `totalScore` ('ts' anahtarı), oyun başına yalnızca puan ARTIŞI eklenir (`startRun` sayacı sıfırlar). Büyük ödül artık 7 görevin hepsini ister. Bulutta `ts` delta ile toplanır (`SaveMerge.additive[kPlanetEvent]`). 6 dilde yeni metin.
- **Reklam kotası birleştirmesi (`SaveMerge._quota`):** cihaz saati yerine `SaveMerge.clock` (main.dart'ta `TimeService.now`'a bağlı) → saat oynayınca haklar bedavaya yenilenmez; iki cihazdaki reklamlar delta ile toplanır (tavan 3 / 5); tavana ulaşıp sayaç yoksa bekleme sayacı başlar.
- **Çekiç / Yükselt / Pervane** (`boosterHammer/Upgrade/Fan`) artık toplamsal (delta) birleşir.
- `boosterAdDay+Count`, `adQuotaDay+adQuota` gün-grubu olarak birleşir; `missionDayAddW/M` haftalık/aylık görev grubuna alındı.
- `rebase`: sezon/etkinlik "alınmış" listeleri ve hafta sonu `cl`/`gc` eşleşme sırasında kaybolmaz.
- Bedava elmas reklamı: ekran kapanmış olsa bile ödül verilir (`!mounted` kontrolü ödülden sonraya alındı).
- Testler: `save_merge_test.dart` (`quotaMergeTests`), `planet_event_test.dart` (toplam puan).
- ⚠️ **Derlenmedi / çalıştırılmadı** (bu ortamda Flutter yok): `flutter analyze && flutter test test/save_merge_test.dart test/planet_event_test.dart`.

# YENİ (v207): Etkinlik bildirimleri + bildirimlerde oyun ikonu
- **Yeni yerel bildirimler** (`NotificationService.scheduleAll`, uygulama arka plana gidince planlanır; sessiz saat 22-09 kuralı geçerli):
  - **"Başladı"**: Merge Tahtası Yarışı, Fırlat Yarışı ve Hafta Sonu etkinliği için, sıradaki koşunun açılışında (gece 00:00'da açılanlar 09:00'a kayar). `LiveEvents.defs` üzerinden döner → Remote Config `events_json` ile eklenen etkinlikler de otomatik.
  - **"Bitiyor"**: bitişten 3 saat önce (sessiz saate denk gelirse kayar, bitişe ≤30 dk kalırsa atlanır). Yarışlarda yalnızca PUANI > 0 olana; Hafta Sonu'nda büyük ödül alınmadıysa. Ödüller bitince zaten otomatik eklendiği için "ödülleri topla" yerine "son şans: puanını yükselt, hedeflerini tamamla" metni kullanıldı.
  - Bildirim kimlikleri: başladı 20-31, bitiyor 40-51, Hafta Sonu 60/61 (mevcut 1-6 ve 10-15 ile çakışmaz).
  - 4 yeni metin, 6 dilde (tr/es/pt/de/fr/ru; en anahtarın kendisi).
- **Oyun ikonu:** tüm yerel bildirimlere renkli büyük ikon (`largeIcon`: `res/drawable-nodpi/ic_notif_large.png`, launcher ikonundan). Küçük ikon (durum çubuğu) zaten `ic_stat_notify`. `raw/keep.xml`'e `@drawable/ic_notif_large` eklendi (shrinkResources silmesin).
- ⚠️ Sunucudan gelen **FCM push**'larda büyük ikon manifestten verilemez (Android yalnızca küçük ikon + renk için varsayılan kaynak kabul eder; küçük ikon zaten ayarlı). Büyük ikon/görsel istenirse push'ta `image` alanı gerekir.
- ⚠️ **Derlenmedi / çalıştırılmadı** (bu ortamda Flutter yok): `flutter analyze`. Telefonda test: Pzt/Çar sabahı "başladı", Salı/Perşembe 21:00 "bitiyor" (puanın varsa), Cumartesi 09:00 hafta sonu.

# YENİ (v206): Yarış botları artık bot gibi görünmüyor
- **İsimler:** 16 sabit Türkçe isim yerine ~90 isimlik karışık havuz (%60 Türkçe, %40 yabancı) + 6 yazım stili: düz isim (`Elif`), rakamlı (`emre34`, `Elif07`), `Mert_B` / `zeynep.k`, takma ad (`Nova99`, `PixelWolf`), yıllı (`kaan_1998`). Aynı sıralamada tekrar yok. Kod: `lib/models/bot_identity.dart`.
- **Avatar:** 10 renk, %55 olasılıkla hayvan/simge emojisi, yoksa baş harf.
- **Seviye:** her botun `Lv.X` rozeti (7-51, düşük seviyelere yatık). Oyuncunun seviyesine bağlı DEĞİL (koşu sırasında değişmesin); oyuncu satırında kendi seviyesi görünür.
- **Kişilik:** her bota ±%15 "uyanık olma" farkı (`BotProfile.awakeAdj`): biri düzenli, biri seyrek oynar. `hourRate`/`botScoreAt` varsayılan davranışı değişmedi (yeni opsiyonel parametre).
- Her şey tohumdan üretilir (kayıt yok): aynı koşu = aynı botlar, her koşuda farklı kişiler. Uyarı: eski isimler değişti; çalışan bir koşu varsa botların isimleri güncellemeden sonra değişir.
- Testler: `test/live_events_test.dart` içine 3 yeni test (kimlik sabit/tekrarsız, stil karışımı, kişilik monoton).
- ⚠️ **Derlenmedi / çalıştırılmadı** (bu ortamda Flutter yok): `flutter analyze && flutter test test/live_events_test.dart`.

# YENİ (v205): Ana sayfada yarış ikonları + yan ikonlar küçüldü
- **Yarış ikonları:** Merge Tahtası Yarışı (🧩) ve Fırlat Yarışı (🎯) artık ana sayfada, sağ sütunda Etkinlik ikonunun altında. **Yalnızca etkinlik AÇIKKEN görünür, bitince kaybolur** (menü zaten saniyede bir yenileniyor, ek zamanlayıcı yok). Köşede sıra rozeti (`#3`), alınabilir hedef varsa kırmızı `!`.
- **Tıklayınca (`LiveEventScreen`)**, Hafta Sonu etkinliği ekranı gibi: üstte başlık kartı (geri sayım, puan, sıra) → **Oyna** butonu → **Hedefler** (Al butonlu) → **Sıralama** → Sıralama ödülleri. Oyna: Merge Tahtası yarışında `MergeBoardScreen`, Fırlat yarışında `LevelMapScreen` açar; dönünce puan/sıra tazelenir.
- **Genel:** ikonlar `LiveEvents.activeDefs`'ten gelir; yani Remote Config `events_json` ile eklenen yeni etkinlikler de aynı şekilde ana sayfada görünür (emoji: `eventEmoji`, kısa ad: `eventMenuLabel`).
- **Bitiş bildirimi:** menüdeyken etkinlik biterse ödül popup'ı hemen çıkar (`_watchLiveEvents`); eskiden menüye yeniden girmek gerekiyordu.
- **Yan ikonlar küçüldü:** `_SideIcon` 68→56 daire, sütun 84→72, yazı 13→11.5, ikonlar arası 10→8; `_OfferIcon` 74→62. Alt dock'a dokunulmadı.
- Yeni çeviri anahtarı: `Merge Race` (6 dil).
- ⚠️ **Derlenmedi / çalıştırılmadı** (bu ortamda Flutter yok): `flutter analyze`. Telefonda bak: Salı/Perşembe günü ikon görünüyor mu, sağ sütun küçük ekranda sığıyor mu.

# YENİ (v193): Genel canlı etkinlik motoru (veri tabanlı) — Sipariş Yarışı bunun üzerinde
- **Fikir:** Bir etkinlik artık KOD değil VERİ: `EventDef` (kimlik, sayılan metrik, hangi gün/kaç gün/kaç haftada bir, hedefler, isteğe bağlı botlu sıralama + sıralama ödülleri). Motor (`lib/models/live_events.dart`, `LiveEvents`) hepsini aynı şekilde yürütür. Ekran: `live_event_screen.dart` (tek ekran, tanıma göre).
- **Varsayılanlar:** `race_mod2` (Pzt-Sal, Merge Tahtası siparişi) ve `race_mod1` (Çar-Per, Fırlat siparişi), 5 botlu. Sayılar `LiveEvents.defaultDefs` içinde (BAŞLANGIÇ TAHMİNİ, ilk haftalarda ayarla).
- **Metrikler** (`EventMetric`): `order_mod1` (Fırlat siparişi, pratik hariç), `order_mod2` (Merge Tahtası siparişi tamamlanınca), `merge_mod1` (Fırlat birleştirme), `combo_mod1` (Fırlat kombo). Yeni metrik = `EventMetric`'e sabit + oyunda ilgili yere `LiveEvents.instance.report(EventMetric.xxx, 1)`. Hook'lar: `GameProgress.reportOrderDelivered/reportMerge/reportCombo`, `MergeBoardService.deliver`.
- **Uzaktan etkinlik (uygulama güncellemesi GEREKMEZ):** Firebase Remote Config'e `events_json` parametresi (metin). Kod çalıştırmaz, yalnızca veri okur; sayılar sınırlanır, geçersiz JSON yok sayılır, en fazla 12 etkinlik. Aynı `id` varsayılanı EZER, `{"id":"race_mod1","off":true}` varsayılanı KAPATIR, yeni `id` eklenir. Örnek:
  `{"events":[{"id":"merge_fest","metric":"merge_mod1","startWeekday":6,"days":2,"title":{"en":"Merge Fest","tr":"Birleştirme Şenliği"},"goals":[{"t":100,"c":500},{"t":300,"c":1500,"g":10},{"t":600,"c":3000,"g":20}]}]}`
  Botlu sıralama için: `"bots":{"speeds":[1,2,3,5,7],"awake":0.65,"burst":0.1,"burstMul":2.5}` ve `"ranks":[{"c":3000,"g":30},{"c":2000,"g":20}]`. Alanlar: `startWeekday` 1=Pzt..7=Paz, `days` (en fazla 7*everyWeeks ve 14), `everyWeeks`/`phase` (örn. 2 haftada bir), ödül `c` coin / `g` elmas / `e` enerji (üst sınırlar: 50000 / 200 / 200).
- **Bot hızı ayarı:** Remote Config `ev_<id>_bot_pct` (yüzde, 100 = varsayılan), örn. `ev_race_mod2_bot_pct`. Etkinlik SIRASINDA `events_json` ya da bot yüzdesini değiştirme (bot puanları/hedefler anında kayar); etkinlikler arasında değiştir.
- **Botlar:** puanları SAKLANMAZ; `LiveEvents.botScoreAt` ile (etkinlik, koşu, saat) tohumundan hesaplanır (saatlik uyku/uyanık, ara sıra hızlı oyun). Sunucusuz, deterministik. Oyuncu eşitlikte öndedir.
- **Ödül:** hedefler etkinlik içinde "Al" ile; sıralama ödülü ve alınmamış hedefler etkinlik BİTİNCE otomatik eklenir (puanı 0 olana verilmez), menüde bir kez bildirim. Etkinlik kartları Etkinlik (kupa) ekranının üstünde (açık olanlar + sıradaki).
- **Kayıt/bulut:** tek anahtar `live_events_v1`, düz yapı (`<id>.r/.s/.dr/.cl`); `SaveMerge.liveEvents` her etkinliği bağımsız birleştirir (puan delta ile toplanır, `dr` max → iki cihazda çift ödül yok). v192'deki `race_event_v1` kaldırıldı (v192 dağıtılmadıysa kayıp yok).
- **Dokunulmadı:** `WeeklyEvent` ve `PlanetEvent` bu motora TAŞINMADI (yayındaki oyuncu kayıtlarını bozmamak için). İstersen sonra, kayıt göçüyle birlikte taşırız.
- ⚠️ **Derlenmedi / çalıştırılmadı** (bu ortamda Flutter yok): `flutter analyze && flutter test test/live_events_test.dart`. Telefonda bak: Etkinlik ekranındaki kartlar, etkinlik ekranı, bitişte açılış popup'ı, `events_json` ile test etkinliği.
- Not: Mod 2 sipariş teslimleri haftalık etkinliğin "sipariş" hedefine SAYILMIYOR (yalnız Mod 1); bu sürümde değiştirilmedi.

# YENİ (v191): Etkinlik oyun alanı "Ufolar" teması + ses/titreşim
- **Arka plan:** AstroFelyx'in "Ufolar" teması kodla çizilir (`lib/widgets/ufo_background.dart`; görsel dosyası yok): yıldız alanı, kayan yıldızlar, 2 dekor gezegen, uçan UFO'lar (büyük olanın kubbesinde el sallayan uzaylı). Oyun ekranının tamamının arkasında; tahta zemini %60 saydam, UFO'lar arkadan görünür.
- **Yeni sesler** (AstroFelyx'ten WAV'a çevrildi, toplam ~130 KB): `pe_combo_1..5` (kombo halkası yükseldikçe perde artar), `pe_land` (iniş), `pe_shake` (Salla), `pe_swap` (Değiştir). `GameFx.planetCombo/planetLand/planetShake/planetSwap`; `SfxService.names` + `pubspec.yaml` güncellendi.
- **Titreşim:** kombo x2-3 hafif, x4-5 orta, x6+ çift güçlü; iniş (hızlıysa) hafif; Salla üçlü; yığın tehlike çizgisine yaklaşınca kalp atışı gibi hafif titreşim (`tensionPulse`). Mevcut: fırlatma, birleşme (kademeye göre), yeni en iyi gezegen, oyun sonu, butonlar.
- **İniş sesi** fizik temas dinleyicisi olmadan, bırakılan gezegenin dikey hızındaki ani düşüşten algılanır (yaklaşık; his tutmazsa `planet_game_screen.dart` içindeki 45 / 0.4 eşikleri).
- Müzik: oyunun genel döngüsü (`MusicService`) etkinlikte de çalmaya devam eder (ayrı müzik yok).
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`. Telefonda bak: UFO'ların performansa etkisi (düşük cihaz), iniş sesinin zamanlaması.

# YENİ (v190): Gezegen Birleştir güçlendiricileri
- Oyun alanının altında 3 düğme: **Salla** (tüm gezegenlere küçük itme; sıkışan yığını gevşetir), **Değiştir** (eldeki ile sıradaki gezegeni değiş tokuş; ikisi aynıysa harcatmaz), **Sil** (bir gezegene dokun, o kaldırılır).
- Her kullanım **reklam izleyerek YA DA mücevherle**: Salla 20 💎, Değiştir 15 💎, Sil 25 💎 (`PlanetConfig.powerShakeGems/powerSwapGems/powerDeleteGems`, AstroFelyx fiyatları). Ödeme penceresi açıkken fizik durur. Sil'de ödeme gezegen seçildikten SONRA sorulur (vazgeçersen para gitmez).
- Kodda: `PlanetWorld.shake/bodyAt/removeBody`, `planet_game_screen.dart` (`_payForPower`, `_PowerDialog`). Loglar `[planet_game]`, analitik `pe_power {kind, via}` (yalnız cihazda sayılır). Testler: `planet_event_test.dart`.
- ⚠️ Derlenmedi / çalıştırılmadı: `flutter analyze && flutter test`.

# YENİ (v189): Hafta sonu etkinliği "Gezegen Birleştir" (Suika tarzı)
- **Ne:** Cumartesi 00:00 – Pazar 23:59 (48 saat, `TimeService` ile). Ana menüde **sağ ikon sütununun en altında** (gezegen ikonu; hafta içi soluk, etkinlikte enerji çipi). `eventUnlockLevel` (7) altındaki oyuncuda görünmez.
- **Giriş:** etkinliğe özel enerji: en fazla **3**, oyun başına 1, **45 dk'da 1** dolar. Tamamı **reklamla** (etkinlik başına en fazla 6) ya da **50 💎** ile dolar. Oyun bitince "Tekrar oyna" 1 enerji harcar; "Devam et (reklam)" üstteki 6 gezegeni temizler (oyun başına 1 kez).
- **Görevler (etkinlik boyunca birikir):** Neptün / Uranüs / Satürn'e ulaş, 3 kez x6 kombo, toplam 2500 birleştirme, tek oyunda 4200 puan + hepsi bitince büyük ödül. Ödüller coin / 💎 / Mod 2 ⚡ (`PlanetEvent.tasks`, `grandReward`; tüm sayılar `lib/models/planet_event.dart` başında).
- **Teslim:** her görev "Al" ile alınır. Etkinlik bitince alınmamış tamamlanmış ödüller bir sonraki açılışta **otomatik** hesaba eklenir ve menüde bir kez bildirim çıkar.
- **Kod:** `lib/services/planet_physics.dart` (forge2d 0.13 ile AstroFelyx fiziğinin sadeleştirilmiş uyarlaması; Fırlat modunun fiziğine dokunmaz), `lib/models/planet_event.dart`, `lib/screens/planet_event_screen.dart` (hub), `lib/screens/planet_game_screen.dart` (oyun). Görseller `assets/images/planet/pl_0..12.webp` (256 px, toplam ~160 KB; AstroFelyx PNG'lerinden çevrildi).
- **Kayıt/bulut:** `planet_event_v1` → `SaveMerge.planetEvent` (aynı hafta: birleştirme/oyun sayısı delta ile toplanır, en iyi değerler max, alınan ödüller birleşim, enerji = düşük olan taraf; farklı hafta: yenisi kazanır). Oyun akışı kaydı buluta yükleme tetikler (`PlanetEvent.onSaved`).
- **Analitik:** özel olaylar Firebase'e gitmiyor (v188), yalnızca cihazda sayılır: `pe_open`, `pe_run_start`, `pe_run_end`, `pe_run_quit`, `pe_refill_ad`, `pe_refill_gems`, `pe_claim`, `pe_continue`, `pe_auto_deliver`. Loglar: `[planet]`, `[planet_game]`.
- **Testler:** `test/planet_event_test.dart` (fizik birleşmesi/kombo, enerji yenilenmesi, görevler, otomatik teslim, bulut birleştirme).
- ⚠️ Derlenmedi / çalıştırılmadı (Flutter yok): `flutter analyze && flutter test`. Telefonda bak: sürükleyip bırakma hissi, gezegen boyutu/ağırlığı (`PlanetConfig`), 4200 puan / Satürn hedefinin zorluğu, Cumartesi 00:00 geçişi.
- Bilinen sınır: iki cihaz çevrimdışıyken aynı biten etkinliğin otomatik teslimi ikisinde de çalışırsa ödül iki kez eklenebilir (çok nadir).

# YENİ (v188): Firebase özel olayları kapatıldı, bulut kaydı eksikleri, log
- **Firebase:** Özel olaylar (`tut_*`, `mb_*`, `ad_*`...) artık Firebase'e GÖNDERİLMEZ (parametreleri konsolda elle tanımlamak gerekiyordu). Firebase yalnız kendi otomatik metriklerini toplar (D0/D1/D7 retention, bölge, oturum). `AnalyticsService` olayları yalnızca cihazda sayar (Ayarlar > "Nasıl oynanır?" uzun basma özeti aynen çalışır). Geri açmak için `lib/services/push_service.dart` içindeki yorumdaki `sink` satırı.
- **Play Games bulut kaydı (hata düzeltmesi):** Mod 2 tahtası "ileride olan taraf komple kazanır" ile birleşiyordu; üretici yükseltme seviyeleri (`pl`) tahtayla birlikte kayboluyordu (coin harcanmış, yükseltme gitmiş). Artık `pl` zincir bazında **max** ile birleşir (`SaveMerge._withBestProducers`, `rebase` dahil). Yeni test: `test/save_merge_test.dart > producerLevelMergeTests`.
- **Bulut kaydı (tetik):** Mod 2 görev ilerlemesi yazılınca da yükleme tetiklenir (`MbMissions.onSaved`, `main.dart`). Önceden yalnız başka bir kayıt tetikleyince buluta giderdi.
- **Log:** bulut yazımında boyut/bölüm/coin/elmas/Mod 2 bölüm/üretici seviyeleri, buluttan uygulanan değişiklikler (önce→sonra), yarım kalan yazmanın kurtarılması, üretici seviyesi birleşmesi; sezon/kumbara/etkinlik/engage yükleme özetleri; Firebase durumu. `AppLog.build` = `v188-cloud-pl`.
- ⚠️ Derlenmedi / çalıştırılmadı (Flutter yok): `flutter analyze && flutter test`. Telefonda bak: iki cihazda biri üretici yükseltirken diğeri bölüm ilerletince yükseltme geri gelmiyor mu; Ayarlar > Hata Kayıtları'nda `[cloud]` satırları.

# YENİ (v186): Üretici kilitleri dünya akışına göre sabitlendi
- **Değişiklik:** `MbWorlds.unlockChapter` `[1, 3, 6]` → `[1, 5, 7]`. Her dünyada 1-4. bölüm yalnız ana üretici (dünyanın KENDİ zinciri: Kafe dünyasında Kafe), 5. bölümde 2., 7. bölümde 3. üretici. Yeni dünyaya geçince yine 1 üreticiyle başlanır, önceki dünyanın zinciri 5. bölümde geri gelir.
- **5. bölüm yumuşatıldı** (2. üretici + altın bölüm aynı anda): Lv3-4 sipariş (Lv5 yok), hedef 6 → 5 sipariş. 6. bölümde Lv3-5 ve hedef 6 geri gelir. Sadece genel 5. bölüm (ilk dünya); sonraki dünyalar zaten Lv4-5 ile devam eder.
- **Enerji (bar 100, üst sınır 200, 90 sn) ve %8/%5 yükseltme bonusları DEĞİŞMEDİ.**
- **Not:** Üretici seviyesi zincire bağlı; eski zincirde yükseltme yapan oyuncu yeni dünyada ilk 4 bölüm yeni ana zincirin Lv1 üreticisiyle oynar, eski zincir 5. bölümde Lv'siyle döner.
- **Testler güncellendi:** `test/mb_producers_test.dart` (kilit tablosu, 4→5. bölümde yeni üretici, `_board(5)` / `_board(23)`).
- ⚠️ Derlenmedi / çalıştırılmadı (Flutter yok): `flutter analyze && flutter test`. Telefonda bak: 4. bölüm bitince 2. sandık beliriyor mu, 7. bölümde 3. sandık, Kafe dünyasında 1. bölüm tek sandık mı.

# YENİ (v185): Mod 2 — dünya başına 2-3 ÜRETİCİ, karışık siparişler, üretici yükseltme
- **Fikir:** Büyük merge oyunlarındaki gibi (Merge Mansion, Travel Town): tek sandık yerine dünyanın içinde birden çok üretici, siparişler hepsinden KARIŞIK kalem ister, her üretici yükseltilir. Her dünya yine AYRI (arka plan/tema bölüm numarasından gelir), tahta tek ve kalıcı.
- **6 tema = 6 zincir.** Dünya → zincirler tablosu: `MbWorlds.chains` (`lib/models/merge_board.dart`): Fast Food `[FF, Kafe]`, Kafe `[Kafe, FF]`, Büyü `[Büyü, Kafe, FF]`, Korsan `[Korsan, Büyü, Kafe]`, Buz `[Buz, Korsan, Büyü]`, Uzay `[Uzay, Buz, Korsan]`. İlki dünyanın ana zinciri; önceki dünyaların zincirleri geri gelir (ilk dünyada Kafe tanıtım olarak).
- **Kilit:** dünya içindeki 1-4. bölümde yalnız ana üretici; **5. bölümde 2. üretici**, **7. bölümde 3. üretici** açılır (v186) (`MbWorlds.unlockChapter`). Hücreler: ana 26 (orta), 2. üretici 27 (sağı), 3. üretici 25 (solu) (`MbWorlds.producerCells`). Açılan hücrede obje varsa en yakın boş hücreye taşınır. Bölüm bitiş penceresinde "Yeni üretici açıldı!" satırı çıkar.
- **Kodlama (kayıt uyumlu):** hücre/sipariş kalemi değeri = `slot*10 + seviye` (slot 0 = dünyanın ana zinciri). Eski kayıtlarda slot hep 0 → hiçbir migrasyon gerekmedi. Yardımcılar: `MbBoard.lv / slotOf / enc / validItem`. Birleşme yalnız AYNI zincir + seviye.
- **Siparişler:** açık üreticilerin zincirlerinden karışık (ana zincir 2 pay, diğerleri 1'er). `maxOrderCost` aynı kaldı (maliyet zincirden bağımsız Lv1 eşdeğeri). Tek üreticide rastgele sayı tüketilmez (eski tohumlu testler değişmedi).
- **Dünya değişince:** objeler ve yarım siparişler yeni dünyanın slot sırasına çevrilir (`MbBoard.remapWorld`); yeni dünyada olmayan zincir ana zincirin AYNI seviyesine döner (kayıp yok). Henüz kilitli üreticinin zincirini isteyen yarım sipariş ana zincire döner (sipariş asla karşılanamaz kalmaz).
- **Üretici yükseltme (coin, kalıcı, zincir başına):** üreticinin sol alt **Lv rozetine dokun** (ya da sandığa uzun bas) → pencere. Seviye 1-5, bedel `MbWorlds.upgradeCosts = [250, 600, 1200, 2400]`. Etki: (1) üst seviye eşya çıkma ihtimali `+%8/seviye` (kuralı bölümlerde — sade/saf üreteç — uygulanmaz), (2) bazı dokunuşlar enerji harcamaz `%5/seviye` (Sv.5 = %20). Coin yetiyorsa rozet yeşil ▲ olur. Seviyeler `MbState.producerLevels` (kayıtta `pl`), `GameProgress.spendCoins` yeni.
- **Öğretici:** gereken zincir 2. ya da 3. üreticideyse halka o sandığa gelir (`MbTutPlan.slot`).
- **Çeviri:** 10 yeni metin TR + ES/PT/DE/FR/RU.
- **Ayar yerleri (denge):** `MbWorlds` (zincir tablosu, kilit bölümleri, hücreler, bedeller, `bonusPct`, `freeTapPct`). Dengeyi telefonda bak: 3 üreticili bölümde tahta çok doluyor mu (gerekirse `unlockChapter` ya da `producerCells` değiştir), yükseltme bedelleri coin akışına göre uygun mu.
- **Log/analitik:** `mb_producer_unlock`, `mb_producer_open`, `mb_producer_upgrade {chain, level, cost}`; `URET:` logunda üretici/zincir/seviye ve `BEDAVA`. Bedava dokunuş `spawns` (harcanan enerji) sayacına eklenmez.
- **Bulut kaydı notu:** eski sürüm (pl yok) kaydı kazanırsa üretici seviyeleri Lv1'e döner (en ileri bölümün kaydı kazanır); herkes güncelleyince sorun kalmaz.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter analyze && flutter test`. Yeni test: `test/mb_producers_test.dart`. Telefonda bak: (1) 3. bölümde 2. sandık beliriyor mu, rozetler okunuyor mu, (2) Lv rozeti/uzun basma pencereyi açıyor mu, yükseltince rozet güncelleniyor mu, (3) dünya geçişinde objelerin görseli doğru zincirde mi, (4) küçük ekranda 3 sandık + rozetler taşmıyor mu.
- **versionCode** +1.

# YENİ (v179): Mod 2'de Play puanlama isteği
- Puanlama penceresi (`ReviewService`) sadece Mod 1'deydi; ana oyun Mod 2 olduğu için çoğu oyuncuya hiç çıkmıyordu. Artık Mod 2'de **3. bölüm bitince** ("Devam" ve varsa hikâye sahnesinden sonra) istenir: `merge_board_screen.dart` `_chapterDone` sonu → `ReviewService.maybeAskMod2`.
- Sınırlar Mod 1 ile ORTAK: oyuncuya en fazla 3 kez, en az 90 gün arayla (+ Google'ın kendi kotası). Bölüm sınırı Remote Config `review_min_chapter_mb` (varsayılan 3). Öğretici sırasında istenmez. Analitik `review_requested` olayına `mode` (mod1/mod2) eklendi.
- ⚠️ Derlenmedi (Flutter yok): `flutter analyze`. Not: Pencere sadece Play'den kurulu sürümde ve Google izin verirse çıkar; test için internal test kanalı kullan.

# YENİ (v178): "Oyunlarımız ve Uygulamalarımız" sayfası
- Menü (Ayarlar) ekranında Müzik'in üstüne turuncu **Oyunlarımız ve Uygulamalarımız** butonu; yeni sayfa `lib/screens/more_games_screen.dart`. Liste alt alta, satıra (ikon dahil) dokununca Play Store açılır (önce `market://`, olmazsa https; açılmazsa popup).
- İlk kayıt: **Galaxy Puzzle** (`com.astrofelyx.pro`, ikon `assets/images/apps/galaxy_puzzle.webp`). Yeni oyun için `kMoreApps` listesine satır ekle.
- Yeni bağımlılık: `url_launcher: ^6.3.1` (sürüm doğrulanamadı) + `AndroidManifest.xml` `<queries>` (https/market). `flutter pub get` gerekir.
- Analitik: `more_games_open`, `more_games_tap {app}`. Çeviri: TR + 5 dil.
- ⚠️ Derlenmedi (Flutter yok): `flutter pub get && flutter analyze`.

# YENİ (v177): Kilitli ikonlar sadece sıradaki 2 tane + özel popup
- Kilitli özelliklerden (Görevler Lv5, Etkinlik Lv7, Çark Lv10, Sezon/Kumbara Lv12) menüde yalnızca **seviyesi en yakın 2'si** görünür; açılmış olanlar hep görünür. Seviye atladıkça sıradaki kilitli ikon belirir (`main_menu_screen.dart`: `show()` / `shownLocked`).
- Kilitli ikona dokununca toast yerine **özel pencere**: soluk ikon + kilit, ad, "Seviye X'te açılır", "Şu an Y. seviyedesin" ve Kapat düğmesi (`_lockedTap`). Yeni çeviri anahtarı: `Reach Level {0} to unlock this! You are Level {1} now.` (TR+5 dil).
- ⚠️ Derlenmedi (Flutter yok): `flutter analyze`.

# YENİ (v176): Ana menü kilitleri + sağ sütun, kasaba üretimi, sabit yazı boyutu
- **Kilitli ikonlar:** Çark (Lv10), Kumbara (Lv12), Sezon (Lv12), Etkinlik (Lv7) ve alttaki Görevler (Lv5) artık seviyesi gelmese de menüde görünür; soluk durur, üstünde **kilit + "Lv.X"** hapı olur. Dokununca "🔒 Seviye X'te açılır" bilgisi çıkar (ekran açılmaz). Açılınca normal ikon + kırmızı nokta davranışı aynı. (`main_menu_screen.dart`: `_SideIcon.lockLevel`, `_DockItem.lockLevel`, `_LockOverlay`, `_lockedTap`.)
- **Kumbara sağa taşındı:** Sol sütundan çıktı; sağ sütun sırası **Çark → Kumbara → Sezon → Etkinlik**. Sağ sütun artık "?" düğmesinin üstünde biten sınırlı bir alanda ve `FittedBox(scaleDown)` içinde; sol sütunla aynı mantık: ekran kısaysa ikonlar kendiliğinden küçülür, taşma/üst üste binme olmaz.
- **Bina yükseltilirken üretim durur:** `GameProgress._townAccrued` insaattaki binada sadece depodakini döndürür; `startTownUpgrade` insaattan önce birikeni depoya yazar; `tickTownUpgrades` bitişte seviyeyi artırır ve üretimi **insaatın bitiş anından** yeni seviyeyle başlatır (uygulama kapalıyken biten inşaat için geçen süre sayılır). Depodaki coin toplanabilir. Uzay Istasyonu (pasif bonus) yükselirken diğer binaların birikimi eski hızla kapatılır. Kasaba ekranı: toplam saatlik üretime insaattakiler dahil değil; bina panelinde "⏸ Yükseltme sırasında üretim durur". Test: `test/town_pause_test.dart`.
- **Yazı boyutu sabit:** `main.dart` MaterialApp `builder`'ında `textScaler: TextScaler.noScaling`. Cihazın yazı boyutu ayarı oyunu etkilemez (tüm ekranlar).
- **Çeviri:** `🔒 Unlocks at Level {0}` ve `⏸ Output paused while upgrading` TR + ES/PT/DE/FR/RU eklendi.
- **versionCode** +1.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter analyze && flutter test`. Telefonda bak: (1) 5 kilitli ikon (Lv.X hapı okunuyor mu), (2) küçük ekranda iki sütun, (3) bina yükseltmede depo sayacı duruyor mu, bitince devam ediyor mu, (4) cihaz yazı boyutunu en büyüğe alınca menü/diyaloglar bozulmuyor mu. Eski kayıtta o an yükseltilen bina varsa, son toplamadan beri birikeni bir kez kaybeder (küçük).

# YENİ (v175): Mod 2 denge — 4. bölüm zorluk sıçraması + enerji
- **Sebep:** Bölüm başına gereken enerji 17 → 31 → 54 → 67 (1–4. bölüm); normal bölümde sipariş başı enerji iadesi yoktu, 90 sn'de 1 enerji dolduğu için 4. bölüm ≈ 100 dk bekleme demekti.
- **Hata:** Seviye atlama popup'ı "enerji doldu" diyordu ama `addXp` yalnız Mod 1 enerjisini dolduruyordu. Artık `merge_board_service.dart` Mod 2 enerjisini de dolduruyor.
- **Enerji iadesi:** Normal bölümlerde sipariş başına +2 ⚡ (`MbChapter.baseOrderEnergy`); Bereket bölümü hâlâ +5.
- **Rampa:** 4. bölüm Lv3–4 ağırlıklı, Lv5 kalem %15 (`rareTop`); 5–6. bölüm Lv3–5; 7. bölümden itibaren Lv4–5 (eskisi gibi). Tahmini net enerji (iade düşülmüş): b1 7, b2 21, b3 44, b4 32, b5 53, b6 55, b7 62. Bölüm 8 ("sadece yüksek seviye") hâlâ ~97 net, 100'lük barın sınırında; istersen ayrıca yumuşatılır.
- **Ayar yerleri:** `lib/models/merge_board.dart` → `MbChapter._build` (seviye aralığı, `baseOrderEnergy`, `rareTop`). Test: `test/merge_board_test.dart` ("yumusak rampa").
- ⚠️ Derlenmedi / çalıştırılmadı (Flutter yok): `flutter analyze && flutter test`. Bölüm tablosunu Python'da simüle ettim (atıksız tahmin; gerçekte ~%10-20 fazla çıkar).

# YENİ (v174): Popup düzeltmeleri (taşma, kutu ikonlar, Mod 2 popup'ları)
- **Taşma:** `MergeChainHint` (Nasıl oynanır zinciri) sabit genişlikli satır + `FittedBox` ile yeniden yazıldı; sol grup her zaman 136 px, ` + ` yazısı yerine ikon. Dar telefonda "RIGHT OVERFLOWED BY xx PIXELS" çıkmaz.
- **İkonlar:** `CoinText` artık 🪙 ⚡ 💎 karakterlerini oyunun kendi görselleriyle (coin_icon / bolt / gem) çizer (eski cihazlarda 🪙 kutu çıkıyordu). Kullanıcılar: CandyButton etiketi, popup'lar, Mod 2 toast'ı, enerji çubuğu, koç balonu, bölüm haritası.
- **Mod 2 popup'ları** (`merge_board_screen.dart`) düz `AlertDialog` yerine `GameAlertDialog` (süslemeli panel + resimli butonlar): Nasıl oynanır (numaralı adımlar), Enerji bitti (mavi "Reklam izle" + yeşil "Doldur" butonu), Bölüm tamamlandı (renkli ödül satırları + sıradaki bölüm kartı).
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter analyze && flutter test`. Telefonda bak: 3 popup'ın görünümü, küçük ekranda Bölüm tamamlandı popup'ının kaydırılması, Nasıl oynanır ipucunun taşmaması.

# YENİ (v173): Appodeal kalktı, Unity LevelPlay geldi
- **Ne değişti:** `stack_appodeal_flutter` ve tüm Appodeal adaptörleri (applovin, bidmachine, vungle, yandex, bigo, inmobi, mintegral, bidon, unity_ads) silindi. Yerine `unity_levelplay_mediation: ^9.3.0` + **Unity Ads adaptörü** (`com.unity3d.ads-mediation:unityads-adapter:5.15.0` (Unity Ads SDK adaptörün içinde gelir)) + eklentinin istediği 3 Play Services bağımlılığı (`android/app/build.gradle`). Appodeal/Mintegral Maven depoları `android/build.gradle`'dan çıkarıldı.
- **`lib/services/ad_service.dart` yeniden yazıldı, dışarıya açık API aynı** (`watchRewardedAd`, `notifyChapterCompleted`, `isRewardedReady`, `showRewarded`, `resetInterstitialCounter`). Analitik olay adları aynı (`ad_rew_*`, `ad_inter_*`). Yükleme başarısız olursa 15/30/60/120 sn aralıkla otomatik yeniden dener.
- **ID'LER BOŞ — sen dolduracaksın:** `AdService.levelPlayAppKey`, `rewardedAdUnitId`, `interstitialAdUnitId` (hepsi `ad_service.dart` başında). **Boşken SDK hiç başlamaz, odullu reklam eski "simülasyon" davranışını gösterir** (oyun çalışır, gerçek reklam çıkmaz).
- **Panelde yapılacak:** LevelPlay'de uygulamayı ekle (`com.sitora.ai`, Android) → App Key; Rewarded ve Interstitial ad unit oluştur → ID'ler; Setup > SDK Networks'ten **Unity Ads**'i etkinleştir (Unity dashboard'da yeni proje aç, mediation partner olarak LevelPlay seç; LevelPlay'deki auto-setup Game ID/Placement'ı kendisi taşır).
- **Rıza (GDPR):** Appodeal'ın Google UMP formu artık yok. AB/AEA/UK'de yasal pencerenin açık onay kutusu init'ten önce `LevelPlayPrivacySettings.setGDPRConsent` ile iletilir. Ayarlar > "Reklam Rızasını Yönet" artık küçük bir aç/kapat penceresi. Yasal metin (çeviriler dahil) buna göre güncellendi: "Appodeal" → "Unity LevelPlay", "Google'ın resmi formu" cümlesi çıktı. **Gizlilik Politikası ve Play Console "Veri güvenliği" beyanını da Appodeal yerine LevelPlay/Unity'ye göre güncelle.**
- **Not:** `AD_ID` izni ve `network_security_config` (düz HTTP açık) kaldı; bazı ağlar HTTP ister.
- **versionCode** +33 → +34 (yeni AAB için).
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok). `flutter pub get && flutter analyze && flutter test`. Özellikle bak: (1) `unityads-adapter:5.15.0` ile eklentinin getirdiği LevelPlay Android SDK sürümü uyumlu mu (uyumsuzsa `LevelPlay.validateIntegration()` logda uyarır; `testingMode`'u geçici true yap), (2) ID'leri girince ilk açılışta Logcat'te `LevelPlay init tamam` görünüyor mu, (3) ödüllü reklam sonrası ödül veriliyor ve müzik geri geliyor mu.

# YENİ (v172): Log / analiz tamamlama (hikâye, Mod 2 görevleri, menü)
- **Yeni olaylar:** `story_scene {id,chapter}` (sahne açıldı), `story_skip {id,line}` (Geç'e basıldı, hangi satırda), `story_done {id}` (son satıra kadar okundu), `mb_mission_done {id,period}` (görev hedefe ulaştı), `mb_mission_claim {id,period}` (ödül alındı), `mod1_menu_tap`, `mb_menu_tap {from}`, `tut_firstrun_mb`.
- **Id bazlı sayaç:** `story_*` ve `mb_mission_*` olayları `ad_rew_completed@yer` gibi ayrıca `olay@id` olarak sayılır (örn. `story_skip@w2_a`, `mb_mission_claim@d_orders`). Hikâye hunisi: sahne başına görülen / atlanan / bitiren; görev hunisi: tamamlanan / alınan.
- **Geliştirici özeti** (`AnalyticsService.summary()`): yeni bölüm "HİKAYE + MOD 2 GÖREVLERİ + MENÜ" (sahne ve görev bazında satırlar, sadece görülenler).
- **AppLog (etiket `story`, `mod2`, `cloud`):** sahne başladı/bitti/atlandı, geçmiş sahnelerin sessizce geçilmesi, görev tamamlandı/ödül alındı/reddedildi, görevler yüklendi, buluttan Mod 2 görevleri güncellendi.
- **Bilerek log yok:** her üretim/birleşmede görev ilerlemesi (log'u boğar); sadece hedefe ulaşma ve ödül anı loglanır.
- **Yayında bak:** (1) `story_skip@w0_a / story_scene@w0_a` yüksekse açılış sahnesi uzun/sıkıcı, (2) `mb_mission_done` ≫ `mb_mission_claim` ise oyuncu ödülü almıyor (kırmızı nokta fark edilmiyor), (3) `mb_menu_tap {from}` hero vs dock dağılımı, (4) `mod1_menu_tap` düşükse Fırlat ikonu görünmüyor.
- ⚠️ Derlenmedi / cihazda denenmedi. Test: `test/analytics_story_test.dart`.

# YENİ (v171): Mod 2 görevleri buluta + 5 dilde çeviri
- **Bulut:** `mb_missions_v1` artık `SaveMerge.keys/otherKeys` içinde (`save_merge.dart`: `kMbMissions`, `mbMissions()`). Kural, dönem dönem bağımsız: aynı gün/hafta/ayda ilerleme **max**, alınan ödüller **birleşim** (alınmış ödül geri açılmaz); dönemler farklıysa **yeni dönemin tarafı** komple kazanır (dünkü ödül yarına taşınmaz). `CloudSaveService`: yüklemeden/birleştirmeden önce `MbMissions.flush()`, buluttan kayıt gelince `MbMissions.load()` (v170'teki "cihaza özel" notu geçersiz). Testler: `test/save_merge_test.dart` (3 yeni, `mbMissionsMergeTests`).
- **Diller:** `lib/localization/story_i18n.dart` (`kStoryI18n`): ES/PT/DE/FR/RU için Mod 2 hikâyesi (13 sahne, 40 satır), karakter adları, ana menü ("Oyna", "Fırlat"), Görevler ekranı başlıkları ve 6 görev etiketi = `kStoryTr`'deki 59 anahtarın hepsi. `AppStrings.lt` sırası: `kTranslations` → `kTranslationsExtra` → `kStoryI18n` → İngilizce. Test: `test/story_i18n_test.dart` (her anahtar her dilde var, `{0}/{1}` korunmuş, `lt` gerçekten çeviriyi döndürüyor).
- **Çeviri kalitesi:** Metinleri ben çevirdim (makine çevirisi seviyesinde, oyun tonu korunarak). Yayından önce PT (Brezilya) ve ES için ana dili konuşan biriyle şakaların ("portal çorbası", "dramatik mod") doğal durduğuna bak. Karakter adları yerelleştirildi (ör. Pickles → Pepinillo/Picles/Gurke/Cornichon/Огурчик).
- **Yeni metin eklerken:** önce `kStoryTr` (TR), sonra `story_i18n.dart` (5 dil); test eksik/fazla anahtarı yakalar.
- ⚠️ Derlenmedi / cihazda denenmedi. `flutter analyze && flutter test`. Telefonda bak: iki cihazda aynı hesapla Mod 2 görevi ilerlet → diğer cihaz buluttan çekince ilerleme/alınan ödül doğru mu; dili RU/DE yapınca hikâye balonu ve görev etiketleri taşmıyor mu (Almanca ve Rusça metinler daha uzun).

# YENİ (v170): Mod 2 görevleri (günlük / haftalık / aylık) + sezon puanı
- **Ne var:** Görevler ekranında her sekmede (Günlük/Haftalık/Aylık) iki bölüm: **Fırlat görevleri** (eski 3'ü, değişmedi) ve **Merge görevleri** (yeni 3'ü). Kırmızı nokta ikisini de kapsar (`hasMissionClaimable || MbMissions.hasClaimable`).
- **Mod 2 görevleri** (`lib/models/mb_missions.dart`, sayılar `defs` listesinde tek yerde): Günlük: 1 bölüm / 8 sipariş / 3 Lv5+ birleştirme. Haftalık: 6 bölüm / 120 ⚡ harca / 1 Lv8 (max) obje. Aylık: 24 bölüm / 1 dünya / 150 sipariş. Ham "birleştir" sayılmaz (Mod 2'de spam olurdu).
- **Ödüller (Mod 1'in yarısı civarı):** günlük 80/60/100 coin; haftalık 500/400/600 coin + 2💎 her biri; aylık 2000/1500/1500 coin + 6💎 her biri. Aylık toplam: Mod 2 ≈ 18.200 coin + 42💎, Mod 1 ≈ 32.900 coin + 105💎 (yani coin ~%55, elmas ~%40). İkisini de tam bitiren üst sınırda Mod 1'in ~1,55 katı coin ve ~1,4 katı elmas kazanır. Elmas sert para (enerji dolumu 💎), o yüzden düşük tutuldu.
- **Sezon puanı:** Mod 2'den sipariş +1 (Mod 1 ile aynı), bölüm +15 (`spMbChapter`), dünya bitirme +40 (`spMbWorld`), Mod 2 görev ödülü +5 (`spMbMission`, Mod 1'de 10). Günde ~1,5 bölüm oynayan biri için tahmini ~1650 SP/ay (yolun ~%50'si, 3240 SP); Mod 1 ve çark/günlük bunun üstüne biner. Bu KABA tahmin: `tools/economy_sim` ile doğrula, gerekirse sabitleri düşür.
- **Besleme noktaları (`merge_board_service.dart`):** uret → ⚡ harca (+1), birleşme → Lv5+ / max, teslim tamam → sipariş + SP, bölüm bitti → bölüm (+ dünya bittiyse dünya). Mod 1 ile aynı kural: görevler `missionsUnlocked` seviyesinde açılır.
- ⚠️ **Kayıt cihaza özel** (`mb_missions_v1`, buluta birleşmez): cihaz değişirse o günkü/haftalık Mod 2 görev ilerlemesi sıfırlanır. İstenirse `SaveMerge`'e dönem-bazlı birleştirme eklenir.
- ⚠️ Haftalık etkinlik (`weekly_event.dart`) hâlâ sadece Mod 1'den besleniyor.
- ⚠️ Derlenmedi / cihazda denenmedi. `flutter analyze && flutter test` (yeni: `test/mb_missions_test.dart`). Telefonda bak: bölüm bitirince Merge günlük görevi 1/1 oluyor mu, kırmızı nokta çıkıyor mu, Al'a basınca sönüyor mu, gece yarısı sıfırlanıyor mu, 2 bölümlü liste küçük ekranda rahat kayıyor mu.

# YENİ (v169): Görevler ikonunda kırmızı nokta
- **Ne değişti:** Ana menüdeki Görevler (dock) ikonunda, tamamlanmış ama ödülü alınmamış herhangi bir görev (günlük/haftalık/aylık, 9 görev) varsa kırmızı nokta çıkar; ödül alınınca söner. Kasaba/albüm/çark rozetleriyle aynı `_DockItem.badge` mekanizması. Kod: `GameProgress.hasMissionClaimable` (koşul, Görevler ekranındaki "Al" düğmesinin etkin olma koşuluyla aynı: ilerleme >= hedef ve alınmamış) + `main_menu_screen.dart` (`badge: progress.hasMissionClaimable`). Test: `test/mission_badge_test.dart`.
- ⚠️ **Mod 2 görevleri ilerletmiyor:** Görev ilerlemesi (teslim/birleşme/coin) sadece Mod 1'den (`game_progress.dart` ~1839-1867) besleniyor; Mod 2 coin'i `addBonusCoins` ile geliyor ve görev/sezon sayılmıyor. Mod 2 ana oyun olduğu için Mod 2 oynayan biri görev rozetini nadiren görür. Çözüm için karar lazım: Mod 2 teslim/birleşme/coin görevlere sayılsın mı (hedefler Mod 1 bölüm hızına göre ölçekli, Mod 2'ye göre ayrı ayar gerekir)?
- ⚠️ Derlenmedi / cihazda denenmedi. Telefonda bak: görev tamamlayıp menüye dönünce nokta hemen çıkıyor mu (menü saniyede bir yenileniyor), ödül alınca sönüyor mu, gece yarısı görev sıfırlanınca nokta kayboluyor mu.

# YENİ (v168): Ana menü düzeni — ANA OYUN Mod 2, yan oyun Mod 1 (Fırlat)
- **Ne değişti (`main_menu_screen.dart`, sadece ana sayfa; oyun içi hiçbir şey değişmedi):** (1) Ortadaki kahraman obje ve alttaki büyük dock düğmesi artık **Mod 2 (Merge Tahtası)** açar; dock etiketi "Harita" → **"Oyna"**. (2) Sol sütundaki 🧩 "Merge Board" ikonu → **🎯 "Fırlat"** (Mod 1: fizik masası + harita, `LevelMapScreen`). (3) **Yeni oyuncu:** ilk açılışta doğrudan Mod 2'ye gider (kendi öğreticisi orada). Mod 2 öğreticisi bir kez görülünce (`tutSeen('mb_tut')`) bu yönlendirme biter, menüye normal döner. Mod 1'in kendi ilk-bölüm rehberi, oyuncu Fırlat'a girince eskisi gibi çalışır.
- **Analiz:** `mb_menu_tap {from: hero|dock}` (ana oyun), `mod1_menu_tap` (Fırlat ikonu), `tut_firstrun_mb` (eski `tut_firstrun_map` yerine). Eski huni karşılaştırması için bu tarihten sonrasını ayrı oku.
- **Çeviri:** 'Play' ve 'Throw Mode' TR `story_strings.dart` içinde; diğer diller İngilizce görür. Dock simgesi hâlâ harita resmi (`nav_map.webp`), istersen 🧩'li yeni bir simgeyle değişir.
- ⚠️ Derlenmedi / cihazda denenmedi. Telefonda bak: (1) yeni kayıtla ilk açılış doğrudan Mod 2 + öğretici + sonra hikâye açılışı akıyor mu, (2) Mod 2 öğreticisini yarıda bırakıp çıkınca menü tekrar Mod 2'ye atıyor mu (beklenen), (3) 🎯 ikonu sütunda kasaba ikonunun altında düzgün duruyor mu, (4) dock'taki harita simgesi "Oyna" yazısıyla çelişiyor mu.

# YENİ (v167): Mod 2 hikayesi "Kayıp Tarif Defteri" (şefle, yeni görsel YOK)
- **Hikâye:** Fırtına Şef Mino'nun dükkânını yıkmış, Usta Karamel'in Tarif Defteri'nin 6 sayfası 6 dünyaya uçmuş. Her dünyada bir misafir karakter (Turşu 🥒, Madam Köpük ☕, Büyücü Mira 🧙, Kaptan Kırıntı 🏴‍☠️, Yeti Ayaz 🧊, Komutan Zorp 👽) bir sayfa ipucu verir. Final: fırtına Usta'nın taşan portal çorbasıymış 😄. Ton: komik + sıcak, hafif gizem.
- **Ne zaman çıkar:** Dünyaya ilk girişte (`arrive`, bölüm 1/9/17/25/33/41), dünyanın son bölümü bitince (`clue`, sayfa bulunur) ve 6. dünya bitince final (`fin`, bölüm 49+). Toplam 13 sahne, 43 satır. Mod 2'de ilk öğretici bitince (ya da atlanınca) açılış sahnesi gelir; öğretici sırasında beklemeye alınır.
- **Şef tek resim:** `mascot_chef.webp`. Duygu KODLA verilir (`StoryMood`): happy = zıplama + ✨, shock = büyüyüp titreme + ❗, sad = eğilme + soluk renk + 💧, think = sallanma + 💭. Misafir karakterler emoji dairesi + isim. Dokun = sonraki satır (yazı akıyorsa hızlıca biter), "Geç" = sahneyi kapatır.
- **Dosyalar:** `lib/models/mb_story.dart` (sahne verisi + saf mantık: `MbStory.pending/next/catchUpSkips`), `lib/widgets/story_scene.dart` (`showStoryScene`), `lib/localization/story_strings.dart` (`kStoryTr`, `AppStrings.lt` TR'de buraya bakar), `merge_board_screen.dart` (`_storyCheck`: ekran açılışı, öğretici bitişi/atlanışı, bölüm bitti penceresi sonrası). Test: `test/mb_story_test.dart` (sıra, dünya sonu, final, tekrar çıkmama, TR kapsaması).
- **Görüldü kaydı:** `GameProgress.tutSeen('story_<id>')` (bulutta birleşir, yeni kayıt alanı yok). Önce işaretlenir, geri tuşunda aynı sahne tekrar çıkmaz. **Hikâye öncesi ilerlemiş oyuncu:** bekleyen 2'den fazla sahne varsa ilk (kuruluş) ve son (bulunduğu dünya) gösterilir, aradakiler sessizce geçilir.
- **Analiz:** `story_scene {id, chapter}` olayı. Log etiketi `story`. Huni için: hangi sahnede oyuncu oyundan çıkıyor (mb_close ile karşılaştır).
- **Diller:** TR yazıldı; ES/PT/DE/FR/RU şimdilik İngilizce görür (önceki Mod 2 sürümlerindeki gibi, sonra `kTranslationsExtra`'ya eklenebilir).
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze && flutter test`. Telefonda bak: (1) şef 190x230 + balon küçük ekranda taşıyor mu, (2) emoji bayrağı (🏴‍☠️) ve 👨‍🍳 cihaz fontunda doğru görünüyor mu, (3) bölüm bitti penceresinden hemen sonra sahne açılışı akıcı mı, (4) öğretici → sahne geçişi (6,2 sn gecikme) fazla uzun mu.
- **Sonraki adım önerisi:** hikâye metinlerini oynarken ayarla (komik/gizem dozu); sahne başına Remote Config ile kapatma anahtarı; istenirse şefe 3-4 yüz ifadesi eklenir (kod aynı kalır, sadece `Image.asset` mood'a göre değişir).

# YENİ (v166): Uygulama ikonu ejderha → şef
- **Ne değişti (`android/app/src/main/res`):** `drawable-nodpi/ic_launcher_background.png` (turuncu ışınlı zemin) + `ic_launcher_foreground.png` (şef, 432x432, görünen pencere 72dp = ortadaki 288 px, şapka/yüz güvenli bölgede) + `ic_launcher_monochrome.png` (Android 13 tematik ikon: şef siluet, göz/kaş/gömlek oyuk). Eski cihazlar için `mipmap-*/ic_launcher.png` (yuvarlak köşeli kare) ve `ic_launcher_round.png` (daire) 48-192 px yeniden üretildi. Bildirim küçük ikonu `drawable-*/ic_stat_notify.png` artık şef şapkası + yüz silueti (beyaz, şeffaf). XML'ler (`mipmap-anydpi-v26`) ve dosya adları aynı, manifestte değişiklik yok.
- Play Store 512x512 ikonu ayrı dosya (`playstore_icon_512.png`), Play Console > Mağaza girişi > Uygulama simgesi'ne yüklenir.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok). Telefonda bak: (1) ana ekran ikonu farklı maske şekillerinde (daire/kare/damla) şapka kırpılmıyor mu, (2) Ayarlar > Duvar kağıdı ve stil > Temalı ikonlar açıkken siluet okunuyor mu, (3) bildirim çubuğunda şapka ikonu okunaklı mı (24 px'te detay az, gerekirse sadece şapka silueti).

# YENİ (v165): Splash maskotu ejderha → şef
- **Ne değişti:** Açılış ekranında ortadaki maskot artık `assets/images/mascot_chef.webp` (öğreticideki şef). Boyut, giriş animasyonu (`elasticOut` ölçek) ve süzülme (`Bobbing`) aynı; `dragon_2.webp` splash'ta kullanılmıyor (`splash_screen.dart`). Asset zaten `pubspec.yaml`'da kayıtlı.
- ⚠️ Derlenmedi (Flutter yok). Telefonda bak: şef 250x250 kutuya sığıyor ama ejderhadan daha uzun/dar, etraftaki 6 dünya objesinin halkasıyla ve "WORLDS" başlığıyla çakışıyor mu (şapka üstte, ayakkabılar başlığa yakın).

# YENİ (v164): Merge Tahtası butonu → sol sütunda yuvarlak ikon
- **Ne değişti:** Ana menüde ortadaki "🧩 Merge Tahtası" hap butonu kaldırıldı. Yerine sol sütunda **Kasaba ikonunun altına** diğerleriyle aynı boyutta yuvarlak ikon (🧩 + "Merge Board" etiketi) eklendi. Tıklama davranışı aynı: `mb_menu_tap` analiz olayı + log + `MergeBoardScreen`. "?" butonu yerinde duruyor (`main_menu_screen.dart`).
- **Kod:** `_SideIcon`'a isteğe bağlı `emoji` parametresi eklendi (resmi olmayan özellikler için; `image` artık varsayılan boş).
- ⚠️ Derlenmedi (Flutter yok). Telefonda bak: sütun 6-7 ikonla dolunca (fırsat + kumbara açıkken) `FittedBox` ikonları fazla küçültüyor mu, en alttaki ikon alt çubuğa binmiyor mu.

# YENİ (v163): Mod 2 öğretici (göster-yaptır, Mod 1'deki gibi)
- **Ne yapıyor:** Mod 2'ye ilk girişte canlı tahtada rehber çalışır: parlayan halka + hareket eden **el** + kısa **balon**. Sabit senaryo yok; tahtaya bakıp sıradaki en faydalı hamleyi gösterir (`lib/models/mb_tutorial.dart`, saf mantık): (1) siparişe teslim edilebilen obje varsa **TESLİM** (dokun ya da karta bırak), (2) siparişin istediği seviyenin altında aynı seviyeden iki obje varsa **BİRLEŞTİR** (birbirine en yakın çift, "Lv1 + Lv1 birleştir!"), (3) yoksa **ÜRET** (buton parlar, "Üret'e dokun!"). İlk sipariş tamamlanınca biter: "Harika! Siparişler coin kazandırır" + "Enerji ⚡ zamanla dolar".
- **Kim görür:** `GameProgress.tutSeen('mb_tut')` ile bir kez. Daha önce ilerlemiş oyuncuya (teslim>0 ya da bölüm>1) gösterilmez, sessizce işaretlenir. Yarıda çıkarsa (geri tuşu) bir sonraki girişte devam eder. **"Geç"** butonu balonun yanında.
- **Tekrar:** Mod 2 üst barına **"?"** eklendi: birleştirme zinciri animasyonu + 3 satır anlatım, "Göster" ile aynı rehber canlı tahtada tekrar çalışır (tutSeen yazılmaz).
- **Analiz (huni):** `mb_tut_start → mb_tut_spawn → mb_tut_merge → mb_tut_deliver → mb_tut_done`, ayrıca `mb_tut_skip` (adım), `mb_tut_quit` (adım), `mb_howto_open`, `mb_tut_replay(_done)`. "Nasıl oynanır?" uzun basış özetinde "MOD 2 ÖĞRETİCİ (huni)" yüzdelerle. Log: `[mod2] OGRETICI basladi / ogretici adim: ... / TAMAMLANDI / ATLANDI`.
- **Diller:** 9 yeni metin TR/EN/ES/PT/DE/FR/RU.
- **Test:** `test/mb_tutorial_test.dart` (planlayıcı: birleştir/teslim/üret/dolu tahta/yarım sipariş önceliği).
- ⚠️ Derlenmedi (Flutter yok). Telefonda bak: el animasyonu doğru hücreden doğru hücreye gidiyor mu (hücre konumu `GlobalKey` ile okunur, hamleden sonra bir kare gecikmeyle yenilenir), balon üst satırlardaki objede sipariş kartlarını örtüyor mu (üstteyse balon objenin ALTINA geçer), "Geç" butonu parmakla rahat basılıyor mu, küçük ekranda spawn balonu butonun üstüne oturuyor mu.

# YENİ (v162): Mod 2 analiz + detaylı log (tüm oyunda eylem logu)
- **Mod 2 log (`mod2` etiketi, `merge_board_service.dart` + ekranlar):** yükleme (kaynak, çevrimdışı enerji), her üret (hücre, seviye, enerji önce→sonra, tahta dağılımı `Lv1x5 Lv2x3`), her birleşme/taşıma/yer değiştirme/geçersiz hamle, sürükleme başladı/boşa bırakıldı, dokunuşla teslim (uygun sipariş yok dahil), kalem/sipariş/bölüm/dünya bitişi (coin önce→sonra, XP, seviye atlama), yeni bölüm kuralı, enerji penceresi seçimi (kapat/reklam/elmas) ve sonucu, elmasla dolum (reddedilme nedeni), her kayıt (boyut), bulut geri yükleme (önce→sonra), ekran açıldı/kapandı + yaşam döngüsü, harita açıldı/bölüm bilgisi. **Önceden sessiz yutulan kayıt/yükleme hataları artık `ERR` olarak yazılır.**
- **Mod 2 analiz olayları:** `mb_menu_tap, mb_open, mb_close, mb_order_done, mb_chapter_done, mb_world_done, mb_merge_max, mb_player_level_up, mb_board_full, mb_energy_empty, mb_energy_choice, mb_ad_energy, mb_ad_energy_failed, mb_gem_refill, mb_gem_refill_short, mb_map_open, mb_map_info, mb_cloud_restore`. **`mb_chapter_done.spawns` = o bölüme harcanan ⚡** (enerji dengesi için ana ölçü); ayrıca birleşme, reklam/elmas dolum sayısı, "enerji bitti" ve "tahta dolu" sayısı, dakika, coin, XP.
- **Bölüm istatistiği (`MbStats`, `mb_stats_v1`):** bölüm başına sayaçlar diske yazılır; uygulama kapanıp açılsa da bölüm ölçümü bozulmaz. Ekran oturumu sayaçları `mb_close` olayında.
- **Reklam yeri:** `AdService.showRewarded(..., placement: 'mb_energy')` → Mod 2 enerji reklamları analizde ayrı görünür (`ad_rew_completed@mb_energy`). Analiz özeti (Nasıl oynanır? uzun bas) artık "MOD 2" bölümü içerir.
- **Tüm oyun (`eylem` etiketi, `game_progress.dart`):** coin paketi, bonus coin, elmas ekleme, booster alma, başlangıç paketi, enerji (elmas/reklam/harcama), bina yükseltme/hızlandırma/usta/gelir toplama, çark, günlük ödül/seri kurtarma, 9 görev ödülü, albüm ödülleri, reklam ödülleri (elmas/indirim/inşaat/toplama), XP, bölüm tamam/yıldız ve ses/müzik/titreşim/efekt ayarları artık çağrıldığı anda loga yazılır. (Önceden yalnızca sonuçtaki `state` farkı görünüyordu.) Ana menüde Mod 2 butonu da loglanır. Build etiketi: `v162-mod2log`.
- **Test:** `test/mod2_stats_test.dart` (MbStats JSON, servis sayaçları, analiz özeti).
- ⚠️ Derlenmedi (Flutter yok): `flutter pub get`, `flutter analyze`, `flutter test`. Telefonda bak: Mod 2'de oyna → Ayarlar > Hakkında 7 dokunuş > log: `[mod2]` satırları ve `bolum bitti` özeti geliyor mu; log 6000 satır sınırına Mod 2 yüzünden daha hızlı dolabilir (gerekirse `AppLog._max` artır).

# YENİ (v159): Mod 2 enerji dengesi + bulut kaydı + 7 dil
- **Enerji (benzer oyunlara göre yeniden ölçüldü):** Merge Mansion / Gossip Harbor / Hollywood Merge / Love and Pies: bar 100, 1 ⚡ / 2 dk. Longleaf Valley: bar 200, 1 ⚡ / 90 sn. Twilight Towers: 1 ⚡ / dk. Merge Family: reklam başına 25 ⚡. Bu oyunda siparişte obje sayısı daha az (aynı ⚡ ile daha hızlı ilerlenir), bu yüzden dolum rakiplerden hızlı OLMAMALI: **bar 20 → 100, dolum 90 sn (aynı kaldı), reklam +10 → +25 ⚡, reklamla üst sınır 40 → 200** (`MbState`: `maxEnergy/regenSeconds/adEnergy/energyCap`).
- **Ne değişti (kusursuz oyunla bölüm başına ⚡):** 1-3. bölümler ≈ 100 ⚡ (ilk oturumda ~3 bölüm), 4-8. bölümler ≈ 70-105 ⚡, 25. bölümden sonra ≈ 105-115 ⚡. Gerçek oyunda tahminen ~%30 fazla. Yani bölüm başına yaklaşık 1 bar = ~150 dk dolum (veya 4 reklam). 60 sn düşünülmüştü ama rakiplerden hızlı olduğu için 90 sn'de bırakıldı; 120 sn Merge Mansion hızıdır. Eskiden 85-115 ⚡ isteyen bölüm 20'lik barla 4-5 bar demekti.
- **Kural ödülleri:** "Sadece yüksek seviye" (8, 28, 48...) en pahalı tur (sipariş başına ~26 ⚡) → ödül **+%50**. "Tek hedef" → **+%25**. Bereket: sipariş başına geri **+2 → +5 ⚡**. Rozet açıklamaları buna göre güncellendi.
- **Eski kayıt:** `v<3` kayıt (bar 20) ilk açılışta **bir kerelik tam dolum** alır (`MbState.saveVersion = 3`). JSON sayıları artık `double` gelse de okunur (tahta sıfırlanmaz).
- **Bulut kaydı:** Mod 2 (`mb_state_v1`) artık Play Games buluta gidiyor. `SaveMerge.kMergeBoard` + `SaveMerge.mergeBoard`: tahta+sipariş+enerji tek parça; **(bölüm, bölümdeki teslim, toplam teslim)** büyük olan taraf komple kazanır, eşitse yerelde değişiklik varsa yerel. Coinler zaten `progress` içinde toplamsal birleştiriliyor. `cloud_save_service.dart` yerel anlık görüntüden önce `MergeBoardService.flush()` çağırır, birleştirme diske yazınca `reloadAfterCloudRestore()` bellek durumunu yeniler. Her kayıtta `MergeBoardService.onSaved` → `scheduleUpload` (main.dart).
- **Diller:** Mod 2'nin tüm metinleri (menü butonu, ekran, bölüm haritası, kural rozetleri ve açıklamaları) ES/PT/DE/FR/RU için `kTranslationsExtra` içine eklendi; TR'de eksik olan "Tek hedef" açıklaması düzeltildi (eski anahtar metinle uyuşmuyordu, İngilizce görünüyordu).
- **Testler:** `merge_board_test.dart` (yeni sabitler, v2→v3 geçişi, double JSON, enerji üst sınırı), `save_merge_test.dart` (Mod 2 birleştirme: ileri bölüm kazanır, eşitlikte yerel/bulut, eski 6 tahtalı kayıt).
- ⚠️ Derlenmedi (Flutter yok): `flutter pub get`, `flutter analyze`, `flutter test`. Telefonda bak: enerji yazısı "⚡ 100/100 · 00:59" sığıyor mu, iki cihazda Play Games girişiyle Mod 2 ilerlemesi geliyor mu, dil değiştirince rozetler çevriliyor mu.
- **Enerji bitince 3 seçenek (v160):** Kapat / Reklam izle (+25 ⚡, günlük sınır YOK) / **100 💎 ile tam dolum** (`MergeBoardService.refillWithGems`, `MbState.refillGemCost`). Elmas yetmezse mağaza açılır (`showNotEnoughGemsDialog`). Elmasa da reklamla (mağaza) ya da satın almayla ulaşılır. Mod 1'in 1 ⚡ = 1 bölüm ölçeğinden bağımsız ayarlandı.

# YENİ (v154): MOD 2 - Merge Tahtası (klasik sürükle-bırak merge)
- **Ana menü:** dock'un üstünde ortada yeni "🧩 Merge Tahtası" butonu (`main_menu_screen.dart`). Mod 1 (fizik masası + harita) aynen duruyor.
- **Oynanış:** 6x8 tahta. "Üret" butonu (1 ⚡) boş hücreye Lv1 (%12 Lv2) obje koyar. Aynı seviyeden iki objeyi sürükleyip üst üste bırak = bir üst seviye (max Lv8). Farklı seviyeye bırakırsan yer değiştirir. Üstteki 3 sipariş kartına uygun seviyede obje bırak = teslim; kartın tüm kalemleri bitince coin ödülü, yeni sipariş gelir.
- **Dünyalar:** 6 dünyanın 8'er seviyelik zinciri (yeni resim yok). Her dünyanın kendi tahtası/siparişleri var. Sonraki dünya, öncekinde 10 sipariş teslim edilince açılır (`MbState.unlockOrders`). Sipariş seviyesi her 6 teslimde bir artar (Lv3 -> Lv8).
- **Enerji (mod 2'ye özel):** 20 ⚡, 90 sn'de +1. Bitince "Reklam izle" ile +10 ⚡ (`AdService.showRewarded`, yer: yok/generic). Tahta doluyken Üret enerji harcamaz.
- **Ekonomi:** Lv n obje = 3 x 2^(n-1) coin (Lv8 = 384); çok kalemli siparişe %20 bonus; siparişin toplam maliyeti 160 Lv1'i geçmez. Coin ana cüzdana gider (`addBonusCoins`: görev/sezon ilerlemesine SAYILMAZ). Sayılar `merge_board.dart` başındaki sabitlerde (`unitCoins`, `maxOrderCost`, `regenSeconds`...).
- **Dosyalar:** `lib/models/merge_board.dart` (saf mantık), `lib/services/merge_board_service.dart` (kayıt `mb_state_v1` + coin), `lib/screens/merge_board_screen.dart` (ekran). Test: `test/merge_board_test.dart`. TR metinler `kDynTrExtra` içinde; diğer diller şimdilik İngilizce.
- ⚠️ Derlenmedi (Flutter yok): `flutter pub get`, `flutter analyze`, `flutter test`. Telefonda bak: hücre boyutu küçük ekranda yeterli mi (6x8 -> gerekirse `MbBoard.cols/rows`), sürüklerken parmağın üstünde görünen obje, menü butonunun diğer ikonlarla çakışması.
- (v159'da bulut kaydına eklendi.) Analytics olayı yok.

# YENİ (v153): Bölüm kuralı çakışması + 7 dil
- **Çakışma düzeltildi:** zamanlı / sınırlı atışlı bölümde artık zor etiketi, mutator ve (zamanlıysa) süreyi kısaltan tema kuralı BİNMEZ (etiket ORTA). Mutator o bloktaki uygun komşu bölüme kayar (`ChapterMods.mutatorChapterOfBlock`); mutator aralığı 6-10 bölüm.
- **Diller:** v152 metinleri (zorluk etiketleri, tema kuralları, mutator, boss) ES/PT/DE/FR/RU için `kTranslationsExtra` içine eklendi. Test: `chapter_mods_test.dart` tüm anahtarların tüm dillerde olduğunu doğrular.
- ⚠️ Derlenmedi.

# YENİ (v152): Zorluk dalgası + tema kuralları + mutator + boss kişilikleri
- **Yeni dosya:** `lib/models/chapter_mods.dart` (`ChapterMods`). `ChapterConfig` getter'ları sonucu uygular; kapılar (bomba 11, buz 21, engel 31, joker 41) korunur. İlk 8 bölüm dokunulmaz.
- **Zorluk dalgası:** normal bölümler blok içinde `M E M H M H E M` (orta/kolay/zor). Kolay: alt seviye -1, süre x1.2, coin x0.85. Zor: alt seviye +1 (11+), süre x0.9, Lv3 +%5, coin x1.15. Rahat/boss kendi türünü korur. HUD'da 🟢/🔥 öneki + bölüm başında toast.
- **Tema kuralı (3-8. bölümler):** Kafe=hızlı servis (süre x0.8), Büyü=iksir dumanı (Lv3 +%8), Korsan=top ateşi (bomba x2), Buz=derin dondurucu (+2 buzlu), Uzay=meteor (+1 engel, joker x2), Fast Food 2. tur=yoğun saat.
- **Mutator:** blok başına 1 bölüm (4.; boss ise 3.): acele, büyük sipariş, bomba gecesi, aşırı stok, buz, barikat, joker yağmuru (kapılara göre). 12, 19, 28, 36, 44, 52, 59...
- **Boss kişilikleri:** 10 Saatçi, 20 Bombacı, 30 Buz Cadısı, 40 Duvarcı, 50 Saatçi... (kapıya göre).
- **Tur (lap):** 49. bölümden sonra kurallar bir kademe sertleşir (düz plato yok).
- **Sipariş alt seviyesi varsayılanları:** ch3 8→9, ch4 11→13, ch5 16→19 (basamaklar yumuşadı). ⚠️ Firebase'de `order_floor_*` yayındaysa onlar ezer.
- Eski `order_floor_test` v149'dan beri güncel değildi, yeniden yazıldı. Yeni test: `chapter_mods_test.dart`.
- ⚠️ Derlenmedi. Yeni metinler sadece TR/EN; diğer diller İngilizce gösterir.

# YENİ (v150): Slot yükseltmesi kaldırıldı + teslim uçuş animasyonu
- **Ekstra Sipariş Slotu KALDIRILDI** (yükseltmeler ekranından ve `buyOrderSlotUpgrade`). Kart sayısı sadece bölüme göre: 1-8 = 2, 9+ = 1. Daha önce satın alanlara harcadıkları coin (1800 / +5000) **bir kez iade edilir** (`slotRefundV1`, bulut birleştirmede max alınır). `upgrade_slot_*` çeviri anahtarları kullanılmıyor (silinebilir).
- **Teslim animasyonu:** Eşleşen obje masadan kartın merkezine **yay çizerek uçar** (0,36 sn, kuyruk izi, küçülür). Ucuş boyunca kart yeşil parlar, süresi durur, başka top o karta eşleşmez. Varınca: ödül/sayaç/bölüm-bitişi işlenir, kartın yerinde halka + kıvılcım patlaması ve ✓ +ödül çıkar. Kod: `_launchDelivery/_tickFlyers/_finishDelivery`, `_FlyBall`, `_BallsPainter` içinde çizim; kart konumu `GlobalKey` ile alınır (alınamazsa eski anlık teslim).
- Sınırlı atış kaybı, uçuştaki obje varken tetiklenmez.
- ⚠️ Derlenmedi. Dikkat: uçan top kartların ÜSTÜNDE değil, tahta katmanında çizilir; kartlar HUD katmanında olduğu için top karta varırken kartın arkasında kalabilir. Telefonda bak; olursa uçuşu HUD katmanına (Overlay) taşı.

# YENİ (v149): 1-2 kart düzeni, teslim ritmi, süre göstergesi, yeni ceza
- **Kart sayısı:** Bölüm 1-8 = 2 kart, 9+ = 1 kart (`ChapterConfig.baseOrderSlots`, RC: `slots_early/slots_late/slots_early_until`). Mağazadaki "Ekstra Sipariş Slotu" bunun ÜSTÜNE eklenir (1 kart+2 slot = 3 kart oyunu eski haline getirir; karar ver!). Kart boyutu 120/108/96 px.
- **Sipariş sayısı:** 1-8: 5,6,7,8,9,10,11,12 (5 ve 10. bölüm rahat/boss çarpanı aynı). 9-14: 8, 15+: 10. Rahat x0.7, boss x0.5 (min 5). Sınırlı atış `shots_per_order` 13→15, zamanlı `seconds_per_order` 12→14. Sipariş seviye tabanı: ch3:2, ch8:3, **ch11:4, ch16:5** (RC `order_floor_*`).
- **Teslim ritmi:** iki teslimat arası en az 600 ms (`delivery_gap_ms`), boşalan slotta ✓ +ödül görünür, yeni sipariş 700 ms sonra gelir (`order_refill_ms`).
- **Süre göstergesi:** sipariş kartının altında ⏱ kalan saniye (son 10 sn kırmızı).
- **Süre dolma cezası:** Lv1 top düşmesi KALDIRILDI. Yerine masadaki 1 (25+ bölümde 2) obje DONUYOR (`penalty_freeze`, `penalty_freeze_late`); yanında birleşme olunca çözülür. Önce Lv2+ objeler seçilir. İlk seferde buz açıklaması gösterilir.
- ⚠️ Derlenmedi. Kontrol: büyüyen kartlar masayla/tehlike çizgisiyle çakışıyor mu, buzlu top dolu masada çözülebiliyor mu, Firebase'de eski `order_floor_*`/`shots_per_order` anahtarları yayında ise koddaki yeni varsayılanları ezer.

# YENİ (v148): Kullanıcı yorumlarına göre düzeltmeler
- **Çıkış (X) butonu** sağ üst köşeye alındı, 24→38 px (dokunma alanı 48 px). Coin kapsülü sola kaydı (`right: 56`). `game_board.dart`.
- **"?" Nasıl oynanır** dugmesi ana menüde (sağ alt, dock üstü) her zaman görünür. Ayarlar'daki buton aynı `openHowTo()` fonksiyonunu kullanır (`widgets/howto_launcher.dart`).
- **Birleştirme zinciri animasyonu** (`MergeChainHint`, `tutorial_coach.dart`): pratik moduna girmeden önce küçük bir açıklama penceresinde A+A→B gösterilir. Yeni anahtarlar: `howto_chain_title/body/btn` (7 dil).
- ⚠️ Derlenmedi (Flutter yok): `flutter analyze`. Kontrol et: "?" butonunun konumu (bottom: 128) Oyna/dock ile çakışıyor mu, X butonu sipariş kartlarıyla çakışıyor mu, ayarlar ekranında kullanılmayan import uyarısı.

# YENİ (v147): Çok detaylı log
- **Log altyapısı:** 6000 satır bellekte, 500 KB dosyada (önceki oturumlar dahil). Yazma tamponlu (700 ms'de bir toplu), hata satırında anında. Log ekranı son 500 satırı gösterir, KOPYALA/PAYLAŞ tamamını verir.
- **Otomatik izleme:** her ekran geçişi (`rota`), her dokunuş koordinatı (`dokunus`), yavaş kareler >120 ms (`jank`), 20 sn'de bir bellek nabzı (`nabiz`), bellek baskısı/ekran ölçüsü/dil değişimi (`sistem`).
- **İlerleme değişimi (`state`):** her kayıtta önceki kayıtla fark: `coins: 700 -> 722 (+22)`, gems, energy, chapter, level, bina, görev... Elmas harcama ve booster kullanımı nedenle birlikte.
- **Oyun tahtası (`oyun`, `tahta`):** bölüm başlangıcı (hedef/varyant/atış/süre), her atış, her birleşme, sipariş teslim/yenilenme/süre dolması, bölüm bitiş/kayıp/devam/tekrar, enerji harcama, 5 sn'de bir tahta özeti (fps, top sayısı, doluluk, gerilim).
- **Reklam (`ads`):** rewarded/interstitial her callback (yüklendi/yüklenemedi/gösterildi/kapandı/tıklandı/süresi doldu), nofill kararı, watchdog, preload durumu, geçiş reklamı sayacı.
- **Satın alma (`billing`):** isAvailable, bulunan/bulunamayan ürünler + fiyat, buy akışı, purchaseStream durumları, teslim.
- ⚠️ Derlenmedi (Flutter yok): `flutter pub get` + `flutter analyze`.

# YENİ (v146): Hata kayıtları gizlendi
- Ayarlar'daki görünür "Hata Kayıtları" butonu kaldırıldı. Açmak için: Ayarlar > **"Hakkında" başlığına 2 sn içinde 7 kez dokun** > şifre (şifre README'de tutulmaz; hash `_logPwHash`).
- Şifre koda düz yazılı değil, FNV-1a hash olarak `settings_screen.dart` içinde `_logPwHash`. Değiştirmek için: `python3 -c "h=0x811c9dc5\nfor b in 'YENISIFRE'.encode():\n h^=b; h=(h*0x01000193)&0xffffffff\nprint(h)"` çıktısını `_logPwHash`'e yaz.
- ⚠️ Bu gizleme güvenlik değil, sadece görünmezlik; log içinde kişisel veri yok.

# YENİ (v144): Play'de "kapat-aç = sıfırdan başlıyor" önlemi + Town turu hatası
- **İlerleme dosya yedeği** (`lib/services/progress_mirror.dart`, `pubspec.yaml: path_provider`): her kayıtta ilerleme SharedPreferences'a VE uygulamanın kalıcı dosya klasörüne (atomik) yazılır. Açılışta prefs boş/bozuksa dosyadan geri yüklenir (`GameProgress.load`). Log: `[progress] load: prefs BOS ama dosya yedegi var`.
- **Yeni teşhis satırı** (açılış logu): `[storage] [acilis] dosya: klasor=... dosyaKanaryaOncekindenKalmis=... yedekBoyut=...`. Play sürümünde sıfırlanma olursa bu satır prefs mi, tüm uygulama verisi mi gittiğini gösterir. Play'den kurulu (RELEASE) sürümün logunu gönder.
- **Town turu çift GlobalKey** (`town_screen.dart`): bina penceresi artık aynı anda tek açılır (`_sheetOpen`), tur anahtarları sadece tur aktifken verilir.
- **Appodeal:** debug/profile derlemede ayrıntılı log (Logcat tag `Appodeal`); `SdkConfigurationError` nedeni orada yazar. Release'te kapalı.
- ⚠️ Derlenmedi (Flutter yok): `flutter pub get` + `flutter analyze` çalıştır.

# YENİ (v140): Crashlytics + Remote Config + puanlama isteği
- **Crashlytics** (`crash_service.dart`): çökme/hata raporu. Firebase toplaması AndroidManifest'te varsayılan KAPALI (analytics, crashlytics, FCM auto-init); Şartlar onaylanınca `PushService.init` açar (GDPR düzeni korundu).
- **Remote Config** (`remote_config_service.dart`, `remote_tuning.dart`): zorluk/ekonomi sayıları Firebase panelinden değişir, yeni sürüm gerekmez. Anahtarlar `remote_config_service.dart` başındaki listede (order_time_scale_pct, shots_per_order, continue_shots, order_floor_ch2..ch5, penalty_balls, inter_every_chapters, update_force, ...). Panelde YAYINLANMAMIŞ anahtar varsayılan (koddaki) değerde kalır. `ChapterConfig` sabitleri artık getter.
- **Puanlama penceresi** (`review_service.dart`): 3 yıldızla biten bölümden haritaya dönünce, bölüm >= 8, en fazla 3 kez, en az 90 gün arayla. `review_requested` olayı.
- **Gradle:** `google-services` + `crashlytics` eklentileri eklendi (settings.gradle, app/build.gradle), `android/app/google-services.json` repoya konuldu. `firebase_ids.xml` SİLİNDİ (eklenti aynı kaynakları üretir).
- ⚠️ Derlenmedi: `flutter pub get` (firebase_crashlytics ^5 / firebase_remote_config ^6 / in_app_review sürümlerini firebase_core ^4 ile uyumlu doğrula), Gradle eklenti sürümleri (4.4.2 / 3.0.2) AGP 8.13 ile derlenmezse güncelle.

# YENİ (v139): Zorunlu güncelleme penceresi (Google Play In-App Updates)
- `lib/services/app_update_service.dart` + `pubspec.yaml: in_app_update`. Oyun açılışında (Şartlar onayından sonra, reklam rızasından ÖNCE) Play'de yeni sürüm varsa Google'ın tam ekran "Güncelle" penceresi çıkar; güncelleyince oyun yeniden açılır.
- Ayar: `forceImmediate` (true=zorunlu tam ekran, false=arka planda indir), `minStalenessDays` (yeni sürüm çıkınca kaç gün süre tanınsın, 0=hemen).
- Sadece Play'den kurulu sürümde çalışır; APK/debug'ta sessizce atlanır. Test: iç test kanalına sürüm N yükle, telefona kur; sürüm N+1 yükle (versionCode artmış olmalı), uygulamayı aç.
- Analytics: `update_available` (stale_days, mode), `update_result` (result).
- ⚠️ Derlenmedi: `flutter pub get` (in_app_update sürümünü doğrula) + `flutter analyze`.

# YENİ (v138): Sınırlı atış bölümleri kolaylaştı
- `shotsPerOrder` 9→13, `shotsBase` 8→15: hedef×13+15 (20 siparişli bölüm 188 → 275 atış). `continueShots` 8→150 (reklam/elmasla devam). Hepsi game_theme.dart. ⚠️ Devam +150 bölümün yarısından fazlası; reklamla çok kolay geçilirse 80-100'e çek.

# YENİ (v137): Cihaz içi analitik özeti
- Ayarlar > "Nasıl oynanır?" düğmesine UZUN BAS → özet artık BÖLÜM (start/complete/fail/devam/süre dolan), REKLAM (rewarded + geçiş ayrı, rewarded tamamlananlar yer bazlı), PARA (iap, elmas harcama) sayılarını da gösterir. Sayılar cihazda saklanır (Firebase'siz de çalışır). `ad_*` olayları `ad_x@yer` olarak da sayılır.

# YENİ (v136): Analytics olayları (Firebase)
- **Bölüm:** `chapter_start` (chapter, kind, variant, replay), `chapter_complete` (stars, throws, continues, expired, coins), `chapter_fail` (reason: full/shots/time, orders/goal, throws, expired, losses).
- **Devam:** `continue_used` (method: ad | owned | gems | booster_ad, reason, n), `booster_offer_choice` (type, choice: ad/buy/shop/cancel).
- **Sipariş:** `order_expired` (chapter, level, rule).
- **Rewarded reklam (ayrı):** `ad_prompt_shown/declined/accepted` (vardı), `ad_rew_impression`, `ad_rew_completed`, `ad_rew_skipped`, `ad_rew_clicked`, `ad_rew_nofill`, `ad_rew_no_internet`, `ad_rew_show_failed` — hepsinde `placement` (continue, booster, town_collect, ...).
- **Geçiş (interstitial) reklam (ayrı):** `ad_inter_impression`, `ad_inter_nofill`, `ad_inter_show_failed`, `ad_inter_clicked`.
- **Para:** `iap_start/iap_purchase/iap_canceled/iap_error` (product), `gems_spent` (why: coin_pack, booster_<tip>, energy, streak_save; amount).
- Olaylar Firebase konsolunda 24 saate kadar gecikmeyle Events sekmesine düşer; DebugView anlık. Önemli olayları konsolda "Mark as key event" yap.
- ⚠️ Derlenmedi (Flutter yok): `flutter analyze`. Bak: `spendGems(amount, [why])` yeni opsiyonel parametre, `_applyContinue(String)`.

# YENİ (v135): Zorluk ayarı (reklam/elmasla devam ihtiyacı için)
- `ChapterConfig.orderTimeScale = 0.85` (sipariş süreleri %15 kısa), `expiredPenaltyBalls` (süre dolunca düşen Lv1 top: 25+ → 2, öncesi 1), `pressureLv3Max = 0.25` (sırada Lv3 gelme tavanı 0.20 → 0.25). Hepsi game_theme.dart başında, tek yerden oynanır.
- ⚠️ Cihazda denenmedi. Çok zor gelirse önce `orderTimeScale`'i 0.9-1.0'a çek. Analytics'te kayıp oranı + devam (reklam/elmas) oranına bak.

# YENİ (v134): Süresi dolan sipariş → yerine +1 seviye üst sipariş
- `_scheduleOrderRefill(harder: true)`: süre dolunca gelen yeni sipariş bir kez +1 seviye (en fazla Lv8), süresi yeni seviyeye göre. Sonraki siparişler normal (sarmal yok). Lv1 top cezası da duruyor.

# YENİ (v133): Sipariş alt sınırı 25+ → Lv5, süre dolunca ceza
- `orderMinLevel`: 3→Lv2+, 8→Lv3+, 15→Lv4+, **25→Lv5+** (rahat bölümde 1 gevşek).
- **Süresi dolan sipariş artık ceza verir**: masanın üst kenarından 1 Lv1 top düşer (`_expiredPenalty`, game_board.dart). Eskiden kart bedavaya yenileniyordu. Ceza yok: alıştırma, rehberli bölüm, bölüm bitmişken. Daha sert istersen top sayısını artır.
- ⚠️ Derlenmedi / cihazda denenmedi. Bak: düşen top üst kenarda duvara/topa gömülüyor mu, 2 sipariş aynı anda dolunca üst üste biniyor mu.

# YENİ (v132): Sipariş alt seviyesi öne çekildi
- `ChapterConfig.orderMinLevel`: bölüm 3+ Lv1 yok, 8+ Lv1-2 yok, 15+ Lv1-3 yok (eskiden 10/18/26). Rahat bölümde 1 seviye gevşek. Test güncellendi. ⚠️ Bölüm 3-5 hâlâ öğretici aralığında, Lv1 kalkınca kolay mı zor mu oyna.

# YENİ (v131): Firebase Analytics düzeltmesi
- `android/app/src/main/res/values/firebase_ids.xml` eklendi (google_app_id vb.). google-services.json kullanılmadığı için Android Analytics uygulama kimliğini bulamıyor ve olay göndermiyordu. Not: "analitik SDK yok" notu eskidir, Firebase Analytics push_service.dart içinde başlar.
- Doğrulama: `adb shell setprop debug.firebase.analytics.app com.sitora.ai` → Firebase Console > DebugView.

# YENİ (v130): Bomba nabız + zorlu siparişler
- **Bomba**: artık duvara/topa çarpınca PATLAMAZ. Oyuncu istediği yere atar, bomba normal top gibi yerleşir, sonra yerleştiği yerde **3 sn nabız gibi atar** (üstte 3-2-1 sayacı, kırmızı parıltı, giderek hızlanan atış) ve orada patlar. Süre: `BoardPhysics.bombFuseSeconds`. Yerleşme gecikirse ilk temastan 1.5 sn sonra fitil yine yanar (`bombFuseMaxWaitAfterLand`).
- **Siparişler**: `ChapterConfig.orderMinLevel` — bölüm 10+: Lv1 yok, 18+: Lv1-2 yok, 26+: Lv1-3 yok (rahat bölümde 1 seviye gevşek). "Lv N+" kural siparişleri de 4-6'ya kayar. Sayıları oynayıp ayarla.
- ⚠️ Cihazda denenmedi; bak: bomba yığın içine girince fitil başlıyor mu, patlama yarıçapı (100px) 3 sn bekleyince adil mi, 26+ bölümlerde sipariş yetişiyor mu.

# YENİ (v129): Derleme hatası düzeltildi
- `game_board.dart` 1336. satır: `final merged = _Ball(...)` sonunda eksik `;` vardı (GitHub Actions: "Expected ';' after this"). Eklendi. Başka eksik noktalı virgül taraması temiz çıktı.

# YENİ (v128): Açılışta Play Games'e otomatik bağlanma
- `CloudSaveService.autoSignIn()`: kullanıcı Kullanım Şartları'nı onayladıktan ve reklam rıza formu kapandıktan sonra (`LegalConsentService.startConsentGatedServices`) Google Play Games girişi başlatılır. Zaten bağlıysa hiçbir şey göstermez.
- Oyuncu girişi reddederse her açılışta rahatsız edilmez: en fazla **3 açılışta** denenir (`maxAutoSignInTries`, `cloud_autosignin_tries_v1`), sonrası sadece Ayarlar > Google Play Games düğmesi. Bağlanınca sayaç sıfırlanır.
- Giriş başarılı olunca `signIn()` zaten buluttan birleştirir; yeni cihazda ilerleme/elmas/satın alımlar böylece geri gelir.
- ⚠️ Derlenmedi / cihazda denenmedi: `flutter analyze`. Bak: (1) ilk kurulumda sıra: şartlar → reklam rıza formu → Play Games penceresi, üst üste binmiyor mu, (2) giriş reddedilince oyun akışı bozulmuyor mu, (3) Play Console'da Play Games Services yapılandırması + test hesabı ekli mi (yoksa giriş hep hata verir).

# YENİ (v126): Arkadaş daveti + Dükkan + Albüm turları
- **Arkadaş daveti turu (Sv 3):** Ana menüde Mesaj Kutusu parlar → "Davetler" sekmesine dokun → kod/paylaşım açıklaması → kademe ödülleri. Seviye ve ödül sayıları sunucu ayarından (`InboxService.qualifyLevel`, `inviteeBonus`, `tiers`) gelir; metinler `TourStep.textBuilder` ile dinamik (`main_menu_screen.dart > _inviteTourShare / _inviteTourRewards`). Sunucu adresi girilmemişse (`InboxService.isConfigured == false`) tur hiç çıkmaz. Kod daha önce girilebiliyorsa (`canRedeem`) son baloncukta "kodu 7. seviyeden önce gir" notu da çıkar.
- **Dükkan turu (Sv 2)** ve **Albüm turu (Sv 4):** aynı rehberli tur sistemiyle (ikona dokun → tek cümlelik açıklama). Bu iki ekran seviye kilitli değil, menüde hep görünür; seviye sadece turun ne zaman çıkacağını belirler (`GameProgress.upgradesTourLevel / inviteTourLevel / albumTourLevel`).
- **Tur sırası** (aynı anda tek tur): Kasaba → Dükkan (Sv 2) → Davet (Sv 3) → Albüm (Sv 4) → Görevler (5) → Etkinlik (7) → Çark (10) → Sezon (12) → Kumbara (12). Görevler, Etkinlik, Çark, Sezon ve Kumbara turları zaten vardı (değişmedi).
- **Eski oyuncular:** Seviye 5+ oyuncular Dükkan ve Albüm turunu görmez (`tut_mig_126` geçişi, tek sefer). Davet turu herkese bir kez gösterilir (tanıtım). Tüm turlar `tutSeen` içinde, bulut birleşiminde birleşim alınır, geri açılmaz.
- Analytics: `tour_invite_start/_step1..4/_done/_skipped`, `tour_upgrades_*`, `tour_album_*`, `tut_feat_tapped_invite|upgrades|album`.
- ⚠️ Derlenmedi / cihazda denenmedi: `flutter analyze && flutter test`. Bak: (1) Mesaj Kutusu'na dokununca 2. adımda "Davetler" sekmesi parlıyor mu (ekran geçişi sırasında hedef 6 sn içinde bulunmalı), (2) Dükkan ikonu sol sütunda küçük ekranda baloncuk ile çakışıyor mu, (3) Sv 2-4 arasında art arda 3 tur çıkması bunaltıyor mu (Dükkan'ı Sv 3, Albüm'ü Sv 5'e kaydırmak için `*TourLevel` sabitleri).
- Yeni testler: `test/tutorial_progress_test.dart` (v126 geçişi, tur seviyeleri).

# YENİ (v125): Kademeli sabit bölüm coin'i
- **Bölümün toplam coin'i artık objelere değil bölüm numarasına bağlı** (`ChapterConfig.baseChapterCoins / chapterCoinsFor / orderPayoutFor`, `game_theme.dart`):
  - Bölüm 1-5: 100, 150, 200, 250, 300 · Bölüm 6-24: 400 → 900 (doğrusal) · Bölüm 25+: 1000, her bölümde +0,5 (tavan 1400, 775. bölümde).
  - Boss ×1.5, rahat bölüm ×0.7 (`bossCoinMultiplier`, `easyCoinMultiplier`). Daha önce geçilmiş (≥1 yıldız) bölümü tekrar oynamak ×0.25 (`replayCoinFraction`).
  - Tam sabit istersen: `lateCoinGrowthPerChapter = 0`.
- **Coin kaynağı değişti** (`game_board.dart`): coin yalnızca **sipariş teslimatında**, bölüm toplamının eşit payı olarak gelir (birikimli yuvarlama: tüm teslimatların toplamı her zaman tam tutar). Birleşme, max seviye birleşme ve kombo artık coin VERMEZ (patlama/efekt/bildirim kalır). Sipariş kartındaki sayı ortalama paydır. Eski `coinMultiplier` (bölüm derinliği çarpanı) ve seviye bazlı sipariş ödülü (Lv7/8, boss ×2, kural siparişi +%25) kaldırıldı.
- `GameProgress.estChapterCoins` artık tahmin değil, doğrudan bu eğri → coin paketleri ve bölge bitirme ödülü buna göre hesaplanır.
- Zorlu bölüm bonusu (%20), reklamla ×2, Kasaba coin bonusu ve yükseltme bonusu olduğu gibi çalışır (sabit toplamın üstüne uygulanır).
- **Denge kontrolü** (`tools/economy_sim`, `python3 final.py`): eski tier-bazlı modele göre bölüm coin'i ilk 400 bölümde ±%7 (en fazla -%14, bölüm 401 civarı), günlük gelir ilk 30 günde ±%1-3. Şehir/çizgi/slot bitiş günleri eskiyle aynı mertebede (45 dk oyuncu: şehir 192 → 187. gün). Sim tekrar-oynama indirimini modellemiyor.
- Yeni test: `test/fixed_coins_test.dart`. Eski testler (`coin_pack_test`, `ad_economy_test`) yeni eğriyle de geçer (elle doğrulandı).
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze && flutter test`. Özellikle bak: (1) bölüm sonunda toplam coin tam sabit tutarla eşleşiyor mu (kasaba/yükseltme bonusu hariç), (2) sipariş kartındaki ortalama sayı ile alınan coin ±1 farkı rahatsız ediyor mu, (3) tekrar oynamada ×0.25 oyuncuyu kırıyor mu (`replayCoinFraction`), (4) günlük görev "coin kazan" hedefleri (900 / 5.500 / 22.000) hâlâ dengeli mi, (5) kayıpta bölüm baştan başlayınca önce alınan coin'ler kalıyor (eski davranış, değişmedi).

# YENİ (v124): Bomba patlaması efekti
- `game_board.dart`: bomba patlaması artık kodla çizilen katmanlı bir efekt (`_Explosion`, `_drawExplosion`): yanık izi, yukarı süzülen yumuşak duman (10 kabarcık), düzensiz loblu ateş topu (beyaz → sarı → turuncu → kırmızı gradyan), ilk anda flaş, şok dalgası halkası ve çevreye fırlayan 26 kıvılcım (sürtünmeyle yavaşlar, hafif aşağı kavisli, kuyruklu). Görsel dosya gerekmez. Süre 1.15 sn.
- Ayar: `_Explosion.duration`, `_Explosion` factory içinde kıvılcım/duman sayıları ve hızları, `_drawExplosion` içinde renkler/yarıçaplar. Görünür patlama yarıçapı `_kBombBlastRadius` (100 px) ile aynı ölçekte; fiziksel etki alanı değişmedi.
- ⚠️ Cihazda denenmedi. Bak: (1) duman blur'u (MaskFilter) düşük model telefonda kare düşürüyor mu (düşerse `puffs` sayısını 6'ya indir / blur'u kaldır), (2) patlama rengi tema zeminlerinde (buz, uzay) okunuyor mu.

# YENİ (v123): Juice + Seri koruma + Zorlu bölüm türleri
- **Juice (tatmin) katmanı** (`game_board.dart`): ekran sarsıntısı (`_kickShake`), yavaş çekim (`_slowMo`, fizik dt'sini ölçekler; sipariş/bölüm süreleri gerçek zamanla akar), büyük birleşmede halka efekti (`_Blast` artık yarıçap + renk alıyor), kombo yazısı (`_comboPop`: KOMBO → SÜPER → İNANILMAZ → EFSANE) ve kombo 5+ için ağır titreşim. Tetikleyiciler: Lv5+ birleşme (hafif/orta sarsıntı), yeni rekor seviye Lv6+ (yavaş çekim), max seviye birleşme (güçlü sarsıntı + yavaş çekim), bomba (güçlü sarsıntı), kayıp.
  - Ayarlar > **Ekran Efektleri** ile kapatılır (`GameProgress.screenFxEnabled`, cihaza özel, buluta gitmez). Kapalıyken sarsıntı VE yavaş çekim yok; kombo yazısı kalır.
- **Seri koruma** (`game_progress.dart`, `main_menu_screen.dart > _offerStreakSave`): günlük ödül serisi 1-3 gün kaçırılınca ve seri >= 2 günse, ödül penceresinden ÖNCE kurtarma teklifi çıkar. 💎 20 (kaçırılan her ekstra gün +10) ya da **sadece 1 gün kaçırıldıysa** reklamla. Kurtarma `lastDailyRewardClaim`'i dünün 12:00'sine çeker (yeni kayıt alanı yok, bulut birleştirme etkilenmez). Sabitler: `streakSaveMaxMissedDays/GemBase/GemPerExtraDay`. Analytics: `streak_save_shown/gems/ad/declined`.
  - **Düzeltme:** ödül penceresi eskiden bir önceki günün ödülünü/halkasını gösteriyordu (claim sonrası index +1 oluyordu). `pendingDailyIndex` ile önizleme claim ile aynı oldu. Gün farkı artık takvim günü (yaz/kış saati kayması seriyi bozmaz).
  - Çark serisi (7 gün) için koruma YOK, istersek aynı yapı kopyalanır.
- **Zorlu bölüm türleri** (`ChapterConfig.variantFor`, `ChapterVariant`): sadece normal bölümlerde (boss/rahat 5'in katları hariç). 🎯 **Sınırlı atış** (14. bölümden, her 6 bölümde) ve ⏱ **Zamanlı** (22. bölümden, her 6 bölümde; 11/21/31/41 tanıtım bölümleriyle çakışmaz). Atış = hedef×9+8, süre = hedef×12+30 sn. Bitince "Atışların Bitti / Süre Doldu" ekranı; "Devam Et" (revive ya da reklam) masayı temizlemez, **+8 atış / +30 sn** ekler. Tamamlayınca bölüm coin'inin **%20'si** ekstra (`variantBonusFraction`). Harita düğümünde 🎯/⏱ rozeti. Süre, çıkış penceresi açıkken durur.
  - Hepsini kapatmak: `ChapterConfig.variantsEnabled = false`. Sayılar tek yerde: `game_theme.dart` (shotsPerOrder, shotsBase, secondsPerOrder, secondsBase, continueShots, continueSeconds).
  - Analytics: `variant_start`, `variant_complete` (kalan atış/süre), `variant_fail` (neden + teslim edilen sipariş). Denge için ilk bakılacak yer burası.
- Yeni test: `test/variant_streak_test.dart`.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze && flutter test`. Özellikle bak: (1) atış/süre sayıları çok kolay mı zor mu (14. ve 22. bölümü elle oyna, `variant_fail` oranına bak), (2) sarsıntıda kenarlarda boşluk görünüyor mu (Transform.scale 1.02 ile kapatıldı), (3) yavaş çekimde top/birleşme hissi, (4) HUD kapsülü (🎯/⏱, "sonraki" rozetinin karşısı) küçük ekranda sipariş kartlarıyla çakışıyor mu, (5) seri koruma penceresi: `adb` ile saati 2 gün ileri alıp dene.

# YENİ (v122): Bölüm mekanikleri — Bomba, Buzlu top, Engel, Joker top
- **Tanıtım programı** (`ChapterConfig`, `game_theme.dart`): 💣 Bomba **11**, 🧊 Buzlu **21**, 🧱 Engel **31**, 🍩 Joker **41**. Her biri ilk görüldüğü bölümde bilgi balonuyla tanıtılır (oyuncu başına bir kez, `tutSeen('sp_*')`). Hepsini kapatmak: `ChapterConfig.specialsEnabled = false`.
- **Bomba:** sıraya nadir gelir (%4 → bölüm 51+ %8, ilk bomba tanıtım bölümünde 3. atıştan itibaren garanti). İlk temasta (top/engel/duvar) patlar; `_kBombBlastRadius = 100` px içindeki HER şey (engel ve buzlu dahil) yok olur. Patlama halkası + coin parçacığı.
- **Buzlu top (21+):** bölüm başında hazır topların 1-4'ü donmuş başlar. Yanında bir birleşme olunca (eşik: yeni top yarıçapı + 16 px) çözülür; donmuşken birleşmez ve siparişe teslim edilmez. Çözülen top, aynı seviyeden komsusuna değiyorsa hemen birleşir.
- **Engel (31+):** bölüm başında 1-3 hareketsiz engel (static Box2D gövdesi). Temaya göre görsel: kasa (varsayılan/kafe/uzay), varil (korsan), kristal (büyü), buz bloğu (buz). Masa dolulukunu etkilemez, bomba kırar. Kayıp yardımı: her kayıpta bir engel/buzlu eksilir.
- **Joker top (41+):** dokunduğu normal topla birleşir, sonuç o topun seviyesi +1. Fizikte `idA` her zaman normal top (seviyeyi o belirler).
- Kod: `board_physics.dart` (`BallKind`, `_canMerge`, `ExplosionEvent`, `setFrozen`, `_processThawed`), `game_board.dart` (`_rollKind`, `_placeObstacles`, `_drawSpecial`, `_drawFrozen`, patlama işleme "4b"). Görseller: `assets/images/special/` (bomb, wild, obstacle_default/pirate/magic/ice, 480x480 WebP). Sayılar/olasılıklar `ChapterConfig` içinde (bombChance, wildChance, frozenCount, obstacleCount).
- Yeni test: `test/specials_test.dart`.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze && flutter test`. Özellikle bak: (1) engelin çarpışma yarıçapı (`_ballRadius`, engel = Lv5 boyutu) görselle uyuşuyor mu, (2) bomba sprite'ının gövdesi çarpışma dairesinde mi (`_drawSpecial` içindeki scale 1.4 / kayma), (3) engel çevresinde top yuva (slot) bulma, (4) engelli bölümün kazanılabilir olması, (5) bomba yarıçapı dengesi.

# YENİ (v121): "Sıradaki" objesi masanın üstünde
- `game_board.dart`: sıradaki obje rozeti atış noktasının yanından (`_padY - 50`) masanın uzak duvarının hemen üstüne (`_tableTopY - 56`, sağda) taşındı. Konumu değiştirmek için o `Positioned`'daki `top`/`right` değerlerine bak.
- ⚠️ Derlenmedi / cihazda denenmedi: sipariş kartlarıyla çakışıyor mu kontrol et (çakışırsa `top`'u artır veya `right`'ı değiştir).

# YENİ (v120): Zincir merge okunabilirliği + sipariş kartı hızı
- **Sorun:** Lv1+Lv1 -> Lv2 doğunca yanındaki Lv2 ile aynı anda tekrar birleşiyordu; ara Lv2 hiç çizilmeden Lv3 çıkıyor, 3 obje birden kayboluyor gibi görünüyordu (fizik 8x hızlanıyor + bir karede birden çok `_simulate`).
- `board_physics.dart`: birleşmeden doğan topa gerçek-zaman kilidi (`chainMergeDelaySeconds = 0.26`). Kilitliyken temas eden aynı seviye çiftler `_deferredMerges`'e alınır, kilit bitince (hâlâ temastalarsa) birleşir. Süreyi 0 yaparsan eski anlık zincire dönersin. Atılan topun ilk çarpması etkilenmez (anlık).
- `game_board.dart`: birleşen topa `_BallsPainter._popSeconds = 0.22` doğuş "pop" animasyonu (0.6 -> 1.15 -> 1.0).
- Sipariş kartı: `_orderRefillDelay` 380 -> 120 ms, kart animasyonu 260 -> 200 ms (opaklık 0.45'ten başlar + yukarıdan kayar), `_minDeliveryAge` 0.7 -> 0.45 sn.
- ⚠️ Derlenmedi / cihazda denenmedi: `flutter analyze`. Bak: (1) zincirde ara seviyenin görünmesi, (2) 0.26 sn çok yavaş gelirse 0.18'e indir, (3) kart gecikmesi hâlâ uzunsa `_minDeliveryAge`'i düşür.

# YENİ (v119): Elmas paketleri 6 -> 4
- `kGemPacks`: `gems_80`, `gems_550` (en iyi), `gems_1200`, `gems_7000`. `gems_300` ve `gems_2600` kaldırıldı; Play Console'a açma. Toplam IAP ürünü: 4 elmas + `starter_pack`, `piggy_bank`, `season_pass_premium`.
- ⚠️ Derlenmedi: `flutter analyze`.

# YENİ (v118): Reklamla hızlanan ekonomi + özel "İzle" penceresi
- **Reklamsız satış YOK** (karar). Geçiş reklamı **3 bölümde 1** (`AdService.chaptersPerInterstitial = 3`, ilk 6 bölüm muaf) aynen kaldı.
- **Özel popup:** tüm ödüllü reklamlardan ÖNCE `widgets/rewarded_prompt.dart` penceresi çıkar (ikon + ödül + "İzle" / "Vazgeç"). Oyuncu "İzle"ye basınca reklam açılır. `watchRewardedAd(context, prompt: RewardedPrompt(...))` / `AdService.showRewarded(..., prompt:)`. Eski basit onay (`showWatchAdConfirm`) çağrıları kaldırıldı. Analytics: `ad_prompt_shown/accepted/declined`, `ad_rewarded_done/fail` (+`placement`).
- **İnşaat hızlandırma reklamı:** Kasaba inşaat panelinde "-30 dk" (günde 4 hak, `GameProgress.buildAdsPerDay/buildAdMinutes`).
- **Depo ×2 topla:** bina panelinde ve alttaki "Hepsini ×2 Topla" (günde 5 hak, bonus coin, görev/sezon ilerlemesine sayılmaz).
- **Yükseltmede %25 indirim reklamı:** temel maliyeti 10.000+ olan Hız/Şans/Slot ve bina yükseltmelerinde (günde 5 hak). İndirim jetonu o kalem satın alınana kadar kalır (`hasAdDiscount`, `canGetAdDiscount`, `claimAdDiscount`).
- **Yükseltme eğrisi:** Hız/Şans 15 seviye, her seviye ~×1.45 (600'den başlar, zincir toplamı ~349k). Eski 3.200 → 10.800 sıçraması kalktı.
- **Gelir yükseltmelere bağlandı:** Hız + Şans seviyesi başına +%1 coin (`upgradeCoinBonus`, en fazla +%30). **Bölge bitirme ödülü:** bölgenin 8. bölümü ilk kez bitince ~3 bölüm coin'i + 5 elmas (`lastRegionBonusCoins`, kutlama popup'ı).
- **Coin paketleri:** `estChapterCoins` economy_sim bölüm coin'ine hizalandı (eskiden ~2 katıydı).
- **Dokunulmadı / sizde karar:** elmas paketi sayısı (6) Play Console ürünleri olduğu için aynı bırakıldı; 4'e indirmek istersen `kGemPacks` + mağaza listesi. Kasaba maliyet tablosu (`TownCatalog.baseCost`) aynı: toplam sink 3.76M. Hedefin 2-3M ise tabloyu ~%25 küçült.
- Yeni test: `test/ad_economy_test.dart`.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze && flutter test`. Özellikle bak: (1) popup sonrası reklamın açılması (Appodeal gerçek cihaz), (2) Kasaba panelinde butonların taşması küçük ekranda, (3) indirim jetonu bulut kaydında korunuyor mu.

# YENİ (v116): Bölüm içi coin ezilme hatası düzeltildi
- `game_board.dart` `_addCoins`: cüzdana `coins = _coins` (mutlak yazma) yerine `coins += amount` yazılıyor, `_coins` cüzdandan yeniden okunuyor. Böylece bölüm sırasında Play Games bulut eşitlemesi (applyRemote) coin'i değiştirirse sonraki kazanç o farkı ezmez.
- Derlenmedi / cihazda denenmedi: `flutter analyze`.
- `tools/economy_sim/sim.py` koda hizalandı: israf yalnızca merge coin'ine uygulanır, sipariş ağırlıkları (Lv7/Lv8, boss, kural siparişi), Kasaba bonusları (coin/günlük/şans/hız/elmas), Kasaba kilometre ödülleri, boss +3 elmas, önceki dünya şartı, dolu masa (prefill), Hızlı Atış/Şanslı Başlangıç etkisi eklendi. `final.py` çalıştırılınca profil raporu + coin paketi tutarlılığı çıkar (`python3 tools/economy_sim/final.py`). `fin2.py` kaldırıldı (eski/yanlış varsayılanlar).

# YENİ (v115): Gerçek internet kontrolü
- `ConnectivityService` (yalnızca dart:io, ücretsiz, ek paket yok): Google/gstatic 204 ve Cloudflare trace sunucularına paralel HTTPS isteği atar; biri beklenen yanıtı verirse internet VAR. Giriş sayfası (captive portal) olan ağlar "yok" sayılır. Hepsi başarısızsa 1 kez daha dener.
- Açılışta (splash animasyonuyla paralel) ve arka plandan dönünce kontrol edilir. İnternet yoksa kapatılamayan "İnternet Yok" penceresi çıkar; TAMAM (veya geri tuşu) oyundan çıkar.
- Sadece açılışta kontrol istersen: `ConnectivityService.checkOnResume = false`.
- Derlenmedi / cihazda denenmedi: `flutter analyze`.

# YENİ (v114): Gizlilik Politikası / Kullanım Şartları uygulama içinde (WebView)
- `LegalScreen` artık yayındaki GitHub Pages sayfalarını `webview_flutter` ile uygulama içinde açıyor (`LegalLinks`, `legal_screen.dart`). Eski TASLAK metinler kaldırıldı. Bağlantı yoksa "Tekrar dene" gösterir.
- Ayarlar ve ilk açılış onay penceresindeki butonlar aynı ekranı kullandığı için ikisi de otomatik güncellendi.
- Yeni paket: `webview_flutter` -> önce `flutter pub get` çalıştır. Sürüm ekli (+22).
- Derlenmedi / cihazda denenmedi: `flutter analyze`.

# YENİ (v113): Play Games + Kayıtlı Oyunlar açıldı
- `games_ids.xml` app_id = 1029325989416, manifest'te APP_ID meta-data aktif, `CloudSaveService.enabled = true`.
- Play Console'da Kayıtlı Oyunlar, Android OAuth istemcisi (Play imzalama SHA-1) ve test kullanıcıları gerekli. Upload key ile yerelde denemek için ikinci Android kimlik bilgisi (upload SHA-1) ekle.
- Derlenmedi / cihazda denenmedi: `flutter analyze`.

# YENİ (v112): AD_ID izni eklendi (Play Console "reklam kimliği" hatası)
- `AndroidManifest.xml`e `com.google.android.gms.permission.AD_ID` eklendi. Appodeal reklam kimliği kullandığı için beyan "Evet" kalmalı. Yeni AAB derle (versionCode artır), yükle.

# YENİ (v111): Bölümden çıkışta enerji
- Bölüm ortasında geri tuşu / Çık butonu ile çıkmak artık **1 enerji harcar** (atış yapılmamış olsa bile). Geri tuşu önce onay dialogu gösterir (`PopScope` + `_confirmExit`). Kazanma / 2. kayıp / kayıp menüsünde `_lossEnergyCharged` bayrağı sayesinde çift düşmez (`_chargeEnergyOnExit`). Pratik ve ilk bölüm öğreticisinde (`_noLose`) enerji düşmez.
- Bilinen boşluk: uygulama zorla kapatılırsa (görev listesinden silme) enerji düşmez.
- ⚠️ Derlenmedi / cihazda denenmedi: `flutter analyze`.

# YENİ (v110): Firebase bağlandı + Worker adresi (v109)
- `InboxService.baseUrl` artık `https://merge-davet.sitora2026.workers.dev` (Worker yayında, D1 şeması kurulu, `IP_SALT` + `ADMIN_TOKEN` secret'ları yüklendi). `isConfigured` true olur, davet/gelen kutusu/senkron açılır.
- Admin paneli: `https://merge-davet.sitora2026.workers.dev/admin` (`ADMIN_TOKEN` ile giriş). Sağlık kontrolü: `/health`.
- **Firebase bağlandı:** `push_service.dart` sabitleri dolduruldu (proje `worlds-merge`, Android uygulaması `com.sitora.ai`). `PushService.isConfigured` true: Firebase Analytics (D1/D7 retention, `tut_*` öğretici hunisi) ve FCM başlatılır. `google-services.json` projeye KONMAZ, oyun değerleri kodla verir.
- Worker tarafında `FCM_SERVICE_ACCOUNT` secret'ı yüklenmediği sürece push bildirimi gitmez, mesajlar yine gelen kutusuna düşer (isteğe bağlı).
- Test: `adb shell setprop debug.firebase.analytics.app com.sitora.ai` sonra Firebase > Analytics > DebugView.
- Play Console > Data safety: Analytics (uygulama etkinliği, cihaz kimliği) işaretlenmeli, gizlilik metninde anonim kullanım istatistiği yazmalı.
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze`.

# YENİ (v103): Kasaba kilit zinciri
- **Kural:** Bir dünyanın binası, bölüm şartına ek olarak **bir önceki dünyanın binası 5. seviyeye gelmeden kurulamaz** (Kafe ← Lezzet Durağı Sv.5, Büyü ← Kafe Sv.5 ...). Sabit: `TownCatalog.unlockPrevLevel` (0 = kapalı). Mantık: `GameProgress.townPrevOk` / `townWorldUnlocked`.
- **Eski oyuncular:** zaten kurulmuş (seviye>0) bina kilitlenmez.
- **Arayüz:** kilit nedeni ayrı gösterilir: bölüm şartı için "🔒 Bölüm N'de açılır", bina şartı için "🔒 Önceki bina Sv.5" (+ dokununca açıklama balonu).
- **Sim (`chain=N`):** kasaba/çizgi bitiş günü değişmez (coin darboğazı olduğu için sıra değişiyor, süre değil). Fark ilk hafta: 45 dk/gün oyuncuda 7. günde toplam kasaba seviyesi 13 → 6 (şart 5), 10 (şart 4), 13 (şart 3); 30. günde hepsi eşitleniyor. 20 dk/gün oyuncuda şart 5 ile 30. gün 26 → 19.
- **Test:** `test/town_unlock_test.dart`.
- ⚠️ Derlenmedi / cihazda denenmedi: `flutter analyze && flutter test`.

# YENİ (v102): Dolu masa (kademeli) — heyecan artar, zorluk eğrisi korunur
- **Ne:** Bölüm artık boş masayla değil, ilerledikçe dolan masayla başlar. 3. bölümde ilk top, **92. bölümde tehlike çizgisine kadar olan alanın ~%50'si** dolu başlar (`ChapterConfig.prefillFraction`, sabitler: `prefillStartChapter=3`, `prefillFullChapter=92`, `maxPrefill=0.50`, kapatmak için `prefillEnabled=false`). Rahat bölümde yarısı, boss'ta tam. Bölüm 1-2, öğretici ve pratikte hiç yok.
- **Zorluk eğrisi nasıl korunuyor:**
  - 9. bölümden sonra tehlike çizgisinin daralması, dolu masa arttıkça aynı oranda gevşer (`GameBoard._dangerLineFraction`, `ChapterConfig.prefillEase`).
  - Hazır toplar **siparişe teslim edilmez** (hafif koyu + halkalı çizilir); önce aynı seviyeden bir atışla birleştirilmeleri gerekir. Yan yana aynı seviye dizilmez (kendiliğinden birleşmesin), seviyeler Lv1-4 (çoğunlukla 1-3).
  - **Yıldız eşikleri** başlangıç doluluğuna göre ölçülür (`_baseFullness`); atış tempo hızlanması da sadece başlangıç doluluğunun ÜSTÜNDE devreye girer (`_pacingFullness`).
  - **Kayıp yardımı:** aynı bölümde 1. kayıptan sonra doluluk yarıya iner, 2. kayıptan sonra sıfırlanır; bölüm kazanılınca sayaç sıfırlanır.
  - Hazır top yerleşimi tehlike çizgisine en fazla %60 yaklaşır.
- **Ekonomi (sim, `prefill=True`):** max dolulukta bölüm süresi ~-%24, bölüm coini ~-%9, coin/dk ~+%19 (ch47'de +%8). 20/45 dk oyuncuda kasaba/çizgi bitişi ~%6-10 hızlanır. Gerekirse `cost_scale` ile telafi et.
- **Test:** `test/prefill_test.dart` (doluluk eğrisi monoton, tavan, rahat/boss çarpanı).
- ⚠️ Derlenmedi / cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze && flutter test`. Özellikle bak: (1) ilk karede hazır topların yerleşmesi (post-frame, gerçek masa boyutu), (2) üst üste binen toplarda fizik titremesi, (3) yüksek dolulukta 3 yıldız alınabilirliği, (4) hazır top halkasının okunurluğu, (5) dolu başlangıçta kayıp oranı (analytics).

# YENİ (v101): Rampa A + elmasla coin paketleri
- **Rampa A (uzun ömür):** kasaba seviye 1-3 aynı, 4-6 x2, 7-10 x4; çizgiler (atış hızı/şans) 1-3 aynı, 4-7 x2, 8-11 x3, 12-15 x4. Simülasyon (45 dk/gün): kasaba ~251, çizgiler ~449 gün (eskiden 80/132).
- **Elmasla coin paketleri** (Mağaza > Coin Paketleri): 30/100/300/800 💎. Miktar ilerlemeye göre ölçeklenir (`GameProgress.estChapterCoins` x6 bölüm/gün x paket günü 0,3/1,2/4/12). Görev ilerlemesine sayılmaz. Test: `test/coin_pack_test.dart`.
- `tools/economy_sim/sim.py` kodla uyumlu hale getirildi (inşaatçı 600/1600, bölüm elmasları, yeni maliyetler).

# YENİ (v99): Rehberli tur (Empires & Puzzles tarzı, karartma + delik + şef balonu)

- `widgets/guided_tour.dart`: ekranı karartır, **sadece gösterilen hedefe** dokundurur, ok + el + şef maskotlu konuşma balonu gösterir. Hedef widget `TourTarget(id)` (ya da `key: GuidedTour.instance.keyFor(id)`) ile işaretlenir; oyun kodu `GuidedTour.instance.event('...')` ile adımı ilerletir. Kök Overlay'e konur (alt paneller dahil her şeyin üstünde).
- Güvenlik: hedef 6 sn bulunamazsa adım atlanır, 12 sn takılırsa "Atla" çıkar. Tur bitince/atlanınca `tutSeen` işaretlenir.
- **Kasaba turu** (Bölüm 1 sonrası, menüde): şef konuşur → Kasaba ikonu → boş arsa → Kur → ücretsiz Hızlandır → bilgi. **Özellik turları** (görevler, çark, etkinlik, sezon, kumbara): açılınca ikon + tek cümle açıklama. Eski parlayan etiketlerin yerini aldı; eski oyuncular (feat_* görülmüş) turu görmez.
- Yeni anahtarlar: `tour_town/missions/wheel/event/season/piggy` (`GameProgress.tutKeys`), metinler `tour_*` (`app_strings.dart`), `main.dart`'a `navigatorKey` eklendi.
- ⚠️ Derlenmedi/cihazda denenmedi (Flutter yok): `flutter pub get && flutter analyze`. Özellikle bak: deliğin hizası, kasaba panelinde "Kur" butonunun görünürlüğü, balonun ekran dışına taşmaması.

# Fast Food Dükkanı - Merge Oyunu (Bölüm 1 + Bölüm 2: Sipariş Sistemi)

## YENİ (v91): Firebase Analytics + onay öncesi senkron düzeltmesi
- **Firebase Analytics eklendi** (`firebase_analytics ^12.4.3`). `PushService.init()` Firebase'i başlatınca `AnalyticsService.sink` Firebase'e bağlanır;
  öğretici hunisi olayları (`tut_*`) artık gerçek kullanıcılardan Firebase konsoluna gider. Firebase hazır olmadan gelen olaylar (en çok 100) tamponlanıp
  sink bağlanınca iletilir. D1/D7/D30 retention'ı Firebase konsolu **kendisi** hesaplar (Analytics > Retention).
- **Kapsam kararı:** Firebase (push + analitik) **GDPR/reklam onayından bağımsız**; GDPR kutusu ve UMP yalnızca reklam içindir. Firebase, Şartlar/Gizlilik
  onayından sonra başlar (`LegalConsentService.startConsentGatedServices`). Gizlilik metninde anonim kullanım istatistiği toplandığı yazmalı; Play Console
  > Data safety formunda Analytics işaretlenmeli.
- **Yapılacak:** `PushService` içindeki 4 Firebase sabitini doldur (dolmazsa push da analitik de çalışmaz). Test: `adb shell setprop debug.firebase.analytics.app com.sitora.ai`
  sonra Firebase konsolu > DebugView.
- **Düzeltme:** İlk açılışta onay ekranı açıkken uygulama arka plana atılıp dönülürse sunucu senkronu (`InboxService.maybeSync`) artık çalışmaz (onaydan önce kimlik/istek yok).
- ⚠️ Derlenmedi / cihazda test edilmedi (Flutter yok). `flutter pub get && flutter analyze` ile başla.

## YENİ (v89): Öğretici baştan yazıldı (yaptırarak öğret)

Piyasa araştırması: oyuncuların %80-90'ı öğretici metnini okumuyor; iyi öğretici **okutmaz, yaptırır**, başta sadece en temel talimatı verir, geri kalanı oyun ilerledikçe yayar, ilk dakikada kaybettirmez. Buna göre:

- **Bölüm 1 rehberli 3 adım** (`widgets/game_board.dart` → `_CoachStep`, parçalar `widgets/tutorial_coach.dart`). Her adımda en fazla 4-5 kelime; **sadece doğru hareket ilerletir**:
  1. *"Sürükle ve bırak!"* — el, atış noktasından sürükleyip bırakır. Oyuncu kendi atışını yapınca geçilir.
  2. *"Aynı objeye at!"* — durgun Seviye 1 objenin etrafında parlayan halka + el. İki Seviye 1 birleşince geçilir. (Bu adımda gelen objeler hep Seviye 1.)
  3. *"Sipariş otomatik teslim!"* — Seviye 2 sipariş kartları parlar, birleşen obje teslim edilince coin patlaması. İlk siparişler rehberde sabit (Sv 2 / Sv 3), böylece ilk atış kendi kendine teslim olmaz.
  - Rehber sırasında Nişan/Joker çubuğu ve "SONRAKİ" önizlemesi gizli (başta tek talimat). Eski süs amaçlı el animasyonu (`hand_tutorial_overlay.dart`) ve alttaki uzun yazı **silindi**.
- **İlk bölümde kaybetme yok**: Bölüm 1 ilk kez oynanırken masa dolacak olursa alt bölge coin parlamasıyla sessizce temizlenir, kırmızı tehlike çizgisi çizilmez, ilk galibiyet her zaman 3 yıldız. Bölüm 1 bitince (`tutSeen('ch1')`) normal kurallar.
- **Bölüm 2-3 ipuçları** (hepsi tek seferlik): tehlike çizgisi ilk kez Bölüm 2+'da nabız gibi parlar + *"Masayı boş tut = ⭐"*; Bölüm 2+ HUD'da **canlı yıldız göstergesi** (masa doldukça 3→2→1); Bölüm 3-6'da ilk birleşmede *"Hızlı birleştir = 🔥 kombo!"*; hayatındaki **ilk "Masa Doldu"da** Nişan Rehberi + Devam Et'i anlatan tek kart.
- **Özellik açılış vurguları** (`screens/main_menu_screen.dart`): kasaba (Bölüm 1 bitince), görevler (Sv 5), etkinlik (Sv 7), çark (Sv 10), sezon + kumbara (Sv 12) ilk açıldığında menüde o ikon parlar, yanında tek cümle + ok çıkar. Aynı anda tek vurgu; ikona dokununca kapanır. **Hediye yok** (para birimi değeri düşmesin).
- **Tek seferlik + tekrar izleme**: görülenler `GameProgress.tutSeen/markTutSeen` ile kaydedilir (anahtarlar `GameProgress.tutKeys`), bulut birleşiminde birleşim kümesi alınır. **Eski kayıtlar** (tutSeen yok ve Bölüm > 1) için hepsi görülmüş sayılır. **Ayarlar > Yardım > "Nasıl Oynanır?"** rehberi **pratik modunda** tekrar açar (`GameBoard(practice: true)`): coin, görev, albüm, enerji, ilerleme hiçbiri etkilenmez, ilk teslimatta biter.
- **Ölçüm (huni)**: `services/analytics_service.dart`. Projede analitik SDK yoktu; olaylar cihazda sayılır ve ayrıca `AnalyticsService.instance.sink` verilirse dışarı iletilir. Huni: `tut_start → tut_step1_throw → tut_step2_merge → tut_step3_deliver → tut_ch1_complete`, ayrıca `tut_ch1_quit {step}`, `tut_danger_hint`, `tut_combo_hint`, `tut_first_full_card`, `tut_feat_shown_*`, `tut_feat_tapped_*`, `tut_replay_*`. **Ayarlar'da "Nasıl Oynanır?" düğmesine uzun basınca** bu cihazın hunisi görünür (geliştirici). Gerçek kullanıcı verisi için Firebase Analytics eklemek gerekir: `pubspec.yaml`'a `firebase_analytics` ekle ve `main()`'de `AnalyticsService.instance.sink = (n, p) => FirebaseAnalytics.instance.logEvent(name: n, parameters: p);` yaz (`firebase_core` zaten var).
- Yeni metinler `localization/app_strings.dart` (`tut_*`, `feat_*_hint`, `howto_*`); `aim_hint` kısaltıldı.
- Testler: `test/save_merge_test.dart` (tutSeen birleşimi), `test/tutorial_progress_test.dart` (eski kayıt kuralı).
- ⚠️ **Derlenmedi / cihazda test edilmedi (bu ortamda Flutter yok)**; sadece parantez dengesi ve elle gözden geçirme yapıldı. İlk işin `flutter pub get && flutter analyze`. Cihazda özellikle bak: (1) adım 2'deki halka/el konumu, (2) adım 3 balonunun sipariş kartlarının hemen altında durması (`top: safeTop + 150`), (3) menüdeki etiketlerin ekran kenarına taşmaması (küçük telefon), (4) canlı yıldız göstergesinin sol üst kapsülle çakışmaması.

## YENİ (v88): Kasaba hızlandırma fiyatı
- Kısa süreler artık ücretsiz değil: **≤2 dk = 1 💎, 3 dk = 3, 4 dk = 4, 5 dk = 5, 6 dk = 6** (`TownCatalog.skipGemCost`). 20 dk = 16 💎, 1 sa = 45 💎 (eğri aynı).
- **İstisna:** ilk bina kurulumu (0 → 1. seviye, ~1 dk) hâlâ **ücretsiz** atlanır (`GameProgress.townSkipCost`, `townLevels[world] == 0`).
- ⚠️ Derlenmedi / cihazda test edilmedi.

## YENİ (v87): Bölüm sonunda reklamla x2 coin

- Bölüm bitiş ekranında **"🎬 x2 Coin +N"** butonu: reklam izlenirse **o bölümde kazanılan coin** kadar bonus cüzdana eklenir. Bölüm başına **1 kez**, **günlük sınır yok** (şimdilik).
- **Sadece coin ikiye katlanır.** Elmas, XP, yıldız, sezon/etkinlik/kumbara puanı katlanmaz. Bonus **görev ilerlemesine sayılmaz** (`GameProgress.addBonusCoins`, `reportCoinsEarned` çağrılmaz) ve Kasaba coin bonusu bonusa uygulanmaz.
- Reklam **hazır değilse buton hiç çıkmaz** (`AdService.isRewardedReady`, 3 kez dener). Reklam gerçekten izlenmediyse bonus verilmez (`showRewarded(strict: true)`; `rewardOnNoFill` bu butonda geçersiz).
- Reklam izlenince geçiş reklamı sayacı sıfırlanır (`resetInterstitialCounter`).
- Düzeltme: bitiş ekranındaki "+coin" artık **toplam bakiyeyi** değil, **o bölümde kazanılanı** gösterir (`_chapterCoins`).
- ⚠️ Derlenmedi / cihazda test edilmedi (Flutter yok).

## YENİ (v67): Tamamen otomatik bulut kaydı

- "Buluta Kaydet" / "Buluttan Yükle" düğmeleri ve "yüklensin mi?" sorusu **kaldırıldı**. Her şey otomatik (`services/cloud_save_service.dart`). Ayarlar'da sadece otomatik giriş olmadıysa tek bir "Google Play Games ile Giriş" düğmesi görünür; bağlıysa durum yazısı çıkar.
- Açılışta bulut daha ileri bölümdeyse (yeni telefon/yeniden kurulum) kayıt sormadan yüklenir; değilse yerel ilerleme buluta yazılır. Bulut okunamadıysa (internet yok) buluta yazılmaz, uygulamaya dönünce tekrar denenir.
- **Satın almalar korunur**: her satın almadan hemen sonra (mücevher paketi, başlangıç paketi, sezon premium, kumbara) buluta yüklenir. Geri yüklemede eski yerel kayıt `cloud_pre_restore_backup_v1` anahtarına yedeklenir; başlangıç paketi ve sezon premium bayrakları yerel+bulut birleştirilir (biri aldıysa açık kalır).
- ✅ IAP artık Google Play Billing ile (`services/billing_service.dart`, `in_app_purchase`). Fiyatlar Play'den gelir. Yarım kalan/geri yüklenecek satın almalar açılışta `restorePurchases` ile teslim edilir.

## YENİ (v66): Büyük objeler + Google Play Games girişi + bulut kaydı

- **Objeler bir tık büyük**: `kBallSizeScale` 0.70 → **0.78** (`models/game_theme.dart`). Yığın biraz daha hızlı dolar (derinlik ~%30 → ~%33), yıldız oranları (`_threeStarDangerRatio` / `_twoStarDangerRatio`) gerekirse oynanışa göre ayarlanır.
- **Play Games girişi** (`services/cloud_save_service.dart`, paket `games_services`): Ayarlar > "Oyun Hesabı" bölümünde giriş, "Buluta Kaydet", "Buluttan Yükle". Açılışta sessiz oturum kontrolü yapılır.
- **Bulut kaydı**: 5 yerel kayıt anahtarı (ilerleme, sezon, kumbara, etkinlik, geri dönüş) tek bir Kayıtlı Oyun (`progress`) olarak saklanır. Yerel kayıt yazıldıkça en fazla 45 sn'de bir, uygulama arka plana alınınca da hemen yüklenir. Bulut daha ileri bölümdeyse (ör. yeni telefon) ana menüde "yüklensin mi?" diye sorulur.
- ⚠️ **Yayından önce yapılacaklar**: (1) Play Console > Oyun hizmetleri'nde oyunu oluştur, **Kayıtlı Oyunlar**'ı aç, uygulamayı bağla ve SHA-1 kimliklerini ekle (debug + yükleme anahtarı + Play imzası). (2) `android/app/src/main/res/values/games_ids.xml` içindeki `app_id` değerini Play Console'daki gerçek **Uygulama kimliği** ile değiştir (şu an `000000000000`). (3) `flutter pub get`: `games_services` sürümü doğrulanamadı; hata verirse güncel sürümü yaz. compileSdk 34 yeni Play Games kütüphanesiyle uyuşmazsa `compileSdk`'i 35'e çıkar.
- ⚠️ Derlenip cihazda test edilmedi (Flutter yok).

## YENİ (v65): Uygulama adı "World Merge" (AndroidManifest label + iOS display name)

## YENİ (v64): WebP + paket adı

- Tüm `assets/**/*.png` dosyaları **WebP**'ye çevrildi (assets 40 MB → ~14 MB). Büyük görseller kayıplı (q88, alfa kayıpsız), küçük UI parçaları kayıpsız. Kod ve `pubspec.yaml` içindeki yollar `.webp` oldu. Android launcher ikonları (mipmap) PNG kalır.
- Paket adı `com.example.fastfood_merge` → **`com.sitora.ai`** (`android/app/build.gradle` namespace + applicationId, `MainActivity.kt` yeni klasörde, iOS bundle id).
- ⚠️ Bu ortamda Flutter yok, derlenmedi. `flutter clean && flutter pub get` sonra dene. Eski paket adıyla kurulu uygulamayı cihazdan sil (yeni paket ayrı uygulama olarak kurulur).


## YENİ (v20.2): Bölüm sonu şovu + yıldız + oyuncu seviyesi

- **Bölüm tamamlanınca** (`lib/widgets/celebration.dart` → `ChapterCompleteCelebration`): karartma, dönen ışın demeti, konfeti, sırayla "pop" ile açılan 1-3 yıldız (yükselen tonda ses/titreşim), sayarak artan coin/💎/XP, seviye çubuğu, parlak yeşil butonlar.
- **Yıldız kuralı** (`game_board.dart`): tur boyunca yığının en yüksek doluluğu (`_peakFullness`) tehlike çizgisine oranlanır: ≤%50 → 3 yıldız, ≤%80 → 2, üstü → 1. "Devam Et" kullanıldıysa en fazla 2. Oranlar `_threeStarDangerRatio` / `_twoStarDangerRatio`. En iyi yıldız kaydedilir, bölüm haritasında kartta görünür.
- **Oyuncu seviyesi (XP)**: XP bölümün büyüklüğüne göre: ilk geçiş = sipariş sayısı + 10, tekrar = sipariş/2 + 4, her yıldız +3 (`GameProgress.xpForChapter`). Gereken XP `xpNeededForLevel` = 80 + 40/seviye → seviye atlama yaklaşık 3., 5., 8., 11., 14., 18. bölümlerde (3 yıldızla). **Seviye atlama kutlaması** (`showLevelUpCelebrations`): madalyon + ödüller — enerji tam dolar, `levelUpCoins` coin, her 5. seviyede +3 💎. Kutlama bitmeden bölüm sonu butonları gizli kalır.
- Yeni görseller: `assets/images/ui/star_full.png`, `star_empty.png`.
- ⚠️ Bu ortamda Flutter yok, derlenip test edilmedi. `flutter pub get` + cihazda dene; yıldız oranlarını oynanışa göre ayarla.

## YENİ (v20): Mücevher + Güçlendiriciler

- **Mücevher (💎)**: `GameProgress.gems`. Kaynaklar: başlangıçta 5, ilk kez geçilen bölüm +3, albüm set ödülü +10, tüm albüm +50, mağaza (IAP). Harcama: enerji doldurma (12 💎) ve güçlendiriciler.
- **Güçlendiriciler** (`BoosterType`): *Nişan Rehberi* (4 💎, 5 atış boyunca topun ilk temas noktasını gösterir, aynı seviyeyse yeşil), *Joker Top* (6 💎, sıradaki topun seviyesini 1-5 arası seçtirir; joker atışı albümde yeni kart açmaz), *Devam Et* (10 💎, masa dolunca alt bölgeyi temizleyip devam, denemede en çok 2 kez). Yeni oyuncu/eski kayıt her birinden birkaç ücretsiz adetle başlar (`_boosters`).
- **Not:** Bu oyunda atış sayısı sınırsız olduğu için "ekstra atış" yerine *Devam Et* konuldu; dikey nişan çizgisi zaten tam boy olduğu için "çizgi uzatma" yerine *Nişan Rehberi* (çarpma noktası önizlemesi) konuldu.
- **Mağaza** (`screens/gem_shop_screen.dart`): başlangıç paketi (tek seferlik), 4 mücevher paketi, enerji doldurma, güçlendirici satın alma. Ana menüde coin'in yanında mücevher rozeti (dokununca mağaza), enerji kutusunda "💎 12" butonu. Enerji bitince çıkan dialog (harita + oyun) mücevherle doldurmayı da sunar (`widgets/gem_dialogs.dart`).
- **Ücretsiz mücevher kaynakları (v20.1):** günlük ödül serisinin 7. günü +5 💎, her haftalık görev +5 💎, her aylık görev +15 💎, her 5. bölümün ilk geçişinde +10 💎 (ilk geçiş +3'e ek), mağazada ödüllü reklam +2 💎 (günde 3). Hepsi `game_progress.dart` başındaki sabitlerden ayarlanır (`dailyRewardDay7Gems`, `weeklyMissionGems`, `monthlyMissionGems`, `chapterMilestoneGems`, `adGemReward`, `adGemsPerDay`). Reklam şu an sahte (`mock_rewarded_ad.dart`).
- **IAP (Play Billing)**: `services/billing_service.dart`. Play Console'da şu ürün ID'lerini oluştur: `gems_80`, `gems_550`, `gems_1200`, `gems_7000`, `starter_pack`, `piggy_bank`, `season_pass_premium`. Ürün Play'de yoksa/aktif değilse butonda 🔒 görünür ve satın alma yapılmaz. Sunucu tarafı makbuz doğrulaması henüz yok.
- Enerji harcaması artık bir denemede en çok 1 kez kesiliyor (`_lossEnergyCharged`); "Devam Et" sonrası kazanınca çift kesinti olmaz.
- Fiyat/miktar sabitleri `game_progress.dart` içinde (`energyRefillGemCost`, `boosterGemCost`, `chapterFirstClearGems`, ...).
- ⚠️ Bu ortamda Flutter yok, derlenip test edilmedi. `flutter pub get` + cihazda dene.

## YENİ (v19): Koleksiyon Albümü

6 tema × 8 obje = 48 kart. Bir obje tahtada ilk kez üretilince (atış ya da birleştirme) kartı açılır; henüz açılmamışlar siluet + "???" görünür. Bir temanın 8 kartı açılınca set ödülü (300 coin), 6 set de alınınca tüm albüm ödülü (2000 coin) gelir.

- Yeni: `lib/models/album.dart` (tema listesi), `lib/screens/album_screen.dart` (ekran).
- `game_progress.dart`: keşfedilen kartlar / alınan set ödülleri diske yazılıyor (`discoverItem`, `claimAlbumSet`, `claimAlbumComplete`). Ödül sabitleri `albumSetReward` / `albumCompleteReward`; mücevher gelince sadece claim metotlarındaki `coins +=` satırları değişir.
- `game_board.dart`: `_discoverInAlbum()` atışta ve birleşmede çağrılıyor; seviye 2+ yeni keşifte kısa bildirim çıkar.
- `main_menu_screen.dart`: dükkan ikonunun soluna mor albüm ikonu, alınacak ödül varsa kırmızı nokta.
- Yeni tema eklerken: `AlbumCatalog.themes` ve `GameProgress.albumThemeKeys` listelerine ekle (aynı sırada).
- ⚠️ Bu ortamda Flutter yok, derlenip test edilmedi. `flutter pub get` + cihazda dene.

## YENİ (v18): Elle yazılmış fizik → GERÇEK fizik motoru (Forge2D/Box2D)

v1-v17 arası `game_board.dart` içinde elle yazılmış, ~200 satırlık bir
"_Ball" simülasyonu vardı (manuel sürtünme, manuel çarpışma/momentum,
"tren vagonu" ve "yığın dengeleme" gibi referans videoya uydurmak için
eklenmiş özel hack'ler). Bunun yerine artık **Forge2D** (Box2D'nin saf
Dart portu) kullanılıyor:

- **YENİ dosya `lib/services/board_physics.dart`**: `World`, `Body`,
  `ContactListener` üzerine kurulu ince bir sarmalayıcı (`BoardPhysics`).
  Masanın perspektifli (trapezoid) kenarları `EdgeShape` segmentleriyle,
  her obje `CircleShape` dinamik `Body` ile temsil ediliyor. Aynı
  seviyeden iki obje temas edince `preSolve` içinde fiziksel sekme
  devre dışı bırakılıp "merge" olayı kuyruğa alınıyor (klasik Box2D
  merge-oyunu tekniği).
- `game_board.dart` içindeki `_Ball` artık gerçek fiziğin değil, sadece
  ekrana çizim/sipariş eşleştirme için tutulan bir **görüntü kopyası**;
  gerçek pozisyon/hız her frame `BoardPhysics`'ten okunuyor.
- Atılan top artık GERÇEKTEN sürtünmesiz sabit hızla uçuyor (eskiden
  bu "sanal hız" hesabıyla taklit ediliyordu); ilk temastan sonra
  `linearDamping` yükseltilerek referans videodaki "sert oturma" hissi
  korunuyor.
- `pubspec.yaml`'a `forge2d` bağımlılığı eklendi.
- ⚠️ **Bu değişiklik de bu ortamda derlenip test edilemedi** (Flutter
  SDK yok). `flutter pub get` + gerçek cihaz/emülatör testi şart -
  özellikle Forge2D'nin tam API imzaları (`World.stepDt` argüman
  sayısı, `ContactListener` metod imzaları, `BodyDef.bullet` alanı)
  paket sürümüne göre küçük farklılıklar gösterebilir, analyzer hata
  verirse bu noktalara bak.

## YENİ (v13): Fizik referans videoya göre yeniden ölçüldü ve kalibre edildi

Referans video (Mystery Town, 1080x2340) 42-60 fps kare-kare analiz edildi
(12 atış izlendi); oyunun fiziği Python'a aktarılıp aynı ölçütlerle karşılaştırıldı.

| Ölçüm | Referans | v12 | v13 |
|---|---|---|---|
| Atış çizgisi → uzak duvar süresi | ~0.22-0.25 sn | 0.35 sn | **0.24 sn** |
| Çarpışma sonrası tamamen durma | ~0.15-0.2 sn | ~0.3-0.5 sn | **~0.15-0.2 sn** |
| Hedefin itilme mesafesi | ~0.5-0.6 obje çapı | ~0.8 | **~0.6** |
| Çarpan objenin (sıyırarak) kayması | ~1.4 çap | ~0.5 | **~1.7** |
| Yığının derinliği (masa boyuna oran) | ~%26 | ~%49 | **~%26** |

Değişiklikler:
- `game_theme.dart` → `kBallSizeScale = 0.70` (ilk deneme 0.62 idi, bir tık büyütüldü): tüm objelerin boyutu (fizik + çizim
  + nişan) tek yerden ölçekleniyor. Referansta obje masa genişliğinin ~%6-9'u;
  eskiden %17-58'i idi, bu yüzden yığın masanın ortasına kadar uzuyor, duvara
  yayılıp toplanmıyordu. **Bu, "masaya yayılma / karşı tarafta toplanma"
  farkının ana sebebiydi.** Çok küçük gelirse 0.70'e çıkar; eski boyut için 1.0.
- `game_board.dart` → `_throwFlightSeconds` 0.35 → 0.24; `_settleDragK` 8 → 18
  (sert ve kısa itme); `_strikerSettleDragK` 30 → 16 (çarpan obje ani donmak
  yerine ~1 çap kayıp yerleşir); birleşme süzülmesi ayrı sürtünmeye
  (`_mergeGlideDragK = 8`, `_Ball.gliding`) alındı ve obje boyutuyla ölçeklendi.
- Dokunulmayanlar: geri tepme (0.25), sönümleme (0.85), çarpma hız tavanı (900),
  yanal sapma aralığı (simülasyonda yığın şekline etkisi ihmal edilebilir çıktı).
- ⚠️ Flutter bu ortamda çalıştırılamadığı için kod derlenip cihazda denenmedi;
  sayılar Python simülasyonuyla doğrulandı. Hissi beğenmezsen ince ayar için
  yukarıdaki 4 sabite bak.

Flutter/Dart ile yazılmış, sadece **Android** için yapılandırılmış bir
merge oyunu prototipi. `ios/` klasörü kullanıcı talebi üzerine yalnızca
**iskelet** olarak eklendi, build alınamaz.

## YENİ: Enerji / görev / günlük ödül artık İNTERNET SAATİYLE çalışıyor

Eskiden tüm süre hesapları cihaz saatine (`DateTime.now()`) bakıyordu;
telefonun saatini ileri alan oyuncu enerjiyi, reklam kotasını ve günlük
ödülü bedavaya yenileyebiliyordu. Şimdi:

- **`lib/services/time_service.dart`** (yeni): açılışta ve uygulama
  arka plandan dönünce HTTPS `Date` başlığından sunucu saatini alır
  (`google.com/generate_204`, olmazsa `cloudflare.com/cdn-cgi/trace`).
  Senkrondan sonra geçen süre cihaz saatiyle değil `Stopwatch`
  (monotonik) ile ölçülür → oyuncu saati değiştirse bile `now()` sapmaz.
- `GameProgress` içindeki tüm `DateTime.now()` çağrıları
  `TimeService.instance.now()` oldu (enerji dolumu, reklam-izle kotası ve
  2 saatlik kilit, günlük ödül/streak, günlük-haftalık-aylık görev
  sıfırlamaları).
- `main.dart`: açılışta en fazla ~3 sn senkron beklenir, sonra oyun
  açılır; `resumed` olayında yeniden senkron olunur.
- `AndroidManifest.xml`: `INTERNET` izni eklendi.
- İnternet yoksa cihaz saati kullanılır ama son görülen sunucu saatinin
  gerisine düşmez (saati geri alma hilesi çalışmaz). **Sınır:** tamamen
  çevrimdışıyken saati İLERİ almak bir sonraki senkrona kadar hâlâ işe
  yarar; senkron olunca gelecekteki kayıtlı zamanlar temizlenir.
- Eski kayıtlarda "gelecekte" kalmış enerji/kilit zamanları otomatik
  düzeltilir (enerji yıllarca dolmama hatası olmaz).
- Gün/hafta/ay sınırları oyuncunun kendi saat dilimine göre hesaplanır.

## YENİ: Oyun "Merge Dünyaları" olarak yeniden markalandı

Oyun artık tek bir "Fast Food Dükkanı" değil, birden fazla dünyayı
(Fast Food, Kafe, Büyü&Simya, yakında Korsan/Buz/Uzay/Orman...) kapsayan
bir merge oyunu. Buna göre:

- İsim her yerde güncellendi: `pubspec.yaml`, Android `AndroidManifest.xml`
  (`android:label`), iOS `Info.plist` (`CFBundleDisplayName`),
  `main.dart` (`MaterialApp.title`), `app_strings.dart` (`game_title`).
- Ana menüde (`lib/screens/main_menu_screen.dart`):
  - Arka plan artık eski mutfak fotoğrafı değil, nötr çok-dünyalı bir
    gradyan (mor → lacivert → turkuaz).
  - Başlık artık "Fast Food Dükkanı" yazan hazır bir logo görseli
    değil, metin tabanlı ("Merge Dünyaları" + alt başlık).
  - Ana ekrandaki "hero" obje artık SABİT değil — oyuncunun o an
    ilerlediği (bir sonraki oynanabilir) bölümün ait olduğu dünyanın
    en üst seviye objesini gösteriyor, altında da o dünyanın adı
    yazıyor. Kafe'ye/Büyü&Simya'ya geçince ana ekran otomatik güncelleniyor.
  - Aşçı maskotu (`mascot_chef.png`) kaldırıldı — yemek temasına özel
    olduğu için yerine koyacak nötr bir görsel yoktu.

⚠️ **Eksik kalan (yeni görsel gerektiriyor, elle üretilmesi lazım):**
gerçek bir logo illustrasyonu, çok-dünyalı bir ana menü arka planı ve
(varsa) tüm dünyalara uyan nötr bir maskot karakteri. Bunlar hazır
olduğunda `main_menu_screen.dart`'taki ilgili yerlere kolayca eklenir -
kod tarafı buna hazır, sadece asset path'i eklemek yeterli.

## YENİ: Tema 3 — Büyü & Simya (17-24. bölümler)

Artık 3 tema var. `lib/models/magic_item.dart` + `game_theme.dart`
içindeki `MagicTheme`, `FoodTier`/`CafeTier` ile birebir aynı desende:
8 seviyelik birleştirme zinciri (Büyülü Kristal → İyileştirme İksiri →
Girdap İksiri → Büyücü Şapkası → Kadim Büyü Kitabı → Ejderha Yumurtası
→ Kehanet Küresi → Kaynayan Simya Kazanı), aynı coin ödül eğrisi
(1,2,3,5,8,13,21,34). `ChapterConfig.themeFor()` artık 3 tema arasında
dönüyor (1-8 Fast Food, 9-16 Kafe, 17-24 Büyü&Simya, 25-32 tekrar Fast
Food, ...). Yeni asset'ler `assets/images/magic/` altında (kullanıcının
ürettiği sticker'lardan otomatik olarak 512x512, tutarlı kenar
boşluklu PNG'lere işlendi, arka plan masa görseli zaten 768x1376 hazır
geldi).

## YENİ: Görevler ayrı bir ekrana taşındı, Haftalık + Aylık gorevler eklendi

Eskiden ana menüde 3 günlük görev kartı doğrudan ekranda duruyordu ve
çok yer kaplıyordu. Şimdi:

- Ana menüde, harita ikonunun **hemen solunda** turuncu bir "Görevler"
  ikonu var (`lib/screens/main_menu_screen.dart`).
- Bu ikon `lib/screens/missions_screen.dart` içindeki yeni ekranı açıyor
  — **Günlük / Haftalık / Aylık** sekmeleri halinde 3'er görev (sipariş
  teslimi, birleştirme, coin kazanma).
- `GameProgress` içinde haftalık ve aylık görevler günlük görevlerle
  **aynı olaylardan** (`reportOrderDelivered`, `reportMerge`,
  `reportCoinsEarned`) beslenir, ama kendi hedef/ödül/claim durumlarını
  ve kendi sıfırlama takvimlerini (hafta: Pazartesi, ay: ayın 1'i)
  bağımsız tutar.
- Tüm bu alanlar (ilerleme, claim durumu, sıfırlama tarihleri) mevcut
  kalıcılık sistemiyle (`shared_preferences`) birlikte diske yazılıyor.

## YENİ: Çarpışma tespiti artık uzamsal ızgara (spatial grid) kullanıyor

`lib/widgets/game_board.dart` içindeki `_simulate()` fizik adımında,
çarpışma kontrolü artık her obje çiftini (O(n²)) taramıyor. Objeler her
karede pozisyonlarına göre hücre boyutu = **en büyük objenin çapı**
olan bir ızgaraya dağıtılıyor; her obje yalnızca kendi hücresi ve
komşu 8 hücredeki objelerle karşılaştırılıyor. Bu, tahta çok sayıda
obje ile dolduğunda (50+) frame süresini önemli ölçüde kısaltır —
mekaniğin kendisi (birleşme/itme/momentum) hiç değişmedi, sadece
"hangi çiftler kontrol edilecek" kısmı optimize edildi.

## YENİ: Ana Menü + Dükkan + Bölüm Haritası (uygulama artık tek ekran değil)

Uygulama artık doğrudan oyuna değil, bir **Ana Menü**'ye açılıyor:

- **Ana Menü** (`lib/screens/main_menu_screen.dart`): büyük "Oyna" butonu,
  coin ile satın alınan **2 yükseltme** ("Hızlı Atış" — fırlatışlar
  arası bekleme süresini kısaltır; "Şanslı Başlangıç" — Seviye 2 obje
  gelme ihtimalini artırır), sağ altta yuvarlak bir **harita ikonu**.
- **Bölüm Haritası** (`lib/screens/level_map_screen.dart`): 8 bölümü
  kart olarak listeler. Sadece Bölüm 1 oynanabilir (`GameProgress.
  maxPlayableChapter`), diğerleri "Yakında" etiketiyle kilitli
  görünür. Bölüm 1 tamamlanınca kartın kenarlığı yeşile döner,
  butonu "Tekrar Oyna" olur.
- **Kalıcı ilerleme** (`lib/models/game_progress.dart`): coin bakiyesi,
  yükseltme seviyeleri, günlük ödül/streak, günlük görevler ve enerji
  artık **tek bir singleton'da** tutuluyor ve `shared_preferences` ile
  diske JSON olarak yazılıyor. `main()` açılışta `GameProgress.load()`'u
  bekliyor; her satın alma/claim/enerji harcama gibi mutasyondan sonra
  kısa bir debounce (400ms) ile diske yazılıyor; uygulama arka plana
  alınırken/kapanırken (`AppLifecycleState.paused`/`detached`) bekleyen
  kayıt hemen `flush()` ile diske işleniyor.
- Oyun ekranındaki (`GameBoard`) kırmızı X butonu artık uygulamadan
  çıkmıyor, **Bölüm Haritası'na geri dönüyor**. Bölüm bitince/
  kaybedince çıkan ekranlarda da "Bölüm Haritasına Dön" seçeneği var.

## YENİ: Arayüz referans tasarıma göre yenilendi

Kullanıcının gönderdiği "Mystery Town" referans ekran görüntüsüne göre
üst kısım tamamen değişti:

- **AppBar ve kitap ikonu kaldırıldı.** Yerine referanstaki gibi ahşap
  bir "Bölüm 1" banner'ı + sağda kırmızı X (kapat/yeniden başlat)
  butonu geldi.
- **"Hedef" kartı eklendi** — bölüm ilerlemesini (X/15 sipariş) ahşap
  çerçeveli, "Hedef" etiketli bir kartla gösteriyor. Bu karta
  **dokununca** eski zincir rehberi açılıyor (özellik kaybolmadı,
  sadece ayrı bir ikon olmaktan çıktı).
- **Masa artık "tam boy"**: gereksiz boşluklar/dolgu (padding) azaltıldı,
  masa ekranın kalan tüm alanını kaplıyor.
- **Objeler artık masanın ahşap çerçevesinin üstüne taşmıyor.** Fizik
  sınırları (`_playLeft/_playRight/_playTop/_playBottom`), tüm görsel
  alan yerine görselin ortasındaki oynanabilir yüzeyle eşleşecek
  şekilde kenarlardan içerlek tutuluyor (`_marginLeftRight/_marginTop/
  _marginBottom` sabitleriyle ayarlanabilir).

## YENİ: Gerçek illüstrasyon görselleri entegre edildi

Artık hiçbir yerde emoji/kod-çizimi obje YOK — kullanıcının ürettiği
gerçek illüstrasyonlar kullanılıyor:

- **8 obje ikonu** (`assets/images/tier_1.png` ... `tier_8.png`) — fizik
  toplarının, sipariş kartlarının ve zincir rehberinin hepsinde
  kullanılıyor. Sağ-alt köşede küçük bir seviye rozeti var (özellikle
  tekli/çift burger gibi görsel olarak birbirine yakın objeleri ayırt
  etmek için).
- **Sipariş kartı çerçevesi** (`order_card_frame.png`) — gerçek bir
  "clipboard/fiş" illüstrasyonu, eskiden kod ile çizilen gradyanlı
  kutunun yerini aldı.
- **Coin ikonu** (`coin_icon.png`) — üst bardaki sayaçta, sipariş
  kartlarının ödül satırında ve altın parçacık (coin burst) efektinde
  kullanılıyor.
- **Masa arka planı** (`table_background.webp`) — bir önceki adımda
  eklenmişti, değişmedi.

**Teknik not:** `CustomPainter` doğrudan `Image.asset` widget'ı
kullanamadığı için (fizik toplarını ve parçacıkları tek bir canvas
geçişinde çizdiğimiz için), görseller `initState`'te ham `ui.Image`
olarak arka planda yükleniyor (`_loadTierImages`). Yüklenene kadar
(genelde birkaç yüz milisaniye) eski kod-çizimi (renkli daire + emoji)
otomatik olarak devrede kalıyor, böylece ekran hiçbir zaman bozuk/boş
görünmüyor.

## YENİ: Zincirleme "yanlış obje patlaması" hatası düzeltildi

| Şikayet | Sebep | Düzeltme |
|---|---|---|
| Sipariş olmayan objeler bazen sipariş olan objeyle birlikte patlıyor | Bir sipariş teslim edilince yerine **anında** yeni sipariş geliyordu — bu yeni sipariş bazen tahtada duran, o ana kadar hiçbir siparişle ilgisi olmayan başka bir objeyle rastgele eşleşip onu da AYNI KAREDE süpürüyordu (zincirleme teslimat) | Sipariş slotu artık teslim sonrası **0.9 saniye boş/bekliyor** (kartta küçük bir yükleniyor ikonu görünüyor) — bu süre boyunca hiçbir obje o slotla eşleşemez, zincirleme patlama tamamen engellendi |

## "Görünmeden patlama" hatası düzeltildi

| Şikayet | Sebep | Düzeltme |
|---|---|---|
| Sipariş olmayan objeler de "patlıyor" gibi görünüyor, sipariş edilen obje oluşumu hiç görünmeden teslim ediliyor | İki obje birleşip yeni seviyeye geçince YENİ obje `vx=vy=0` (durgun) olarak oluşuyordu — otomatik teslimat kontrolü bunu AYNI KAREDE görüp anında teslim ediyordu, oyuncu objeyi hiç görmeden kayboluyordu | Her objeye bir "yaş" (`age`) sayacı eklendi. Artık bir obje **en az 0.7 saniye ekranda durduktan sonra** teslim edilebiliyor — birleşip hamburger oluşuyor, sen onu görüyorsun, sonra (eşleşiyorsa) teslim ediliyor |

## YENİ: Dağılma ve otomatik teslimat düzeltmeleri

| Şikayet | Sebep | Düzeltme |
|---|---|---|
| Çarpışınca objeler çok fazla dağılıyor, masanın bir ucundan diğerine gidip yanlışlıkla "Masa Doldu" tetikliyor | Serbest kayarken akıcı olsun diye sürtünme zayıf tutulmuştu, ama bu çarpışma sonrası fırlayan objenin de uzun mesafe kaymasına sebep oluyordu (bilardo hissi) | Serbest kayma sürtünmesi ayrı, **çarpışma sonrası enerji kaybı** ayrı ele alındı: `restitution=0.22`, çarpışma sonrasına özel `postCollisionDamping=0.32` (ekstra sönümleme) ve `170px/s` mutlak hız tavanı eklendi. **(Sonradan güncellendi: bu değerler hedefi çok yumuşak bıraktığı için `_collisionRestitution=0.5`, `_postCollisionDamping=0.7`, tavan `240px/s` yapıldı; ayrıca tam kafa kafaya çarpışmalara rastgele ±15° yanal sapma eklendi — bkz. `game_board.dart` → "Obje-obje çarpışma ayarları".)** Artık gerçek hayattaki gibi çarpışan obje anında "küt" diye enerjisini kaybedip duruyor, masanın diğer ucuna kaymıyor — ama serbest atışlar hâlâ akıcı kayıyor |
| Teslimat için objeye dokunmak gerekiyordu | Manuel tasarım | Artık **tamamen otomatik**: durgun bir obje açık bir siparişle aynı seviyedeyse, dokunmadan kendiliğinden teslim ediliyor (coin + altın parçacık efekti). Manuel dokunma mantığı (`_tryFulfillOrderAt`, `_findBallAt`) tamamen kaldırıldı |

## YENİ: Bölüm nasıl bitiyor?

Önceki sürümde oyun **hiç bitmiyordu** — sadece bir kaybetme durumu
vardı (masa dolunca). Şimdi net bir hedef var:

- Üst bardaki ilerleme çubuğu **"Bölüm 1: X/15 sipariş"** gösteriyor.
- **15 sipariş** teslim edince "🎉 Bölüm 1 Tamamlandı!" ekranı çıkıyor
  (toplam kazanç özetiyle birlikte), "Tekrar Oyna" butonuyla baştan
  başlayabilirsin.
- Bunun dışında hâlâ bir kaybetme durumu var: masa dolarsa (obje atış
  noktasına yakın bölgede durursa) "Masa Doldu!" ekranı çıkıyor, o ana
  kadar kaç sipariş tamamladığını gösteriyor.
- Hedef sayısını değiştirmek istersen `game_board.dart` içindeki
  `_chapterGoal` sabitini güncelle (şu an `15`).
- Bölüm 3 henüz yok, o yüzden tamamlayınca şimdilik sadece "Tekrar
  Oyna" var — ileride buraya "Bölüm 2'ye Geç" butonu eklenecek.

## Fizik hissi ve efekt düzeltmeleri

| Şikayet | Sebep | Düzeltme |
|---|---|---|
| Çarpışmalar yumuşak/etkisiz | Farklı seviyeler çarpışınca sadece pozisyon düzeltiliyor + hız sönümleniyordu, gerçek itme yoktu | Eşit kütle varsayımıyla **gerçek momentum aktarımı** (impulse-based) eklendi, `restitution=0.9` ile sert/zıplı çarpışma |
| Tahta doldukça hız yavaşlıyor | Performans düşünce (O(n²) çarpışma kontrolü) frame süresi uzuyor, kod uzun frame'leri tamamen ATLIYORDU | Artık uzun frame'ler **alt-adımlara (substep)** bölünüyor — gerçek zamanlı hız hep sabit kalıyor. Ayrıca durgun obje çiftleri çarpışma kontrolünden muaf tutuluyor (performans) |
| "+5 coin" yazısı ekranı büyütüp küçültüyor | Toast metni koşullu olarak eklenip çıkarılıyordu, Column'un yüksekliği değişiyordu | Coin kazanımlarında artık metin YOK — **altın parçacık (coin burst) efekti** var. Kalan uyarı metni (`_toast`) için de sabit yükseklikli alan ayrıldı, layout artık hiç zıplamıyor |

## Bölüm 2: Sipariş Sistemi (Gossip Harbor / Merge Mansion referanslı)

Ekranın üst kısmında her zaman **3 açık sipariş** görünür — referans
videodaki "To-Go Order" fişiyle aynı görsel dil (kağıt fiş görünümü,
gradyanlı arka plan, gölge). Her sipariş belirli bir seviyede obje
istiyor:

- Tahtada o seviyeye uyan bir objeye **dokunursan** sipariş otomatik
  teslim edilir: obje tahtadan kalkar, coin kazanırsın (normal
  birleştirme ödülünün **2 katı**), o slota hemen yeni bir sipariş gelir.
- Eşleşen bir obje tahtadaysa sipariş kartının kenarlığı **yeşile**
  döner (`deliverable` göstergesi) — hangi siparişi hemen
  karşılayabileceğini bir bakışta görürsün.
- Düşük seviyeler (Lv1-Lv2) sık, yüksek seviyeler (Lv5-Lv6) nadir
  istenir — ağırlıklı rastgele seçim (`_generateOrder`).
- Sipariş istemediğin bir objeye dokunursan (eşleşme yoksa) hiçbir şey
  olmaz, sadece uyarı gösterilir — yanlışlıkla obje kaybetmezsin.

## Görsel iyileştirmeler ("profesyonel" görünüm)

- **Toplar artık düz renk değil:** Radyal gradyan ile cilalı/parlak
  (glossy) bir sfer görünümü var — üst-sol köşede beyaz bir
  "highlight" noktası, kenarlarda hafif koyulaşma. Cam/plastik bir
  obje hissi veriyor.
- **Sipariş kartları:** Kağıt fiş dokusu (krem-bej gradyan), yuvarlak
  köşeler, gölge, ortada objenin kendi glossy rozeti.
- Masa görseli hâlâ `CustomPainter` ile ahşap çerçeve + damar dokusu +
  iç gradyanlı oyun yüzeyi olarak çiziliyor (Bölüm 1'den).

## Mekanik: Shuffleboard tarzı kaydırma (referans videoyla birebir aynı)

Referans olarak gönderilen video incelendi: bu, "Tasty Travels" adlı
oyunun **gerçek oyun içeriği değil**, reklam amaçlı özel bir mini oyunu
("playable ad") — shuffleboard/air-hockey tarzı bir kaydırma oyunu.
Mekanik buna göre kuruldu:

- Masa tamamen boş başlar, grid/hücre sistemi yok.
- Oyuncuya yakın (alt) tarafta sabit bir **atış noktası** var. Orada
  **rastgele** bir obje belirir — **"Sıradaki" önizleme kutusu YOK**,
  obje atış noktasında belirdiği an ne olduğu görülür.
- Parmağını sürükleyerek yatayda nişan alırsın (dikey nişan çizgisi).
- Parmağını kaldırdığında obje **yukarı** (masanın uzak ucuna doğru)
  fırlar — yukarıdan aşağı DÜŞMEZ, tam tersi yönde kayar.
- Yer çekimi yok; obje sabit hızla fırlar ve **sürtünmeyle yavaşlayarak**
  durur (gerçek bir shuffleboard/air-hockey gibi).
- Sadece **gerçekten çarpışan** (iç içe geçen) aynı seviyedeki objeler
  birleşir — aralarında mesafe varsa hiçbir şey olmaz, "boşluktan
  eşleşme" hatası düzeltildi.
- Farklı seviyeler çarpışırsa fiziksel olarak ayrılır ve enerjileri
  belirgin şekilde söner (önceki sürümdeki sonsuz titreme/zıplama
  düzeltildi): düşük hız eşiğinin altına inen objeler tam olarak
  durur, ufak ondalık sapmalarla asla titremez.
- Objeler atış noktasına yakın bölgede durursa ("Masa Doldu") oyun
  biter, "Yeniden Başla" ile sıfırlanır.
- Masa artık düz bir renk değil: ahşap çerçeveli, iç yüzeyi hafif
  gradyanlı, damar dokulu gerçek bir masa görseli olarak
  `CustomPainter` ile çiziliyor (bkz. `_TablePainter` sınıfı).

## Önceki sürümdeki hatalar ve düzeltmeleri

| Şikayet | Sebep | Düzeltme |
|---|---|---|
| "Sıradaki" olmamalı | Üstte ayrı bir önizleme kutusu vardı | Tamamen kaldırıldı, obje sadece atış noktasında belirir |
| Objeler titriyor | Çarpışma sonrası hız hiç sönümlenmiyordu, sonsuz küçük düzeltmeler birikiyordu | Çarpışma sonrası hız güçlü şekilde sönümleniyor + düşük hız eşiğinde tam sıfıra kilitleniyor |
| Aralarında engel yokken direkt eşleşiyor | Çok küçük çakışmalarda bile birleşme tetikleniyordu | Artık yalnızca `overlap > 0.4px` gibi gerçek bir çakışma varsa işlem yapılıyor |
| Yukarıdan aşağı düşüyor | Suika Game mantığıyla (yanlış varsayım) yazılmıştı | Yer çekimi tamamen kaldırıldı, atış noktasından yukarı doğru sürtünmeli kayma mantığına geçildi |
| Masa çizimi kötüydü | Düz renkli `Container` kullanılıyordu | `CustomPainter` ile ahşap çerçeve + damar dokusu + iç gradyan eklendi |
| Karşı uca gidip geri sekiyor, tekrar gidiyor | Duvara çarpınca hız ters çevrilip azaltılarak geri yansıtılıyordu (`-vx*0.4`) | Artık duvara çarpınca **tam durur** (hız sıfırlanır), hiç sekmiyor |
| Hareket donuk/takılmalı görünüyor | Her obje ayrı bir widget'tı (Positioned+Container+FittedBox+Column), bu ağaç saniyede ~60 kez yeniden kuruluyordu | Tüm objeler artık tek bir `CustomPainter` (`_BallsPainter`) ile tek canvas geçişinde çiziliyor — widget ağacı hiç değişmiyor, çok daha akıcı |

## Bölüm 1 içeriği

8 seviyelik Fast Food zinciri:

| Seviye | Obje | Coin Ödülü |
|---|---|---|
| 1 | Tekli Patates Kızartması | +2 |
| 2 | Kutu Patates | +5 |
| 3 | Soğan Halkası Tabağı | +10 |
| 4 | Tek Katlı Cheeseburger | +20 |
| 5 | Çift Katlı Big Burger | +40 |
| 6 | Pizza Dilimi | +80 |
| 7 | Tam Boy Büyük Pizza | +160 |
| 8 | Dev Ziyafet Menüsü Tepsisi | +320 |

AppBar'daki kitap ikonu tüm zinciri gösteren rehberi açar.

> Not: Fizik/zorluk ayarlarını değiştirmek istersen
> `lib/widgets/game_board.dart` en üstündeki sabitlere bak:
> `_launchSpeed` (fırlatma hızı), `_frictionPerSecond` (ne kadar hızlı
> yavaşlasın), `_dangerLineFraction` (oyun sonu çizgisinin konumu).

## FlutLab'de çalıştırma

1. Bu klasörün tamamını (pubspec.yaml, lib/, android/) FlutLab
   projenize yükleyin / import edin.
2. FlutLab terminalinde `flutter pub get` çalıştırın.
3. Cihaz olarak **Android** seçip Run/Play tuşuna basın.
4. `ios/` klasörüne dokunmayın — FlutLab zaten Android odaklı çalışır,
   bu klasör sadece ileride gerçek bir Mac ortamında tamamlanmak üzere
   iskelet olarak duruyor (detay: `ios/README_ISKELET.md`).

## Yerel makinede çalıştırma (VS Code / Android Studio)

```bash
flutter pub get
flutter run -d android
```

## Proje yapısı

```
lib/
  main.dart                        -> Uygulama giriş noktası (artık MainMenuScreen açılıyor)
  models/food_item.dart            -> 8 seviyelik Fast Food zinciri (isim, renk, emoji, ödül, yarıçap)
  models/food_order.dart           -> Sipariş veri modeli (seviye, coin ödülü)
  models/game_progress.dart        -> Kalıcı ilerleme (coin, kilitli bölümler, yükseltmeler) - singleton
  screens/main_menu_screen.dart    -> Ana menü: Oyna butonu, dükkan/yükseltmeler, harita ikonu
  screens/level_map_screen.dart    -> Bölüm seçim ekranı (oynanan/kilitli/yakında)
  widgets/order_card.dart          -> Profesyonel görünümlü sipariş fişi kartı
  widgets/game_board.dart          -> Fizik motoru + sipariş mantığı + tek-canvas render + nişan/atış/teslim girişi
android/                           -> Tam Android proje dosyaları (Gradle, Manifest, ikonlar)
ios/                               -> ISKELET, build alınamaz
```

## YENİ: Tema 6 — Uzay İstasyonu (41-48. bölümler)

Artık 6 tema var ve sırayla dönüyor: 1-8 Fast Food, 9-16 Kafe & Pastane,
17-24 Büyü & Simya, 25-32 Korsan Hazinesi, 33-40 Buz Krallığı,
**41-48 Uzay İstasyonu**, 49-56 tekrar Fast Food, ...

- `lib/models/space_item.dart` (`SpaceTier`/`SpaceTiers`) + `game_theme.dart`
  içindeki `SpaceTheme` — diğer temalarla birebir aynı desen. Ödüller
  aynı Fibonacci dizisi (1,2,3,5,8,13,21,34).
- `ChapterConfig.themeFor()` artık `block % 6` kullanıyor (Uzay = son dal).
- Görseller: `assets/images/space/` (masa: `table_space.webp` 768×1376,
  objeler: `space_tier_1..8.png`, 512×512 şeffaf). Objeler kırpılıp kare
  tuvale ortalandı, böylece GameBoard'un kareye sığdırması oranı bozmuyor.
- Zincir (1→8): Uzay Cıvatası → Devre Kartı → Enerji Kristali → Keşif
  Drone'u → Astro Robot → Siber Kask → Kozmik Muhafız → Yıldız Gemisi.
- Dil anahtarı: `theme_space` (TR: Uzay İstasyonu, EN: Space Station).
- Not: 5 → 6 tema geçişinde 41+ bölümlerin teması değişti (eskiden 41-48
  tekrar Fast Food'du, şimdi Uzay).

## YENİ: Ses efektleri + titreşim

Tüm kararlar TEK dosyada: `lib/services/game_fx.dart` (hissi değiştirmek
için sadece oradaki sayılara bak). Altyapı: `sfx_service.dart` (ses
havuzu, `audioplayers 6.1.0`), `haptic_service.dart` (Flutter'ın hazır
`HapticFeedback`'i — ek paket/izin yok).

| An | Ses | Titreşim |
|---|---|---|
| Atış | `throw` (yumuşak fiiit) | hafif |
| Farklı objeler çarpışınca | `hit_1..4` (obje büyüdükçe daha derin) | sadece sert çarpmada hafif/orta |
| Masa kenarına çarpma | `wall` (yumuşak tok) | yok (her atışta olurdu, yorucu) |
| Merge | `merge_2..8` (pentatonik gamda yükselir) | seviyeyle artar: hafif → orta → ağır |
| Bu tur ilk kez yüksek seviye (≥4) | `new_tier` ek parıltı | ağır+orta ("ta-DUM") |
| En üst seviye merge | `merge_max` | ağır-orta-ağır |
| Sipariş teslimi | `coin` (ka-ching) | çift kısa tik |
| Bölüm tamamlandı | `chapter_complete` fanfarı | artan şiddet + parıltı tikleri |
| Masa doldu | `game_over` (yumuşak alçalan) | iki ağır + orta |
| Buton / ödül / satın alma / yetersiz coin | `tap` / `reward` / `denied` | tik / kısa desen |

- Ana menü sağ üstte **ses** ve **titreşim** aç/kapa butonları var
  (`GameProgress.soundEnabled/hapticsEnabled`, diske kaydedilir).
- Ses başka uygulamaların müziğini durdurmaz (mixWithOthers).
- Sesler `tools/generate_sfx.py` ile sıfırdan sentezlendi (telifsiz,
  toplam ~1,4 MB). Beğenmediğin sesi `assets/sfx/` altında AYNI İSİMLE
  kendi .wav'ınla değiştir, kod değişmez. Yeni ses eklersen
  `SfxService.names` + `pubspec.yaml` listesine de ekle.
- Bug fix: `_simulate()` artık tur bittikten sonra kalan alt-adımlarda
  çalışmıyor. Eskiden 60 FPS'te oyun sonu aynı karede 2 kez tetiklenip
  (ikinci kayıpta) enerjiyi 2 kez harcayabiliyordu.

## Sırada ne var (yol haritası)

- ~~**Ana Menü + Dükkan + Bölüm Haritası**~~ ✅ Tamamlandı (bu sürümde).
- ~~**Kalıcılık:** `shared_preferences` ile coin/ilerlemeyi diske
  yazma~~ ✅ Tamamlandı (bu sürümde) — bkz. "Kalıcı ilerleme" bölümü.
- ~~**Bölüm 2:** Sipariş sistemi~~ ✅ Tamamlandı (önceki sürümde).
- **Bölüm 3:** Güç-yükseltmeleri — ödüllü reklamla açılan yardımcılar.
- **Bölüm 4:** Reklam entegrasyonu (rewarded video) — oyun bittiğinde
  "reklam izle, devam et" gibi.
- **Sonraki temalar:** Kahve & Pastane, Büyü & Simya (aynı mimariyle,
  sadece `food_item.dart` dosyasındaki zincir verisi değişecek).

## YENİ: Sınırsız bölüm ilerlemesi (sabit "8 bölüm" kaldırıldı)

Artık sabit bir bölüm sayısı YOK — "ilerleyebildiğin kadar ilerle" mantığı:

- **`ChapterConfig`** (`lib/models/game_theme.dart`): her bölüm numarası
  için temayı ve hedefi anlık üretir. Elimizdeki 2 tema (Fast Food,
  Kafe & Pastane) 8'er bölümlük bloklar halinde sırayla dönüyor
  (1-8 Fast Food, 9-16 Kafe, 17-24 tekrar Fast Food, ...) — 3. bir tema
  eklendiğinde tek değişecek yer `ChapterConfig.themeFor()`.
- **Zorluk eğrisi iki katmanlı:**
  1. Sipariş hedefi (`goalFor`) her blok içinde 15→50 artıyor, her yeni
     blokta (yeni döngü) taban +20 yükseliyor — hiçbir zaman sıfırlanmıyor.
  2. Sipariş **içeriği** de zorlaşıyor: `difficultyT` bölüm numarasına
     göre 0→1 arası bir katsayı üretir (40. bölümde platoya oturur),
     `_generateOrder()` bu katsayıyla düşük seviye siparişlerin ağırlığını
     azaltıp yüksek seviyelerinkini artırır.
- **Bölüm Haritası artık büyüyerek gösteriliyor:** `GameProgress.
  maxUnlockedChapter` + birkaç kilitli önizleme kartı kadar kart
  listeleniyor (sabit 16 değil) — bölüm bitirildikçe liste kendiliğinden
  uzuyor.
- **"Sonraki Bölüm →" butonu:** bölüm tamamlanınca haritaya dönmeden
  doğrudan bir sonraki bölüme geçilebiliyor (zincirleme oynanış).
- `GameProgress.maxPlayableChapter` (eski "8'in ötesi Yakında" kilidi)
  tamamen kaldırıldı.

## YENİ: TR/EN dil desteği, görsel varlıklar, retention + coin sink paketi

- **Yerelleştirme:** `lib/localization/app_strings.dart` — anahtar bazlı
  hafif TR/EN sözlüğü (intl/ARB paketi yok, bu ölçekte gereksiz). Ana
  menüde sol üstte dil değiştirme butonu var.
- **Görseller entegre edildi:** ana menü arka planı, logo banner'ı ve
  şef maskotu artık kullanıcının ürettiği gerçek illüstrasyonlar
  (`assets/images/menu_background.webp`, `menu_logo.png`,
  `mascot_chef.png`).
- **Bug fix:** sipariş kartları artık aktif temanın (Fast Food/Kafe)
  görsellerini kullanıyor — eskiden Kafe bölümlerinde bile Fast Food
  görselleri çıkıyordu.
- **Dükkan yükseltmeleri 3 → 15 seviyeye çıkarıldı**, maliyetler
  kademeli artan bir eğriye oturtuldu (150'den 19.000'e kadar).
- **YENİ yükseltme: Ekstra Sipariş Slotu** (3 → 5 slot, 2 seviye).
- **YENİ: Sonraki obje önizlemesi** — atış noktasının sağ üstünde
  sabit bir rozet, bir sonraki fırlatılacak objeyi gösteriyor.
- **YENİ: Günlük ödül + 7 günlük streak** — ana menüde üstte bir
  banner, art arda gelince ödül büyüyor, bir gün atlanırsa sıfırlanıyor.
- **YENİ: Günlük görevler** (sipariş teslim et / birleştirme yap /
  coin kazan) — ilerleme çubuğu + hedefe ulaşınca "Al" butonu.
- Bu retention sistemleri `DateTime.now()` ile gün sınırı hesaplıyor;
  ilgili alanlar (`lastDailyRewardClaim`, `dailyStreak`,
  `missionsResetDate`, `mission*Progress/Claimed`) artık `GameProgress`
  ile birlikte diske yazılıp geri okunuyor.

## Bilinen sınırlamalar (Bölüm 1 kapsamı)

- Kalıcı kayıt tek cihaz/tek kullanıcı: bulut senkronizasyonu (Play
  Games/Game Center girişiyle cihazlar arası ilerleme) yok, sadece
  `shared_preferences` ile yerel diskte tutuluyor.
- Fizik, gerçek bir motor (Box2D/Forge2D) değil, basitleştirilmiş elle
  yazılmış bir simülasyon. Çarpışma tespiti artık **uzamsal ızgara
  (spatial grid) tabanlı broad-phase** kullanıyor — her obje sadece
  fiziksel olarak yakınında olabilecek objelerle karşılaştırılıyor
  (eskiden her obje HER objeyle, O(n²), kontrol ediliyordu). Yine de
  gerçek bir motorun sahip olduğu süreklilik/continuous collision,
  "uyuyan cisim" (sleeping body) gibi ileri optimizasyonlar yok —
  gerçek cihazda 50-100+ obje ile stres testi hâlâ önerilir.
- Masa görseli 2D düz üstten görünüm; referans videodaki 3D perspektif
  (uzağa gittikçe küçülen masa) bu sürümde yok, sadece ahşap doku var.
- Reklam SDK'sı entegre değil (AndroidManifest'te INTERNET izni bilerek
  kapalı bırakıldı, yorum satırında not var).

**v8 (referans video ölçümü):** Atış uçuşu hızlandırıldı: top masanın uzak ucuna `_throwFlightSeconds` (0.35 sn) içinde sabit hızla uçar (referansta ölçülen ~0.3 sn; eskiden ~2 sn yavaşlayarak süzülüyordu). Çarpışma tepkisi v6 ile aynı kalsın diye çarpma anında topun hızı eski sürtünmeli modelin vereceği "sanal hıza" indirilir (`_virtualThrowSpeed`). Uçuşta alt-adımlar 1/480 sn'ye sıklaştırılır.

**v9 (referans videonun 30. sn sonrası ölçümü):** Çarpışma sonrası hedef ~0.5–1.5 obje çapı SERT itilip ~0.3 sn'de durur (eskiden hafif sürtünmeyle masanın ucuna kadar süzülüyordu). Atılan topun çarpma hızı sabit `_thrownImpactSpeed=900`'e indirilir, çarpışma sonrası objelere üstel sürtünme `_settleDragK=14` uygulanır, restitution 0.35 / damping 0.75, yanal sapma ±~29°. Hepsi `game_board.dart` başındaki sabitlerden ayarlanır.

**v10 (v9 sonrası: objeler masanın ortasında kalıyor):** Sorun: v9'da çarpışma sonrası çok sert sürtünme (k=14) ve durgun doğan birleşme objeleri yığının masanın ortasına doğru uzamasına yol açıyordu (simülasyonda yığın önü v9'da masanın ~%56'sına kadar geliyordu). Düzeltme: `_settleDragK=8`, `_collisionRestitution=0.25`, `_postCollisionDamping=0.85` ve referans videoda ölçülen **birleşme süzülmesi** (`_mergeGlideSpeed=400`: birleşen obje ~1 obje çapı uzak duvara doğru süzülür, yığını duvara doğru toplar).

**v11 (tren vagonu / chain sorunu):** Ekran kaydında objeler tek bir hat halinde diziliyordu ("tren vagonu"). Sebep: atılan top hedefe çarpınca hedefi az iter, kendisi de temas noktasının hemen gerisinde durup yığına katılmak yerine yığının UCUNA yeni bir halka ekliyordu. Düzeltme:
- `_headOnThreshold` 0.25→0.45, `_collisionScatter` 0.5→0.9 rad (~52°): daha çok çarpışma yanal sapma alıyor.
- Yeni `_strikerSettleDragK=30`: çarpan (atılan) top, hedeften çok daha güçlü sürtünmeyle çarpma noktasına "yapışıyor", hattı uzatmıyor.
- Birleşme süzülmesi artık tam dikey değil, `_collisionScatter` genişliğinde rastgele açıyla dağılıyor.
Simülasyonda (PCA elongation oranı, >1 = hat gibi) ortalama 3.2'den 2.5'e, rastgele atış sapmasıyla birlikte en kötü durumlarda (aşırı uzun hat) ortalama 91'den 2.5'e indi.

**v12 (dağılma hâlâ zayıftı):** v11'deki sapma açısı saf rastgeleydi (-max..max), bu yüzden bazı çarpışmalarda şans eseri 0'a yakın bir açı çıkıyor, top yine düz gidip hatta ekleniyordu. Şimdi açının bir TABANI var: `_collisionScatterMin=0.45` (~26°) ile `_collisionScatterMax=1.2` (~69°) arası rastgele büyüklük + rastgele işaret — yani HİÇBİR sapma neredeyse sıfır olamıyor. `_headOnThreshold` da 0.45'ten 0.6'ya çıktı, daha çok çarpışma bu mekanizmayı tetikliyor. Simülasyonda en kötü durumdaki hat uzunluğu (PCA elongation) v11'de 10.8 iken v12'de 3.8'e indi.

**v17 (öğretici hareketi düzeltildi — yön):** v16'daki demo, eli çapraz/dikey bir yol boyunca hedefe taşıyordu; ama gerçek oyunda sürükleme SADECE YATAY (sağa-sola nişan alma), bırakınca obje KENDİ KENDİNE yukarı fırlıyor. Artık Faz 1: el sabit bir yükseklikte sağa-sola gidip geliyor (nişan alma), bir noktada "bırakma" darbesi (ring burst) gösteriyor, ardından hayalet obje bağımsız şekilde hızla yukarı fırlıyor - el yerinde kalıp soluyor. Gerçek `onPanUpdate`/`_updateAim` mekaniğiyle birebir aynı his.

## YENİ (v20.3): Merge KOMBO sistemi

- `game_board.dart` → `_registerMergeCombo`: 2.5 sn içinde art arda gelen merge'ler zincir sayılır; 3. zincirden itibaren küçük coin bonusu (+2, +4, +6...) ve ekranda "🔥 xN +bonus" bildirimi + ekstra coin patlaması.
- Ayar sabitleri: `_comboWindowMs`, `_comboMinForBonus`, `_comboBonusPerStep`.
- ⚠️ Flutter bu ortamda yok: derlenmedi, cihazda dene.

## YENİ (v20.4): KASABA (meta ilerleme)

Ana menüde Oyna butonunun altında **Kasaba** şeridi (yükseltilebilir bina varsa kırmızı nokta) → `lib/screens/town_screen.dart`.

- **6 bina** (dünya başına 1), her biri **0 (harabe) → 10** seviye; toplam kasaba seviyesi **0-60**. Bina büyüdükçe o dünyanın daha üst seviye objesi sergilenir.
- **Yükseltme = coin + o dünyada yıldız şartı** (`TownCatalog.baseCost`, `starReq`; maliyet dünya sırasına göre +%15/dünya). Coin sink + eski bölümleri yıldız için tekrar oynatma nedeni.
- **Kalıcı bonuslar** (10. seviyede): Lezzet Durağı +%40 coin • Şirin Kafe +%50 XP • Simya Kulesi +%5 şanslı başlangıç • Korsan Limanı +%100 günlük ödül coini • Buz Sarayı -40 ms atış beklemesi • Uzay İstasyonu +%50 pasif coin üretimi (tüm binalar).
- **Kilometre taşları** (toplam seviye 3,6,10,15,20,25,30,40,50,60): otomatik coin/💎 ödülü; 6 unvan (Küçük Köy → Efsane Diyar).
- Yeni: `lib/models/town.dart` (katalog + tüm denge sabitleri), `GameProgress` (townLevels, upgradeTown, bonus getter'ları, kayıt alanları `townLevels` / `townMilestoneIdx`, eski kayıtlar sorunsuz açılır).
- Bağlanan noktalar: `_addCoins` (coin bonusu), bölüm sonu XP (`applyXpBonus`), `level2Chance`, `throwCooldown`, `claimDailyReward`, `reportChapterComplete`.
- ⚠️ Flutter bu ortamda yok: derlenmedi. `flutter pub get` + cihazda dene; maliyet/bonus dengesini `town.dart`'tan ayarla.

## v20.5: Kasaba kilidi
Bir dünyanın binası, o dünyanın ilk bölümüne ulaşılana kadar kilitli (soluk kart + "🔒 Bölüm N'de açılır"): Kafe=9, Büyü=17, Korsan=25, Buz=33, Uzay=41. Mantık: `GameProgress.townWorldUnlocked`.

## v20.6: ŞANS ÇARKI
Ana menüde Kasaba şeridinin yanında 🎡 butonu (bedava çevirme hazırsa kırmızı nokta) → `lib/screens/wheel_screen.dart`.
- Günde **1 bedava** + **3 reklamli** çevirme (reklam şimdilik `mock_rewarded_ad`). Gün sınırı `TimeService` ile (saat hilesine karşı).
- **8 dilim** (`lib/models/lucky_wheel.dart`, ağırlıklar/ödüller orada): 🪙100/250/500, ⚡enerji dolumu, 🎁booster, 💎2, 💎5 (nadir), 👑1500 jackpot (nadir). Beklenen ~0,5 💎/çevirme.
- **7 gün seri:** art arda 7 gün bedava çeviren 7. gün nadir dilimlerden birini garanti alır.
- **Kasaba bağı:** Korsan Limanı bonusu coin ödüllerine de uygulanır. Oranlar ekranda şeffaf listelenir.
- Ödül çevirme başlarken diske yazılır (uygulama kapansa da kaybolmaz). Kayıt alanları: wheelDay/wheelFreeUsed/wheelAdUsed/wheelStreak/wheelLastFreeDay.
- ⚠️ Flutter bu ortamda yok: derlenmedi. Dart 3 (record sözdizimi) gerekir; pubspec sdk >=3.0.0 uygun.

## v20.7: SEZON YOLU + ARKA PLAN MÜZİĞİ
- **Sezon Yolu** (`lib/models/season.dart`, `lib/screens/season_screen.dart`): aylık, 30 kademe, bedava + premium yol. Ana menüde 🏆 butonu (alınacak ödül varsa kırmızı nokta). Her ayın 1'inde sıfırlanır (`TimeService`).
  - SP kaynakları: sipariş +2, bölüm +8, görev ödülü +15, çark +10, günlük ödül +10. Kademe başına 50 SP. Hepsi `SeasonService` başındaki sabitlerde.
  - Ödül tabloları: `freeReward` / `premiumReward`. Premium satın alma Play Billing ile (`season_pass_premium`, her ay yeniden alınır). Premium yolu tamamen gizlemek için `kSeasonPremiumEnabled = false`.
  - Kayıt kendi anahtarında (`season_v1`), eski kayıtlar etkilenmez. `GameProgress.grantReward` toplu ödül verir.
- **Müzik** (`lib/services/music_service.dart`, `assets/music/loop.wav`): 21.8 sn (8 ölçü, 88 BPM) kesintisiz lofi döngü, ses ayarına bağlı, arka plana gidince durur. Telifsiz Pixabay parçasından üretildi, kaynak/lisans notu: `AUDIO_CREDITS.md`. DİKKAT: `tools/generate_music.py` ve `tools/generate_sfx.py` artık `loop.wav`, `hit_1..4.wav`, `merge_2..8.wav` dosyalarını ESKİ sentetik sesle ezer; çalıştırma.
- ⚠️ Flutter bu ortamda yok: derlenmedi. `flutter pub get` + cihazda dene.

## v20.8: BİLDİRİMLER + KUMBARA
- **Bildirimler** (`lib/services/notification_service.dart`): uygulama arka plana gidince planlanır, oyuna dönünce silinir. Enerji doldu • ertesi sabah 10:00 çark+günlük ödül • sezon bitmeden 2 gün önce • 3 gün gelmezse. 22:00-09:00 arası olanlar 09:00'a kayar. İzin ilk bölüm bitince bir kez istenir. Paketler: `flutter_local_notifications 17.2.4` (bilerek sabit), `timezone`. Android: desugaring + `POST_NOTIFICATIONS` + receiver eklendi. Bildirim ikonu şimdilik uygulama ikonu.
- **Kumbara** (`lib/models/piggy.dart`, `lib/screens/piggy_screen.dart`): sipariş +1, bölüm +5 💎 birikir, tavan 500, kırmak için en az 100. Kırma Play Billing ile (`piggy_bank`), fiyat Play'den gelir. Ana menüde Sezon + Kumbara ikinci satırda.
- ⚠️ Derlenmedi (Flutter yok). `flutter pub get` sonrası paket/Gradle hatası olursa bana yapıştır.

## v20.9: KARŞILAMA + İLK OYUN + HAFTALIK ETKİNLİK + ZOR GÖREVLER
- **Karşılama** (`models/engage.dart`): yeni oyuncuya hoş geldin hediyesi (300 🪙, 10 💎, joker); 2+ gün gelmeyene geri dönüş hediyesi (gün×200 🪙 (en çok 7 gün), tam enerji, 5+ günde 3 💎, 7 günde joker). Ana menüde diyalogla verilir, uygulama kapanırsa kaybolmaz. Eski oyunculara hoş geldin gösterilmez.
- **İlk oyun**: ilk dünyanın hedefleri yumuşatıldı (`goalFor`: 6, 9, 12, 18, 25, 32, 42, 50); ilk 3 bölümü ilk geçişte +150/+250/+400 coin ekstra.
- **Haftalık etkinlik** (`models/weekly_event.dart`, `screens/event_screen.dart`): her hafta tür değişir (sipariş / birleştirme / kombo), 5 kilometre taşı. **Hafta sonu etkinlik ve sezon puanı 2 kat.** Sayılar `WeeklyEvent` başında.
- **Görevler zorlaştırıldı** (`game_progress.dart`): günlük 40 sipariş / 120 birleştirme / 900 coin; haftalık 200/650/5500; aylık 800/2600/22000. Ödüller de yükseldi.
- ⚠️ Derlenmedi (Flutter yok).

## v21: ZORLUK DALGASI + KURAL SİPARİŞİ
- **Bölüm türleri** (`ChapterConfig.kindFor`): her 5. bölüm 🌿 RAHAT (hedef %70, kolay siparişler), her 10. bölüm 👑 BOSS (hedef %50, sadece Lv3-6 yüksek siparişler, sipariş ödülü 2 kat, ilk geçişte +5 💎 +500 coin). Bölüm 5 ve sonrası. Bölüm haritasında ve oyun başlığında ikon, açılışta bildirim.
- **Kural siparişi** (`FoodOrder.anyAbove`): 6. bölümden itibaren "Lv N+ herhangi biri" (N=3-5), kartta mor "Lv3+". Ödül teslim edilen objenin seviyesine göre +%25. Önce birebir eşleşen sipariş, yoksa kural siparişi teslim alır. Boss'ta yok. Olasılık: `%12 + %18×zorluk`.
- ⚠️ Derlenmedi (Flutter yok).


## Gelen Kutusu + Arkadaş Davet
- Ana menüde alt çubukta **Mesaj Kutusu** (eski Dükkan yerine); **Dükkan** artık sol sütunda Mağaza'nın altında.
- Ekran: `lib/screens/inbox_screen.dart` (sekmeler: MESAJLAR / DAVETLER), istemci: `lib/services/inbox_service.dart`.
- **Yapılacak:** worker'ı yayınlayınca `InboxService.baseUrl` içindeki `HESAP` kısmını gerçek adresle değiştir
  (değiştirene kadar servis hiç ağ isteği yapmaz, ekran "yakında" gösterir).
- Paylaşım menüsü `MainActivity.kt` içindeki küçük bir MethodChannel ile açılır (ek paket yok).
- Kimlik ve "verilmiş ödüller" listesi bulut kaydına dahildir (`invite_v1`, bkz. `save_merge.dart`).

### v84: sunucu istekleri azaltıldı + push bildirimi
- **Ne zaman istek gider:** (1) uygulama açılışında / arka plandan dönünce (en çok 3 dk'da bir), (2) davet edilen oyuncu 7. seviyeye
  ulaşınca (`GameProgress.onLevelUp` → `InboxService.onPlayerLevelUp`; davet edilmemiş ya da zaten onaylanmış oyuncuda istek yok),
  (3) push bildirimi gelince / bildirime dokunulunca, (4) gelen kutusu ekranı açılınca ve elle yenilenince. Menüdeki 3 dakikalık
  periyodik yenileme **kaldırıldı**.
- **Push ("Gelen kutunda mesajın var"):** `lib/services/push_service.dart` (Firebase Cloud Messaging, ücretsiz). İçerik bildirimde
  görünmez; metinler `android/app/src/main/res/values*/strings.xml`. Firebase bilgileri `google-services.json` olmadan
  `PushService` içindeki 4 sabitten verilir; doldurulana kadar servis hiçbir şey yapmaz.
- **Tek istek:** Bir senkron artık `POST /v1/sync` ile **1 istek** (eskiden progress + status + inbox = 3). Worker eski sürümse
  (`/v1/sync` yok → 404) istemci eski 3 istekli yola düşer.
- **Yapılacak:** Firebase projesi aç → Android uygulaması ekle (`com.sitora.ai`) → `PushService` sabitlerini doldur →
  worker'a `FCM_SERVICE_ACCOUNT` secret'ı ekle (worker README'sindeki "Push bildirimi").
- ⚠️ Derlenmedi (Flutter yok); `firebase_core ^4.11.0` / `firebase_messaging ^16.4.0` ile `flutter pub get` hata verirse sürümleri güncelle.

## Çoklu dil (v127)

Desteklenen diller: TR, EN, ES, PT-BR, DE, FR, RU. İlk açılışta cihaz dili seçilir
(desteklenmiyorsa EN), Ayarlar > Dil listesinden değiştirilir ve kalıcıdır
(`shared_preferences`, anahtar `app_language`).

- `lib/localization/app_strings.dart`: `t('anahtar')` ve `lt('English kalıp {0}', [arg])`.
- `lib/localization/translations.dart`: ES/PT/DE/FR/RU çevirileri + eşya adları (`kItemNames`).
- Eksik çeviri İngilizceye düşer. Oyun adı ("Worlds Merge") hiçbir dilde çevrilmez;
  splash başlığı kodda sabit, yazı tipi Baloo2.
- Yeni dil eklemek: `AppLanguage` enum'una değer, `nativeName`, `translations.dart`'a satırlar.
- Arapça (AR) ve Endonezce (ID) henüz yok. AR için sağdan-sola arayüz testi gerekir.

## v254 — Fırlat (Mod 1) masa doluluğu / zorluk testere dişi
- **Dolu masa:** 1-2. bölüm boş; 3. bölümde %20 dolu başlar, 40. bölümde %45'e çıkıp sabitlenir (`startPrefill=0.20`, `prefillFullChapter=40`, `maxPrefill=0.45`). Testere dişi: rahat (5'in katları) x0.5, rahat tier x0.6, zor tier x1.15, boss x1.0. Kayıptan sonra yarıya iner (eski davranış).
- **Sipariş alt seviyesi:** `order_floor_ch3/4/5` varsayılanı 9/13/19 → 6/10/15 (Lv3 siparişi 6. bölümden, Lv4 10'dan, Lv5 15'ten). ⚠️ Firebase'de yayındaysa panel değeri ezer.
- **Düşük seviye sınırı:** `kMaxLowLevelBalls` 16 → 22.
- **Otomatik teslim** ve **baskı başlangıcı (9. bölüm)** değişmedi.
- ⚠️ Derlenmedi/test koşulmadı. `prefill_test` ve `order_floor_test` yeni değerlere göre güncellendi.
- **v255:** Dolu masadaki hazır toplardan koyu tonlama + halka kaldırıldı (kural aynı: hazır toplar birleşmeden teslim edilmez).
- **v256:** Dolu masayı ilk gören oyuncuya bir kerelik koç notu: hazır objeler birleşmeden teslim edilmez (`sp_prefab`, 6 dil).
- **v257:** **Bomba güçlendirici** (pervane yerine). Dokunulan noktanın çevresini (yarıçap 100) patlatır, engel/buzlu dahil (`BoosterType.bomb`, 40 elmas). Rastgele bomba atışı kaldırıldı (`bombChance`=0). Eldeki pervaneler (`boosterFan`) bombaya dönüşür. Korsan teması kuralı: "Cursed cargo" (buzlu + sandık), mutator "Gold rush" (süre -%20, coin x1.4), boss "Korsan Kaptan" (süre x0.85, ceza +1 dondurma). Çekiç aynen duruyor. ⚠️ Engel bölümlerinde (31+) engeli artık yalnız bomba güçlendirici kırar.
- **v258:** Masa dolunca (tehlike çizgisinin %85'i, %75'te söner) bomba butonu turuncu nabız atar (`_bombGlow`, `_PulseGlow`; pratik/rehber/öğretici hariç). Bölüm ilk geçiş +1 mücevher 20 → 30. bölüme uzatıldı (`chapterFirstClearGemsUntil`).
- **v259:** Güçlendirici butonları yenilendi: her birine kendi rengi (gradyan), krem çerçeve, üstte parlak yansıma, alt gölge, sayı/elmas hapı; aktif butonda büyüme (`_BoosterButton`).
- **v260:** Fiyatlar: nişan 20, çekiç 25, bomba 50, enerji dolumu 30 mücevher (yükselt 40, joker 45, devam 70 aynı). Play paketleri (öneri): gems_80 0,99$ / gems_550 4,99$ / gems_1200 9,99$ / gems_7000 49,99$ / starter_pack 1,99$ / piggy_bank 2,99$ / season_pass_premium 4,99$.
