import 'package:flutter_test/flutter_test.dart';
import 'package:fastfood_merge/models/game_theme.dart';

void main() {
  test('dolu masa: 1-2. bolum bos, 3. bolum %20, plato sonrasi tavan', () {
    expect(ChapterConfig.prefillFraction(1), 0);
    expect(ChapterConfig.prefillFraction(2), 0);
    expect(ChapterConfig.prefillFraction(3), closeTo(0.20, 1e-9));
    for (var c = 3; c <= 300; c++) {
      final f = ChapterConfig.prefillFraction(c);
      expect(f, greaterThan(0));
      expect(f, lessThanOrEqualTo(ChapterConfig.maxPrefill * 1.15 + 1e-9), reason: 'bolum $c');
    }
  });

  test('dolu masa: testere disi - ayni blokta kolay bolum zordan az dolu', () {
    // Blok 17-24: 18 kolay, 22 zor.
    expect(ChapterConfig.prefillFraction(18), lessThan(ChapterConfig.prefillFraction(22)));
    expect(ChapterConfig.prefillFraction(15), lessThan(ChapterConfig.prefillFraction(14))); // 5'in kati rahat
  });

  test('dolu masa: tehlike cizgisi gevsemesi 0..1 arasi', () {
    for (var c = 1; c <= 300; c++) {
      final e = ChapterConfig.prefillEase(c);
      expect(e, inInclusiveRange(0.0, 1.0));
    }
  });
}
