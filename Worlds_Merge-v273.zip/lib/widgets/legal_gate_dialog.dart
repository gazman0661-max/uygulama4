import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../localization/app_strings.dart';
import '../screens/legal_screen.dart';
import '../services/analytics_service.dart';
import '../services/legal_consent_service.dart';
import 'ui_kit.dart';

/// Ilk acilis zorunlu onay penceresi. Kapatilamaz; ya onaylanir ya uygulamadan cikilir.
class LegalGateDialog extends StatefulWidget {
  const LegalGateDialog({super.key});

  static Future<void> show(BuildContext context) {
    return showGeneralDialog<void>(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.78),
      transitionDuration: const Duration(milliseconds: 350),
      pageBuilder: (_, __, ___) => const LegalGateDialog(),
      transitionBuilder: (_, anim, __, child) => FadeTransition(
        opacity: anim,
        child: ScaleTransition(scale: Tween<double>(begin: 0.9, end: 1.0).animate(CurvedAnimation(parent: anim, curve: Curves.easeOutBack)), child: child),
      ),
    );
  }

  @override
  State<LegalGateDialog> createState() => _LegalGateDialogState();
}

class _LegalGateDialogState extends State<LegalGateDialog> {
  bool _gdpr = false;
  bool _busy = false;
  final _termsTap = TapGestureRecognizer();
  final _privacyTap = TapGestureRecognizer();
  late final bool _showGdpr = LegalConsentService.instance.showGdpr;

  @override
  void initState() {
    super.initState();
    _termsTap.onTap = () => _open(LegalKind.terms);
    _privacyTap.onTap = () => _open(LegalKind.privacy);
    AnalyticsService.instance.log('legal_shown', {'gdpr_box': _showGdpr ? 1 : 0});
  }

  @override
  void dispose() {
    _termsTap.dispose();
    _privacyTap.dispose();
    super.dispose();
  }

  void _open(LegalKind k) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => LegalScreen(kind: k)));
  }

  // v268: Sartlar/Gizlilik kutulari kaldirildi; "Kabul et" = ikisini de kabul. Reddet = oyundan cik.
  // AB/AEA/UK'deki kisisellestirilmis reklam kutusu (istege bagli, varsayilan KAPALI) durur.
  Future<void> _accept() async {
    if (_busy) return;
    _busy = true;
    await LegalConsentService.instance.accept(gdprConsent: _showGdpr && _gdpr);
    if (mounted) Navigator.of(context).pop();
  }

  void _decline() {
    AnalyticsService.instance.log('legal_decline');
    SystemNavigator.pop();
  }

  /// Kutusuz, tiklanabilir satir (Sartlar / Gizlilik metnini acar).
  Widget _linkRow(InlineSpan label) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Text.rich(
          label,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 14.5, height: 1.25, color: Color(0xFF4A2C0A), fontWeight: FontWeight.w700),
        ),
      );

  Widget _check({required bool value, required ValueChanged<bool> onChanged, required InlineSpan label}) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => onChanged(!value),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 28,
              height: 28,
              child: Checkbox(
                value: value,
                activeColor: const Color(0xFF3CC13A),
                side: const BorderSide(color: Color(0xFF8A5A2B), width: 2),
                visualDensity: VisualDensity.compact,
                onChanged: (v) => onChanged(v ?? false),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text.rich(
                label,
                style: const TextStyle(fontSize: 14, height: 1.25, color: Color(0xFF4A2C0A), fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }

  TextSpan _link(String text, TapGestureRecognizer r) => TextSpan(
        text: text,
        recognizer: r,
        style: const TextStyle(color: Color(0xFF1B6FD1), decoration: TextDecoration.underline, fontWeight: FontWeight.w900),
      );

  /// "{0}" yer tutuculu cumleyi, {0} yerine tiklanabilir baglanti koyarak olusturur.
  TextSpan _legalSpan(String key, String linkKey, TapGestureRecognizer r) {
    final st = AppStrings.instance;
    final parts = st.lt(key).split('{0}');
    final pre = parts.first;
    final post = parts.length > 1 ? parts.sublist(1).join('{0}') : '';
    return TextSpan(children: [
      if (pre.isNotEmpty) TextSpan(text: pre),
      _link(st.lt(linkKey), r),
      if (post.isNotEmpty) TextSpan(text: post),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final tr = AppStrings.instance.language == AppLanguage.tr;
    return PopScope(
      canPop: false,
      child: Material(
        type: MaterialType.transparency,
        child: SafeArea(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(26),
                  gradient: const LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Color(0xFFFFF4D6), Color(0xFFFFE0A3)],
                  ),
                  border: Border.all(color: const Color(0xFFFFB300), width: 4),
                  boxShadow: const [BoxShadow(color: Colors.black54, blurRadius: 20, offset: Offset(0, 8))],
                ),
                padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('🛡️', style: TextStyle(fontSize: 38, height: 1.0)),
                      const SizedBox(height: 4),
                      Text(
                        AppStrings.instance.lt('Before You Start'),
                        style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: Color(0xFF5D2E00), height: 1.1),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        AppStrings.instance.lt('To play, you need to accept the Terms of Use and the Privacy Policy. Tap the underlined text to read them.'),
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 14, height: 1.3, color: Color(0xFF6B4423), fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 10),
                      _linkRow(_legalSpan('I have read and accept the {0}.||terms', 'Terms of Use', _termsTap)),
                      _linkRow(_legalSpan('I have read and accept the {0}.||privacy', 'Privacy Policy', _privacyTap)),
                      if (_showGdpr) ...[
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.fromLTRB(10, 8, 10, 6),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.55),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: const Color(0xFF1B6FD1).withOpacity(0.5), width: 1.5),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                AppStrings.instance.lt('🇪🇺 EU / EEA / UK (GDPR)'),
                                style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w900, color: Color(0xFF14509A)),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                AppStrings.instance.lt('Your progress is stored on your device. Our ad and measurement partners (e.g. Unity LevelPlay) may process data such as the advertising ID and device info. You can withdraw consent any time in Settings > Manage Ad Consent, and exercise your data access/erasure rights via the address in the Privacy Policy.'),
                                style: const TextStyle(fontSize: 12, height: 1.25, color: Color(0xFF4A2C0A), fontWeight: FontWeight.w600),
                              ),
                              _check(
                                value: _gdpr,
                                onChanged: (v) => setState(() => _gdpr = v),
                                label: TextSpan(
                                  text: AppStrings.instance.lt('I explicitly consent to the processing of my personal data as described above.'),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 36, top: 2, bottom: 2),
                                child: Text(
                                  AppStrings.instance.lt('Optional: allow it for personalized ads. If you decline, you will still see ads, just not personalized. You can change this any time in Settings > Manage Ad Consent.'),
                                  style: const TextStyle(fontSize: 11.5, height: 1.25, color: Color(0xFF6B4423), fontWeight: FontWeight.w600),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 12),
                      CandyButton(
                        label: AppStrings.instance.lt('Accept & Continue'),
                        style: CandyStyle.green,
                        height: 58,
                        fontSize: 20,
                        pulse: true,
                        onTap: _accept,
                      ),
                      const SizedBox(height: 10),
                      CandyButton(
                        label: AppStrings.instance.lt('Decline (Exit)'),
                        style: CandyStyle.orange,
                        height: 48,
                        fontSize: 16,
                        onTap: _decline,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
