import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../services/time_service.dart';
import '../services/merge_board_service.dart';
import 'game_progress.dart';
import 'mb_missions.dart';
import 'weekly_event.dart';

import '../services/log_service.dart';
/// SEZON YOLU: aylik, 30 kademelik, bedava + premium yollu ilerleme.
///
///  * Sezon puani (SP) mevcut sistemlerden akar: siparis teslimi, bolum
///    bitirme, gorev odulu alma, cark cevirme, gunluk odul.
///  * Her ayin 1'inde sezon sifirlanir (TimeService: saat hilesine karsi).
///  * Premium yol iki yolla alinir: (1) GERCEK PARA (Play Billing, [premiumProductId]) -> sezon boyunca
///    tum premium oduller reklamsiz; (2) para vermeyen: bir kademenin bedava odulu alininca ayni
///    kademenin premium odulu 1 odullu reklam izlenerek alinir (ekranda).
///    [kSeasonPremiumEnabled] false ise premium yol hic gorunmez.
///  * Kaydi kendi anahtariyla ('season_v1') tutar; GameProgress'e ek alan
///    gerektirmez, eski kayitlar etkilenmez.
const bool kSeasonPremiumEnabled = true;

class SeasonReward {
  final int coins;
  final int gems;
  final bool energy; // Mod 1 enerjisi: tam dolum
  final int mbEnergy; // Mod 2 enerjisi (⚡ adet)
  final BoosterType? booster;
  final int boosterCount;
  const SeasonReward({
    this.coins = 0,
    this.gems = 0,
    this.energy = false,
    this.mbEnergy = 0,
    this.booster,
    this.boosterCount = 1,
  });
}

class SeasonService {
  SeasonService._();
  static final SeasonService instance = SeasonService._();

  // ── Denge sabitleri ──
  static const int tierCount = 30;
  static const String premiumProductId = 'season_pass_premium';
  // Kademeli maliyet: 1. kademe [baseSp], sonraki her kademe [stepSp] daha pahali.
  // (1->50, 2->54, 3->58 ... 30->166; toplam 3240 SP)
  // v187 HEDEF: her gun oynayan biri sezonu ~ayin 25-28. gununde bitirir (hafta sonu x1.5 dahil);
  // haftanin 3-4 gunu oynayan ~20. kademeye gelir. Kaynak dagilimi asagida.
  static const int baseSp = 50;
  static const int stepSp = 4;
  static const double weekendSeasonMultiplier = 1.5;
  static const int spOrder = 1;
  static const int spChapter = 8;
  static const int spMission = 10;
  static const int spWheel = 5;
  static const int spDaily = 5;
  // Mod 2 (merge tahtasi): siparis icin spOrder kullanilir; bolum/dunya/gorev ayri.
  static const int spMbChapter = 15;
  static const int spMbWorld = 40;
  static const int spMbMission = 5;
  // v187: gorev/sandik SP'si doneme gore: gunluk 5 (+10 sandik), haftalik 25 (+50), aylik 60 (+120).
  // Gunluk oyuncu ~ayda: oyun ~1500 + gunluk gorev/sandik ~900 + haftalik ~750 + aylik ~400 = ~3500 SP.
  static int spMbMissionFor(MbPeriod p) => switch (p) { MbPeriod.daily => 5, MbPeriod.weekly => 25, MbPeriod.monthly => 60 };
  static int spMbChestFor(MbPeriod p) => switch (p) { MbPeriod.daily => 10, MbPeriod.weekly => 50, MbPeriod.monthly => 120 };

  /// t. kademeye gecmek icin gereken SP (t: 1..tierCount).
  static int tierCost(int t) => baseSp + stepSp * (t - 1);

  /// t. kademeye ulasmak icin toplam SP.
  static int cumulativeSp(int t) {
    var sum = 0;
    for (var i = 1; i <= t; i++) {
      sum += tierCost(i);
    }
    return sum;
  }

  static const String _key = 'season_v1';

  int _seasonId = 0; // yil*100+ay
  int points = 0;
  bool premium = false;
  final Set<int> _claimedFree = {};
  final Set<int> _claimedPremium = {};

  // ── Odul tablolari ──
  static SeasonReward freeReward(int t) {
    if (t == tierCount) return const SeasonReward(gems: 30, coins: 2000, mbEnergy: 100);
    if (t % 10 == 0) return const SeasonReward(gems: 12, coins: 800);
    if (t % 5 == 0) return const SeasonReward(mbEnergy: 60, gems: 3);
    if (t % 3 == 0) return const SeasonReward(gems: 2, mbEnergy: 15);
    if (t % 2 == 0) return const SeasonReward(mbEnergy: 25);
    return SeasonReward(coins: 100 + t * 10);
  }

  static SeasonReward premiumReward(int t) {
    if (t == tierCount) return const SeasonReward(gems: 100, coins: 5000, mbEnergy: 200);
    if (t % 10 == 0) return const SeasonReward(gems: 30, coins: 1500, mbEnergy: 100);
    if (t % 5 == 0) {
      return SeasonReward(gems: 12, mbEnergy: 100, booster: BoosterType.values[(t ~/ 5) % 3], boosterCount: 3);
    }
    if (t % 3 == 0) return const SeasonReward(gems: 8, mbEnergy: 30);
    if (t % 2 == 0) return const SeasonReward(mbEnergy: 50, coins: 200);
    return SeasonReward(coins: 300 + t * 30, gems: 2);
  }

  // ── Durum ──
  static int _currentSeasonId() {
    final n = TimeService.instance.now();
    return n.year * 100 + n.month;
  }

  /// Sezonun bitmesine kalan sure.
  Duration get timeLeft {
    _rollIfNewSeason();
    final n = TimeService.instance.now();
    final next = DateTime(n.year, n.month + 1, 1);
    return next.difference(n);
  }

  void _rollIfNewSeason() {
    final id = _currentSeasonId();
    if (_seasonId != id) {
      _seasonId = id;
      points = 0;
      premium = false;
      _claimedFree.clear();
      _claimedPremium.clear();
      save();
    }
  }

  int get tier {
    _rollIfNewSeason();
    var t = 0;
    while (t < tierCount && points >= cumulativeSp(t + 1)) {
      t++;
    }
    return t;
  }

  /// Mevcut kademe icindeki ilerleme; son kademede tam.
  int get pointsInTier {
    final t = tier;
    if (t >= tierCount) return tierCost(tierCount);
    return points - cumulativeSp(t);
  }

  /// Siradaki kademe icin gereken SP (son kademede son kademenin maliyeti).
  int get nextTierCost => tierCost((tier + 1).clamp(1, tierCount));

  bool isClaimed(int t, {required bool premiumTrack}) =>
      (premiumTrack ? _claimedPremium : _claimedFree).contains(t);

  bool canClaim(int t, {required bool premiumTrack}) {
    _rollIfNewSeason();
    if (t < 1 || t > tierCount || t > tier) return false;
    // Premium: satin alindiysa dogrudan; alinmadiysa ayni kademenin bedava odulu alinmis olmali (reklami ekran izletir).
    if (premiumTrack && !premium && !_claimedFree.contains(t)) return false;
    return !isClaimed(t, premiumTrack: premiumTrack);
  }

  /// Alinmayi bekleyen odul var mi? (ana menu kirmizi noktasi)
  bool get hasClaimable {
    _rollIfNewSeason();
    for (var t = 1; t <= tier; t++) {
      if (canClaim(t, premiumTrack: false)) return true;
      if (kSeasonPremiumEnabled && canClaim(t, premiumTrack: true)) return true;
    }
    return false;
  }

  int get claimableCount {
    var n = 0;
    for (var t = 1; t <= tier; t++) {
      if (canClaim(t, premiumTrack: false)) n++; // premium (satin alinmadiysa) reklam ister: "Hepsini al" sayisina girmez
      if (kSeasonPremiumEnabled && premium && canClaim(t, premiumTrack: true)) n++;
    }
    return n;
  }

  void addPoints(int amount) {
    if (amount <= 0 || !GameProgress.instance.seasonUnlocked) return;
    _rollIfNewSeason();
    final max = cumulativeSp(tierCount);
    final gain = WeeklyEvent.instance.isWeekend ? (amount * weekendSeasonMultiplier).floor() : amount;
    points = (points + gain).clamp(0, max).toInt();
    save();
  }

  /// Bir kademenin odulunu verir. Basariliysa odulu doner, degilse null.
  SeasonReward? claim(int t, {required bool premiumTrack}) {
    if (!canClaim(t, premiumTrack: premiumTrack)) return null;
    final r = premiumTrack ? premiumReward(t) : freeReward(t);
    (premiumTrack ? _claimedPremium : _claimedFree).add(t);
    GameProgress.instance.grantReward(
      coins: r.coins,
      gems: r.gems,
      energy: r.energy,
      booster: r.booster,
      boosterAmount: r.boosterCount,
    );
    if (r.mbEnergy > 0) MergeBoardService.instance.grantEnergy(r.mbEnergy, source: 'sezon');
    save();
    return r;
  }

  /// Alinabilen tum odulleri tek seferde verir; alinan adet doner. Satin ALMAYANLARDA yalniz bedava oduller
  /// toplanir; premium oduller her kademe icin ayrica reklam izlenerek alinir (toplu reklam yok).
  int claimAll() {
    var n = 0;
    for (var t = 1; t <= tier; t++) {
      if (claim(t, premiumTrack: false) != null) n++;
      if (kSeasonPremiumEnabled && premium && claim(t, premiumTrack: true) != null) n++; // yalniz satin alanlar
    }
    return n;
  }

  /// Premium yolu acar (Play Billing teslimatinda BillingService cagirir).
  void unlockPremium() {
    _rollIfNewSeason();
    premium = true;
    save();
  }

  // ── Kalicilik ──
  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_key);
      if (raw != null && raw.isNotEmpty) {
        final j = jsonDecode(raw) as Map<String, dynamic>;
        _seasonId = j['season'] as int? ?? 0;
        points = j['points'] as int? ?? 0;
        premium = j['premium'] as bool? ?? false;
        _claimedFree
          ..clear()
          ..addAll((j['free'] as List? ?? const []).whereType<int>());
        _claimedPremium
          ..clear()
          ..addAll((j['prem'] as List? ?? const []).whereType<int>());
        AppLog.i('season.load', 'yuklendi sezon=$_seasonId puan=$points premium=$premium');
      }
    } catch (err) {
      AppLog.w('season.load', 'yutulan hata', err);
      // bozuk kayit: varsayilanla devam
    }
    _rollIfNewSeason();
  }

  Future<void> save() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(
        _key,
        jsonEncode({
          'season': _seasonId,
          'points': points,
          'premium': premium,
          'free': _claimedFree.toList(),
          'prem': _claimedPremium.toList(),
        }),
      );
    } catch (err) { AppLog.w('season.save', 'yutulan hata', err); }
  }
}
