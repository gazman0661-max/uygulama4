/// Etkinlik odulu (coin / elmas / Mod 2 enerjisi). Canli yarislar ve hedef odulleri kullanir.
class EventReward {
  final int coins;
  final int gems;
  final int energy; // Mod 2 enerjisi
  const EventReward({this.coins = 0, this.gems = 0, this.energy = 0});

  bool get isEmpty => coins == 0 && gems == 0 && energy == 0;

  EventReward operator +(EventReward o) =>
      EventReward(coins: coins + o.coins, gems: gems + o.gems, energy: energy + o.energy);
}
