import 'analytics_service.dart';
import 'dart:async';
import 'dart:ui' as ui;

import 'package:shared_preferences/shared_preferences.dart';

import 'ad_service.dart';
import 'app_update_service.dart';
import 'push_service.dart';

import 'log_service.dart';
/// Ilk acilista Kullanim Sartlari + Gizlilik Politikasi onayi (ZORUNLU).
/// AB/AEA/UK'de ek olarak ISTEGE BAGLI kisisellestirilmis reklam onayi (GDPR kutusu):
/// isaretlenirse kisisellestirilmis, isaretlenmezse kisisellestirilmemis reklam.
/// Secim her zaman Ayarlar > Reklam Rizasi'ndan degistirilebilir.
/// Onay verilmeden oyun acilmaz; reklam SDK'si ve push (Firebase)
/// onaydan ONCE baslatilmaz.
///
/// Metinler degisip yeniden onay gerekirse [_kVersion] sayisini artir.
class LegalConsentService {
  LegalConsentService._();
  static final LegalConsentService instance = LegalConsentService._();

  static const int _kVersion = 1;
  static const String _kKey = 'legal_consent_version_v1';
  static const String _kTimeKey = 'legal_consent_time_v1';

  bool _accepted = false;
  bool get accepted => _accepted;

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      final v = p.getInt(_kKey);
      _accepted = (v ?? 0) >= _kVersion;
      AppLog.i('consent', 'load: kayitliSurum=$v gerekli=$_kVersion kabul=$_accepted');
    } catch (err, st) {
      _accepted = false;
      AppLog.e('consent', 'load BASARISIZ (onay okunamadi)', err, st);
    }
  }

  /// Kullanici onayladi: kaydet, sonra onay gerektiren servisleri baslat.
  Future<void> accept({required bool gdprConsent}) async {
    _accepted = true;
    try {
      final p = await SharedPreferences.getInstance();
      final ok1 = await p.setInt(_kKey, _kVersion);
      final ok2 = await p.setString(_kTimeKey, DateTime.now().toUtc().toIso8601String());
      final ok3 = await p.setBool('legal_gdpr_consent_v1', gdprConsent);
      final back = p.getInt(_kKey);
      if (ok1 && ok2 && ok3 && back == _kVersion) {
        AppLog.i('consent', 'accept: diske yazildi (geri okunan=$back)');
      } else {
        AppLog.e('consent', 'accept: YAZMA BASARISIZ setInt=$ok1 setString=$ok2 setBool=$ok3 geriOkunan=$back');
      }
    } catch (err, st) {
      AppLog.e('consent', 'accept: yazma ISTISNA', err, st);
    }
    AnalyticsService.instance.log('consent_accept', {'gdpr': gdprConsent ? 1 : 0});
    startConsentGatedServices();
  }

  bool _started = false;

  /// Reklam SDK'si (LevelPlay) ve push: yalnizca onay sonrasi.
  void startConsentGatedServices() {
    if (_started || !_accepted) return;
    _started = true;
    AppLog.i('consent', 'onay sonrasi servisler basliyor');
    unawaited(PushService.instance.init());
    // Reklam rizasi penceresi kapandiktan SONRA Play Games girisi (iki sistem penceresi ust uste binmesin).
    // Once zorunlu guncelleme kontrolu (Play'de yeni surum varsa tam ekran pencere cikar),
    // sonra reklam rizasi ve Play Games girisi (pencereler ust uste binmesin).
    unawaited(AppUpdateService.instance
        .check()
        .catchError((Object err) {
          AppLog.w('consent.guncelleme', 'check hatasi', err);
        })
        .then((_) async {
          // AB/AEA/UK'de acik GDPR onayi (yasal pencerenin kutusu) LevelPlay'e iletilir.
          bool gdprConsent = false;
          try {
            final p = await SharedPreferences.getInstance();
            gdprConsent = p.getBool('legal_gdpr_consent_v1') ?? false;
          } catch (err) {
            AppLog.w('consent.reklam', 'gdpr onayi okunamadi', err);
          }
          await AdService.instance
              .initializeSdk(gdprApplies: showGdpr, gdprConsent: gdprConsent)
              .timeout(const Duration(seconds: 8), onTimeout: () {})
              .catchError((Object err) {
            AppLog.w('consent.reklam', 'SDK hatasi', err);
          });
        })
        .whenComplete(() {
          // v268: Play Games girisi OTOMATIK degil; Ayarlar > "Google Play Games ile giris yap"
          // dugmesinden elle yapilir (CloudSaveService.autoSignIn artik cagrilmiyor).
        }));
  }

  static const Set<String> _gdprRegions = {
    // AB uyeleri
    'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU', 'IE',
    'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE',
    // AEA + Birlesik Krallik + Isvicre
    'IS', 'LI', 'NO', 'GB', 'UK', 'CH',
  };

  /// Cihaz bolgesi AB/AEA/UK/Isvicre ise (ya da bolge bilinmiyorsa, temkinli
  /// olarak) acik GDPR onay kutusu gosterilir. Reklam icin asil bolge tespitini
  /// LevelPlay'e gonderilen GDPR bayragi belirler.
  bool get showGdpr {
    final cc = ui.PlatformDispatcher.instance.locale.countryCode;
    if (cc == null || cc.isEmpty) return true;
    return _gdprRegions.contains(cc.toUpperCase());
  }
}
