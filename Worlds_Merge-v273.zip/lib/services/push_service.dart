import 'dart:async';
import 'dart:math';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'analytics_service.dart';
import 'crash_service.dart';
import 'remote_config_service.dart';
import 'inbox_service.dart';

import 'log_service.dart';
/// FIREBASE BASLATMA + PUSH BILDIRIMI (Firebase Cloud Messaging) - "Gelen kutunda mesajin var".
///
/// Ayni Firebase uygulamasi kullanim istatistigi (Firebase Analytics) icin de baslatilir.
///
/// - Bildirimi sistem gosterir (uygulama kapaliyken de); icerigi sabit metindir, mesajin kendisi
///   bildirimde gorunmez. Metinler: android/app/src/main/res/values*/strings.xml (inbox_push_*).
/// - Firebase bilgileri google-services.json OLMADAN buradan verilir. Doldurulana kadar
///   [isConfigured] false'tur ve servis hicbir sey yapmaz (oyun etkilenmez).
/// - Cihaz token'i InboxService.setPushToken ile worker'a gider (yalnizca degisince).
/// - Herkese giden mesajlar icin cihaz 'all' konusuna abone olur (abonelik Google'a gider,
///   worker'a istek olmaz).
class PushService {
  PushService._();
  static final PushService instance = PushService._();

  // Firebase projesi: worlds-merge, Android uygulamasi: com.sitora.ai (google-services.json'dan alindi).
  // Ayni degerler indirilen google-services.json icinde de yazar:
  //   projectId        = project_info.project_id
  //   messagingSenderId= project_info.project_number
  //   appId            = client[0].client_info.mobilesdk_app_id
  //   apiKey           = client[0].api_key[0].current_key
  // (Bunlar gizli anahtar degildir; her APK'nin icinde zaten bulunur.)
  static const String projectId = 'worlds-merge';
  static const String messagingSenderId = '1029325989416';
  static const String appId = '1:1029325989416:android:395f375d3bfdf34adf771d';
  static const String apiKey = 'AIzaSyBslNFyww1SZVR7cctGQ9oWCNpHjsp4OOM';

  static const String topicAll = 'all';

  // Bu cihazda en son hangi Firebase ayariyla (proje/gonderen/uygulama) FCM token'i alindi.
  static const String _cfgStampKey = 'fcm_cfg_stamp_v1';

  static bool get isConfigured =>
      !projectId.startsWith('BURAYA') &&
      !messagingSenderId.startsWith('BURAYA') &&
      !appId.startsWith('BURAYA') &&
      !apiKey.startsWith('BURAYA');

  bool _started = false;
  final Random _rng = Random();

  bool _coreOk = false;
  Future<void>? _coreFuture;

  /// v268: Firebase cekirdegi + Analytics (+ Crashlytics) acilista, onay penceresini BEKLEMEDEN baslar
  /// (main.dart'ta en basta). Boylece ilk acilis, yasal pencere, internet kapisi gibi adimlar da
  /// huni olaylarinda gorunur. Olaylar sink baglanana kadar AnalyticsService'te tamponlanir.
  /// Birden fazla kez cagrilabilir (ayni Future doner).
  Future<void> initCore() => _coreFuture ??= _initCore();

  Future<void> _initCore() async {
    if (!isConfigured) return;
    try {
      await Firebase.initializeApp(
        options: const FirebaseOptions(
          apiKey: apiKey,
          appId: appId,
          messagingSenderId: messagingSenderId,
          projectId: projectId,
        ),
      ).timeout(const Duration(seconds: 10));
      AppLog.i('push', 'Firebase.initializeApp tamam (cekirdek, onay beklemeden)');
      unawaited(FirebaseAnalytics.instance.setAnalyticsCollectionEnabled(true).catchError((_) {}));
      unawaited(CrashService.instance.init());
      // Anahtar olaylar (huni + gelir) Firebase'e gider; liste AnalyticsService.firebaseEvents'te.
      // Digerleri yalnizca cihazda sayilir (Ayarlar > "Nasil oynanir?" uzun basma ozeti).
      AnalyticsService.instance.sink = (n, p) {
        unawaited(FirebaseAnalytics.instance.logEvent(name: n, parameters: p).catchError((_) {}));
      };
      _coreOk = true;
      AppLog.i('push', 'Firebase Analytics: otomatik metrikler + anahtar olaylar (${AnalyticsService.firebaseEvents.length} olay)');
    } catch (err) {
      AppLog.w('push_service.initCore', 'yutulan hata', err);
    }
  }

  /// Firebase projesi / google-services.json degistiyse eski ayarla alinmis FCM token'i yeni projede
  /// GECERSIZDIR (sunucu SENDER_ID_MISMATCH / UNREGISTERED alir, bildirim gelmez). Ayar damgasi
  /// degisince token bir kez silinir; yenisi alinip sunucuya gonderilir. Ilk calistirmada da bir kez calisir.
  Future<void> _resetTokenIfConfigChanged(FirebaseMessaging fm) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final stamp = '$projectId|$messagingSenderId|$appId';
      if (prefs.getString(_cfgStampKey) == stamp) return;
      await fm.deleteToken().timeout(const Duration(seconds: 10));
      await prefs.setString(_cfgStampKey, stamp);
      AppLog.i('push', 'Firebase ayari yeni/degisti: FCM token yenilendi');
    } catch (err) {
      AppLog.w('push_service.resetToken', 'yutulan hata', err);
    }
  }

  /// Onay sonrasi: Remote Config + push (FCM). Cekirdek zaten acilista baslamis olur.
  Future<void> init() async {
    if (_started || !isConfigured) return;
    _started = true;
    try {
      await initCore();
      if (!_coreOk) return;
      unawaited(FirebaseMessaging.instance.setAutoInitEnabled(true).catchError((_) {}));
      unawaited(RemoteConfigService.instance.init());
      final fm = FirebaseMessaging.instance;
      await _resetTokenIfConfigChanged(fm);

      // Uygulama ONDEYKEN gelen push'u sistem gostermez: gelen kutusunu yenile. Herkese giden bir
      // mesajda binlerce cihaz ayni anda istek atmasin diye 0-30 sn rastgele gecikme.
      FirebaseMessaging.onMessage.listen((_) {
        Future<void>.delayed(Duration(seconds: _rng.nextInt(30)), () {
          unawaited(InboxService.instance.sync(force: true));
        });
      });
      // Arka plandaki uygulama bildirime dokunularak acildi: oyuncu bekliyor, hemen yenile.
      FirebaseMessaging.onMessageOpenedApp.listen((_) {
        unawaited(InboxService.instance.sync(force: true));
      });
      // (Kapaliyken bildirimle acilis zaten acilis senkronuyla yenilenir.)

      fm.onTokenRefresh.listen((t) => unawaited(InboxService.instance.setPushToken(t)));
      unawaited(fm.subscribeToTopic(topicAll).catchError((_) {}));
      final t = await fm.getToken();
      if (t != null) {
        AppLog.i('push', 'FCM token alindi (...${t.substring(t.length > 8 ? t.length - 8 : 0)})');
        await InboxService.instance.setPushToken(t);
      }
    } catch (err) {
      AppLog.w('push_service.init', 'yutulan hata', err);
      // Firebase / Play Hizmetleri yoksa push sessizce devre disi kalir; oyun etkilenmez.
    }
  }
}
