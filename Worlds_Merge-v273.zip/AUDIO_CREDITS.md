# Ses kaynakları ve lisanslar

Tüm dosyalar Pixabay'den indirildi (Pixabay Content License: ticari kullanım serbest, atıf zorunlu değil).
Play Store'a çıkarken lisans kanıtı gerekirse Pixabay'deki sayfa adresleri ve dosya adları aşağıda.

| Oyundaki dosya | Orijinal dosya | Sanatçı | Yapılan işlem |
|---|---|---|---|
| assets/music/loop.wav | deawthanapon-lofi-relax-beat-loop-bpm-88-eb-major-ii-v-i-361752.mp3 | deawthanapon | Baş/son sessizlik kesildi, tam 8 ölçüye (21.818 sn) ayarlandı, +8 dB, 32 kHz stereo wav |
| assets/sfx/hit_1..4.wav | floraphonic-glass-clink-9-188130.mp3 | floraphonic | 4 perde varyasyonu (+5, +2, -1, -4 yarım ses), seviye eşitlendi |
| assets/sfx/merge_2..8.wav | universfield-bubble-pop-06-351337.mp3 | universfield | 7 perde varyasyonu (-3 ... +8 yarım ses, seviye yükseldikçe tizleşir) |

Diğer sesler (throw, wall, coin, reward, merge_max, new_tier, pe_*) hâlâ `tools/generate_sfx.py` ile üretilmiş orijinal sentetik seslerdir.
