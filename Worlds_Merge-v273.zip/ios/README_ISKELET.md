# iOS - ISKELET (henuz calisir durumda degil)

Bu klasor sadece placeholder/iskelet olarak eklendi, kullanicinin acik
talebi geregi ("iOS dosyasini iskelet olarak koy") gercek bir Xcode
projesi DEGILDIR ve olduğu gibi build alinamaz.

Icinde olanlar:
- Runner/AppDelegate.swift
- Runner/Info.plist
- Podfile (minimal)

Icinde OLMAYANLAR (gercek build icin gerekli):
- ios/Runner.xcodeproj/
- ios/Runner.xcworkspace/
- ios/Runner/Assets.xcassets/
- ios/Runner/Base.lproj/LaunchScreen.storyboard, Main.storyboard
- ios/Flutter/ (Debug.xcconfig, Release.xcconfig, Generated.xcconfig)

Gercek iOS build'i almak icin (bir Mac + Xcode gerekir):
1. Bu proje klasorunu bir Mac'e kopyalayin.
2. `flutter create --platforms=ios .` komutunu proje kok dizininde calistirin
   (mevcut lib/ ve pubspec.yaml dosyalarina dokunmaz, sadece eksik ios/
   dosyalarini tamamlar).
3. `cd ios && pod install`
4. `flutter run` veya Xcode'dan Runner.xcworkspace'i acip calistirin.

FlutLab gibi tarayici tabanli ortamlar genelde sadece Android build
alabilir, bu yuzden bu proje bilerek Android-first tasarlandi.
